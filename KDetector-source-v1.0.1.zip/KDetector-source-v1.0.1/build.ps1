<#
.SYNOPSIS
    Сборка KDetector.dll, запуск тестов и подготовка установочного архива.

.DESCRIPTION
    1. Проверяет наличие .NET SDK (6.0 или новее).
    2. Определяет папку Among Us (параметр -GamePath, переменная окружения AMONGUS или стандартные пути Steam/Epic).
    3. Проверяет BepInEx 6 IL2CPP и interop-сборки игры (BepInEx\core, BepInEx\interop).
    4. Восстанавливает пакеты, собирает Release, запускает тесты ядра.
    5. Проверяет результат (код возврата, наличие DLL, управляемая сборка, ссылки на сборки игры).
    6. Копирует результат в dist и собирает dist\KDetector-setup.zip.

.PARAMETER GamePath
    Папка Among Us (та, где лежит "Among Us.exe").

.PARAMETER UseNuGet
    Собирать против пакетов NuGet (BepInEx.Unity.IL2CPP 6.0.0-be.735 + AmongUs.GameLibs.Steam 2026.9.29)
    вместо interop-сборок из папки игры. Нужен доступ к nuget.bepinex.dev.

.PARAMETER Install
    После сборки скопировать KDetector.dll в <GamePath>\BepInEx\plugins\KDetector\.

.PARAMETER SkipTests
    Не запускать тесты ядра.

.EXAMPLE
    .\build.ps1 -GamePath "C:\Program Files (x86)\Steam\steamapps\common\Among Us"

.EXAMPLE
    .\build.ps1 -GamePath "D:\Games\Among Us" -Install
#>
[CmdletBinding()]
param(
    [string]$GamePath = $env:AMONGUS,
    [switch]$UseNuGet,
    [switch]$Install,
    [switch]$SkipTests,
    [ValidateSet('Release', 'Debug')]
    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$PluginProject = Join-Path $Root 'src\KDetector.Plugin\KDetector.Plugin.csproj'
$TestProject = Join-Path $Root 'tests\KDetector.Core.Tests\KDetector.Core.Tests.csproj'
$Dist = Join-Path $Root 'dist'
$BuildOut = Join-Path $Root 'build\out'

function Write-Step([string]$text) { Write-Host "`n==> $text" -ForegroundColor Cyan }
function Fail([string]$text) {
    Write-Host "`nОШИБКА: $text" -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------------------- 1. .NET SDK
Write-Step 'Проверка .NET SDK'
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) {
    Fail ".NET SDK не найден. Установите .NET SDK 8.0 (или новее) с https://dotnet.microsoft.com/download и перезапустите PowerShell."
}
$sdks = & dotnet --list-sdks
if (-not $sdks) { Fail 'dotnet установлен, но SDK не найден (установлен только Runtime). Установите .NET SDK 8.0.' }
$maxMajor = ($sdks | ForEach-Object { [int]($_ -split '\.')[0] } | Measure-Object -Maximum).Maximum
if ($maxMajor -lt 6) { Fail "Нужен .NET SDK 6.0 или новее. Найдено: $($sdks -join '; ')" }
Write-Host "Найден .NET SDK: $(($sdks | Select-Object -Last 1))"

# ---------------------------------------------------------------- 2. Папка игры
Write-Step 'Поиск папки Among Us'
if (-not $GamePath) {
    $candidates = @(
        "${env:ProgramFiles(x86)}\Steam\steamapps\common\Among Us",
        "$env:ProgramFiles\Steam\steamapps\common\Among Us",
        "$env:ProgramFiles\Epic Games\AmongUs",
        "C:\SteamLibrary\steamapps\common\Among Us",
        "D:\SteamLibrary\steamapps\common\Among Us"
    )
    $GamePath = $candidates | Where-Object { $_ -and (Test-Path (Join-Path $_ 'Among Us.exe')) } | Select-Object -First 1
}

if (-not $UseNuGet) {
    if (-not $GamePath) {
        Fail ("Папка Among Us не найдена автоматически. Укажите её: .\build.ps1 -GamePath ""C:\путь\к\Among Us""`n" +
              "или соберите против пакетов NuGet: .\build.ps1 -UseNuGet")
    }
    $GamePath = (Resolve-Path $GamePath).Path
    if (-not (Test-Path (Join-Path $GamePath 'Among Us.exe'))) {
        Fail "В папке '$GamePath' нет файла 'Among Us.exe'. Укажите папку игры, а не папку BepInEx или plugins."
    }
    Write-Host "Папка игры: $GamePath"

    # ------------------------------------------------------------ 3. BepInEx и interop
    Write-Step 'Проверка BepInEx и interop-сборок игры'
    $core = Join-Path $GamePath 'BepInEx\core'
    $interop = Join-Path $GamePath 'BepInEx\interop'
    $required = @('BepInEx.Core.dll', 'BepInEx.Unity.IL2CPP.dll', '0Harmony.dll', 'Il2CppInterop.Runtime.dll')
    foreach ($f in $required) {
        if (-not (Test-Path (Join-Path $core $f))) {
            Fail ("Не найден BepInEx\core\$f.`n" +
                  "Установите BepInEx 6 Bleeding Edge, вариант Unity.IL2CPP-win-x64 (build 735 или новее), в папку игры и запустите игру один раз.`n" +
                  "Инструкция: docs\INSTALLATION_RU.md, раздел «Установка BepInEx».")
        }
    }
    foreach ($f in @('Assembly-CSharp.dll', 'Hazel.dll', 'UnityEngine.CoreModule.dll', 'UnityEngine.IMGUIModule.dll')) {
        if (-not (Test-Path (Join-Path $interop $f))) {
            Fail ("Не найден BepInEx\interop\$f.`n" +
                  "Interop-сборки создаются BepInEx при ПЕРВОМ запуске игры с установленным BepInEx (это может занять несколько минут).`n" +
                  "Запустите Among Us, дождитесь главного меню, закройте игру и повторите сборку.")
        }
    }
    $exe = Join-Path $GamePath 'Among Us.exe'
    $bytes = [IO.File]::ReadAllBytes($exe)
    $pe = [BitConverter]::ToInt32($bytes, 0x3C)
    $machine = [BitConverter]::ToUInt16($bytes, $pe + 4)
    $arch = switch ($machine) { 0x8664 { 'x64' } 0x14c { 'x86' } default { "0x{0:X}" -f $machine } }
    Write-Host "Архитектура Among Us.exe: $arch"
    if ($arch -ne 'x64') {
        Write-Host "ВНИМАНИЕ: игра не 64-битная. Нужен BepInEx Unity.IL2CPP-win-x86. Плагин (MSIL) при этом не меняется." -ForegroundColor Yellow
    }
    $libArgs = @("-p:AmongUsPath=$GamePath", '-p:GameLibsSource=Local')
}
else {
    Write-Host 'Режим NuGet: BepInEx.Unity.IL2CPP 6.0.0-be.735 + AmongUs.GameLibs.Steam 2026.9.29'
    $libArgs = @('-p:GameLibsSource=NuGet')
    if ($GamePath) { $libArgs += "-p:AmongUsPath=$GamePath" }
}

# ---------------------------------------------------------------- 4. Restore + Build
Write-Step 'Восстановление пакетов'
& dotnet restore $PluginProject @libArgs
if ($LASTEXITCODE -ne 0) { Fail "dotnet restore завершился с кодом $LASTEXITCODE (см. сообщения выше)." }

Write-Step "Сборка $Configuration"
if (Test-Path $BuildOut) { Remove-Item $BuildOut -Recurse -Force }
& dotnet build $PluginProject -c $Configuration --no-restore -o $BuildOut @libArgs
if ($LASTEXITCODE -ne 0) { Fail "Сборка завершилась с кодом $LASTEXITCODE. Ошибки компилятора перечислены выше (строки 'error CS…')." }

# ---------------------------------------------------------------- 5. Tests
if (-not $SkipTests) {
    Write-Step 'Тесты ядра (без игры)'
    & dotnet run --project $TestProject -c $Configuration
    if ($LASTEXITCODE -ne 0) { Fail 'Тесты ядра не прошли — DLL не будет упакована. Подробности выше.' }
}

# ---------------------------------------------------------------- 6. Проверка результата
Write-Step 'Проверка результата'
$dll = Join-Path $BuildOut 'KDetector.dll'
if (-not (Test-Path $dll)) { Fail "Файл $dll не найден после сборки." }
$name = [Reflection.AssemblyName]::GetAssemblyName($dll)
Write-Host "Сборка: $($name.FullName)"
$bytes = [IO.File]::ReadAllBytes($dll)
$text = [Text.Encoding]::ASCII.GetString($bytes)
foreach ($ref in @('BepInEx.Unity.IL2CPP', 'Il2CppInterop.Runtime', '0Harmony')) {
    if (-not $text.Contains($ref)) { Fail "В DLL нет ссылки на $ref — сборка некорректна." }
}
if (-not ($text.Contains('Assembly-CSharp'))) { Fail 'В DLL нет ссылки на Assembly-CSharp — сборка выполнена не против игровых библиотек.' }
Write-Host 'Управляемая сборка (MSIL) со ссылками на BepInEx, HarmonyX, Il2CppInterop и Assembly-CSharp: OK'

# ---------------------------------------------------------------- 7. dist
Write-Step 'Подготовка dist'
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
Copy-Item $dll (Join-Path $Dist 'KDetector.dll') -Force
$setup = Join-Path $Root 'build\setup'
if (Test-Path $setup) { Remove-Item $setup -Recurse -Force }
$pluginDir = Join-Path $setup 'BepInEx\plugins\KDetector'
New-Item -ItemType Directory -Force -Path $pluginDir | Out-Null
Copy-Item $dll $pluginDir
foreach ($f in @('README_RU.txt', 'INSTALLATION_RU.txt', 'KDetector.cfg.example')) {
    $src = Join-Path $Dist $f
    if (Test-Path $src) { Copy-Item $src $setup }
}
$zip = Join-Path $Dist 'KDetector-setup.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $setup '*') -DestinationPath $zip
Write-Host "Архив: $zip"

if ($Install) {
    if (-not $GamePath) { Fail 'Для -Install нужен -GamePath.' }
    $target = Join-Path $GamePath 'BepInEx\plugins\KDetector'
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    Copy-Item $dll $target -Force
    Write-Host "Установлено в $target" -ForegroundColor Green
}

Write-Host "`nГОТОВО. DLL: $(Join-Path $Dist 'KDetector.dll')" -ForegroundColor Green
Write-Host 'Установка: скопируйте KDetector.dll в <Among Us>\BepInEx\plugins\KDetector\ (или распакуйте KDetector-setup.zip в папку игры).'
