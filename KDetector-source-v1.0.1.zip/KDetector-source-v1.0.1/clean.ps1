<#
.SYNOPSIS
    Удаляет результаты сборки (bin, obj, build). Папку dist и документацию не трогает.
#>
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$targets = @('build') + (Get-ChildItem -Path (Join-Path $Root 'src'), (Join-Path $Root 'tests') -Directory -Recurse |
        Where-Object { $_.Name -in @('bin', 'obj') } | ForEach-Object { $_.FullName })
foreach ($t in $targets) {
    $full = if ([IO.Path]::IsPathRooted($t)) { $t } else { Join-Path $Root $t }
    if (Test-Path $full) {
        Remove-Item $full -Recurse -Force
        Write-Host "Удалено: $full"
    }
}
Write-Host 'Очистка завершена.'
