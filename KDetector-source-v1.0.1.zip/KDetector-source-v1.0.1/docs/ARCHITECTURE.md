# Архитектура KDetector by CCCP_MODS (tg: @cccp_mods)

## Слои

```
┌──────────────────────────── KDetector.dll (один файл) ────────────────────────────┐
│ KDetector.Plugin (зависит от BepInEx / HarmonyX / Il2CppInterop / игры)            │
│   Plugin.cs ─ поэтапная инициализация, изоляция ошибок, Unload/Shutdown            │
│   Configuration/ConfigBinder ─ KdSettings ↔ BepInEx ConfigFile (горячее применение)│
│   Compatibility/PatchManager ─ патчи по одному, только объявленные методы          │
│   Network/RpcPatches ─ префиксы HandleRpc / UpdateSystem → ядро → отмена/пропуск   │
│   Game/ ─ GameStateReader, PlayerTracker, HostActions, GameEnums                   │
│   Commands/ChatCommandPatch ─ /kd … локально                                       │
│   UI/ ─ IMGUI: MainWindow, 10 страниц, Theme, Gui (все вызовы Unity), TextInput    │
├────────────────────────────────────────────────────────────────────────────────────┤
│ KDetector.Core (без зависимостей от игры; исходники компилируются в ту же DLL)     │
│   Detection/ ─ модель событий, RuleRegistry, DetectionEngine, Rules/*             │
│   RpcShield/ ─ SlidingWindowCounter, категории, RpcShieldEngine                   │
│   Network/NetworkInspector ─ конвейер Shield → сигнатуры → протокол               │
│   Risk/RiskModel ─ объяснимая оценка                                              │
│   Actions/ ─ профили, ActionEngine, IHostActions, очередь рассмотрения            │
│   Database/ ─ KdDatabase (JSONL), DatabaseService (фоновая запись), миграции       │
│   Configuration/ ─ KdSettings, SettingsValidator                                  │
│   Commands/, Reports/, Logging/, Diagnostics/, UiModel/                            │
└────────────────────────────────────────────────────────────────────────────────────┘
```

**Почему ядро — отдельный проект.** Чтобы 132 теста бизнес-логики запускались без игры, Unity и BepInEx. **Почему одна DLL.** Плагин включает исходники ядра (`<Compile Include="..\KDetector.Core\**\*.cs">`), поэтому пользователю не нужно заботиться о разрешении второй сборки загрузчиком BepInEx.

Изменение относительно предложенной в ТЗ структуры: папки `Bootstrap`, `Players`, `Detection`, `Database` и др. физически находятся в `KDetector.Core`, а в `KDetector.Plugin` — только код, которому нужны игровые типы. Это требование тестируемости, а не стиля.

## Поток данных

```
Unity Update (каждые 0.25 с) ─ GameStateReader → GameContext ─┐
Unity Update (каждые 0.5 с) ─ PlayerTracker.Snapshot ─────────┤→ KDetectorCore
Harmony-префикс HandleRpc ─ RpcObservation ───────────────────┘
        │
        ├─ NetworkInspector: RpcShield → KnownClientRules → ProtocolRules
        │     └─ синхронное решение об отмене: ActionEngine.ShouldCancel
        ├─ LevelRules / PlatformRules (по изменению данных игрока)
        ▼
DetectionEngine (включено? уверенность? исключения? порог в окне?) → DetectionEvent
        ▼ подписчик
RiskModel.Add → ActionEngine.Handle (Log/Notify/Mark/Watchlist/DB/Review/Report/Kick/Ban)
        ▼
DatabaseService (память сразу, диск — фоновый поток не чаще FlushIntervalSeconds)
```

## Ключевые решения

| Решение | Причина |
|---|---|
| Префиксы на `PlayerControl/PlayerPhysics/CustomNetworkTransform.HandleRpc` вместо подмены `InnerNetClient.HandleGameData` | Минимальное вмешательство: отменяется ровно один RPC; меньше конфликтов с другими модами и хрупкости при обновлениях |
| `AccessTools.DeclaredMethod` | Не патчить базовый `InnerNetObject.HandleRpc` для всех объектов, если у типа нет своего метода |
| Отмена только в безопасных категориях | Отмена движения/систем/убийств у клиента ведёт к рассинхронизации — такие превышения только фиксируются |
| Отправитель = владелец объекта | Реальный отправитель в `HandleRpc` недоступен; поэтому «host-only RPC от не-хоста» — подозрение (InvalidProtocol), а не подтверждённое нарушение |
| Копия полезной нагрузки только для номеров из каталога сигнатур | Нет аллокаций на обычных RPC; копия через `MessageReader.Get` не сдвигает исходный читатель |
| IMGUI, только подтверждённые перегрузки GUILayout; собственное поле ввода на `Input.inputString` | `GUILayout.TextField` и `GUIStyleState.textColor` не подтверждены в IL2CPP-сборке игры (могли быть вырезаны) |
| `FrameCache` для данных UI | IMGUI вызывает OnGUI несколько раз за кадр; состав элементов должен совпадать между Layout и Repaint |
| Состояние UI в статических классах | Не зависеть от управляемых полей внедрённого IL2CPP-компонента |
| JSONL + атомарная замена + карантин + сохранение строк будущей схемы | Ручное редактирование, устойчивость к сбоям, отсутствие потерь данных |
| Сложные структуры (сигнатуры, лимиты, профиль Custom) — в JSON-файлах `Data/`, остальное — в `.cfg` BepInEx | Таблицы правил плохо выражаются плоскими ключами `.cfg` и должны версионироваться |
| Режим совместимости по `Application.version` | На непроверенной версии по умолчанию «только наблюдение» |

## Потоки

- Игровой поток: патчи, Update, OnGUI, ядро. Все общие структуры ядра под блокировками.
- `KDetector.Database`: фоновая запись базы, автокопии, автоочистка. Защита от записи устаревшего снимка после восстановления — счётчик поколений.
- `KDetector.Log`: фоновая запись файлового журнала через ограниченную очередь (переполнение → строки отбрасываются с отметкой, игра не ждёт диска).

## Расширение

Новое правило: дескриптор (`RuleDescriptor`) + метод, возвращающий `DetectionCandidate`; регистрация в `KDetectorCore`. Настройки правила, GUI-страница Detection Rules, база и модель риска подхватят его автоматически.
Новая сигнатура клиента: запись в `Data/KnownClients.json` (без перекомпиляции).
Новый лимит RPC: `Data/RpcShield.json` → Categories/Overrides.
