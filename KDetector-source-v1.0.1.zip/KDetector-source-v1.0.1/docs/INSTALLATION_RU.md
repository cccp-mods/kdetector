# KDetector by CCCP_MODS (tg: @cccp_mods) v1.0.1 — установка и сборка с нуля

Инструкция рассчитана на человека, который никогда не работал с Visual Studio и .NET.
Всё делается в Windows 10/11. Время: 20–40 минут (больше всего — первый запуск игры с BepInEx).

Содержание:
1. [Что понадобится](#1-что-понадобится)
2. [Установка BepInEx в игру](#2-установка-bepinex-в-игру)
3. [Подготовка проекта](#3-подготовка-проекта)
4. [Сборка DLL](#4-сборка-dll)
5. [Установка плагина](#5-установка-плагина)
6. [Первый запуск и проверка](#6-первый-запуск-и-проверка)
7. [Сборка в Visual Studio (необязательно)](#7-сборка-в-visual-studio-необязательно)

---

## 1. Что понадобится

| Компонент | Зачем | Где взять | Обязательно? |
|---|---|---|---|
| **.NET SDK 8.0** (или 9.0) | компилятор C# и команда `dotnet` | https://dotnet.microsoft.com/download/dotnet/8.0 → раздел **SDK** → «Windows x64 Installer» | да |
| **BepInEx 6 Bleeding Edge**, вариант **Unity.IL2CPP-win-x64**, сборка **735 или новее** | загрузчик модов для Among Us | https://builds.bepinex.dev/projects/bepinex_be (официальный сервер сборок BepInEx) | да |
| Visual Studio 2022 Community, нагрузка «Разработка классических приложений .NET» | удобный редактор (сборка работает и без неё) | https://visualstudio.microsoft.com/ru/vs/community/ | нет |
| Git | скачивание исходников через `git clone` | https://git-scm.com/download/win | нет (можно скачать ZIP) |
| Интернет при первой сборке | `dotnet` скачивает справочные сборки .NET 6 (targeting pack) с nuget.org | — | да, один раз |

Зачем именно .NET SDK 8, если плагин для .NET 6: BepInEx 6 исполняет плагины на .NET 6, поэтому плагин компилируется под `net6.0`. SDK 8/9 умеет собирать под `net6.0` (скачает справочный пакет автоматически). Предупреждение `NETSDK1138` о том, что .NET 6 вне поддержки, — нормально.

**Не скачивайте DLL с неизвестных сайтов.** Все игровые библиотеки для сборки берутся из вашей собственной игры (их создаёт BepInEx).

### Проверка установки .NET SDK

Откройте **PowerShell** (Пуск → введите «PowerShell» → Enter) и выполните:

```powershell
dotnet --list-sdks
```

Должна появиться строка вроде `8.0.4xx [C:\Program Files\dotnet\sdk]`. Если пишет «dotnet не является командой» — перезапустите PowerShell или переустановите SDK. Если список пустой — установлен только Runtime, а нужен **SDK**.

---

## 2. Установка BepInEx в игру

### 2.1. Найдите папку игры

**Steam:** библиотека → правый клик по Among Us → «Управление» → «Просмотреть локальные файлы». Откроется папка, в которой лежит `Among Us.exe`. Обычно это
`C:\Program Files (x86)\Steam\steamapps\common\Among Us`.

**Epic Games:** библиотека → «…» у Among Us → «Управление» → значок папки рядом с «Установка». Обычно `C:\Program Files\Epic Games\AmongUs`.

> Важно: с версии 2026.9.29 Steam-версия игры **64-битная**. Нужен BepInEx **win-x64**. Если `build.ps1` сообщит, что ваш `Among Us.exe` 32-битный, используйте **win-x86**.

### 2.2. Установите BepInEx

1. На https://builds.bepinex.dev/projects/bepinex_be скачайте архив **BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.<номер>…zip** с номером **735 или больше**.
2. Распакуйте **содержимое** архива прямо в папку игры (рядом с `Among Us.exe` должны появиться папка `BepInEx`, папка `dotnet`, файлы `winhttp.dll` и `doorstop_config.ini`).
3. Запустите игру **один раз** и дождитесь главного меню. Первый запуск долгий (иногда 5–10 минут): BepInEx генерирует interop-сборки. Не закрывайте игру, если кажется, что она «зависла» на заставке.
4. Закройте игру. Проверьте, что появилась папка `Among Us\BepInEx\interop` с файлами `Assembly-CSharp.dll`, `Hazel.dll`, `UnityEngine.*.dll`.

Если у вас уже стоит мод, который включает BepInEx (например, BetterAmongUs), BepInEx уже установлен — убедитесь только, что сборка 735 или новее, и **не заменяйте его файлы наугад**.

---

## 3. Подготовка проекта

1. Создайте папку, например `C:\Dev\KDetector` (без кириллицы и пробелов в пути — так меньше проблем).
2. Поместите туда исходники проекта KDetector by CCCP_MODS (tg: @cccp_mods) так, чтобы в `C:\Dev\KDetector` лежали `KDetector.sln`, `build.ps1`, папки `src`, `tests`, `docs`.
   - через Git: `git clone <адрес репозитория> C:\Dev\KDetector`
   - или распакуйте архив с исходниками.

Что где лежит:

| Путь | Назначение |
|---|---|
| `src\KDetector.Core\` | логика античита без зависимостей от игры |
| `src\KDetector.Plugin\` | сам плагин BepInEx (патчи, интерфейс) |
| `src\KDetector.Plugin\KDetector.Plugin.csproj` | настройки сборки плагина (путь к игре, источник библиотек) |
| `tests\KDetector.Core.Tests\` | автотесты |
| `build.ps1` | автоматическая сборка |

### Зависимости для компиляции и для запуска — это разные вещи

- **Для компиляции** нужны DLL из `Among Us\BepInEx\core` (BepInEx, HarmonyX, Il2CppInterop) и `Among Us\BepInEx\interop` (игра и Unity). Проект ссылается на них **на месте** и **не копирует** их.
- **Для запуска** нужен только `KDetector.dll` в папке плагинов. Всё остальное уже есть у вас в игре вместе с BepInEx. Поэтому в архив плагина ничего, кроме `KDetector.dll` и текстовых файлов, не входит.

---

## 4. Сборка DLL

### 4.1. Через build.ps1 (рекомендуется)

1. Откройте PowerShell в папке проекта: в Проводнике откройте `C:\Dev\KDetector`, щёлкните по адресной строке, введите `powershell` и нажмите Enter.
2. Если PowerShell запрещает запуск скриптов, разрешите их только для текущего окна:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   ```
3. Запустите сборку, указав папку игры:
   ```powershell
   .\build.ps1 -GamePath "C:\Program Files (x86)\Steam\steamapps\common\Among Us"
   ```
   Добавьте `-Install`, чтобы сразу скопировать DLL в игру.

Скрипт по шагам: проверит .NET SDK → найдёт игру → проверит BepInEx и interop → восстановит пакеты → соберёт Release → запустит тесты → проверит DLL → положит результат в `dist`.

**Как понять, что сборка успешна:** в конце зелёная строка `ГОТОВО. DLL: …\dist\KDetector.dll`, перед ней — строка тестов `провалено: 0`. Появились файлы `dist\KDetector.dll` и `dist\KDetector-setup.zip`.

Если сборка упала — скрипт печатает `ОШИБКА:` и причину. Ошибки компилятора выглядят как `…\Файл.cs(строка,столбец): error CS0117: …`. Решения типичных проблем: [TROUBLESHOOTING_RU.md](TROUBLESHOOTING_RU.md).

### 4.2. Вручную одной командой

```powershell
dotnet build src\KDetector.Plugin\KDetector.Plugin.csproj -c Release -p:AmongUsPath="C:\Program Files (x86)\Steam\steamapps\common\Among Us"
```
DLL появится в `src\KDetector.Plugin\bin\Release\KDetector.dll`.

### 4.3. Без папки игры (через NuGet)

```powershell
.\build.ps1 -UseNuGet
```
Используются пакеты `BepInEx.Unity.IL2CPP 6.0.0-be.735` и `AmongUs.GameLibs.Steam 2026.9.29` с `nuget.bepinex.dev`. Вариант удобен, если игры на этом компьютере нет, но сборка против библиотек **вашей** игры точнее.

### Проверка Target Framework и архитектуры

- Target Framework задан в `src\KDetector.Plugin\KDetector.Plugin.csproj`: строка `<TargetFramework>net6.0</TargetFramework>`. Менять не нужно.
- Плагин — управляемая сборка **AnyCPU (MSIL)**. Выбирать x64 в настройках сборки **не нужно**: архитектуру определяет BepInEx (x64 для 64-битной игры). `build.ps1` проверяет и выводит архитектуру `Among Us.exe`.

---

## 5. Установка плагина

1. Откройте папку игры → `BepInEx` → `plugins`.
2. Создайте в ней папку `KDetector`.
3. Скопируйте туда `dist\KDetector.dll`. Итог: `Among Us\BepInEx\plugins\KDetector\KDetector.dll`.
   Либо распакуйте `dist\KDetector-setup.zip` в папку игры — он содержит ровно эту структуру.

Не заменяйте файлы BepInEx и не удаляйте другие плагины без причины. Если стоит другой античит-мод (например, BetterAmongUs), оба будут работать параллельно; при конфликтах временно отключите один из них, перенеся его DLL из `plugins` в другую папку.

---

## 6. Первый запуск и проверка

1. Запустите игру.
2. Откройте журнал BepInEx: `Among Us\BepInEx\LogOutput.log` (в некоторых сборках `LogOutput.txt`). Найдите строки:
   ```
   [Info   :KDetector by CCCP_MODS (tg: @cccp_mods)] [Core] KDetector by CCCP_MODS (tg: @cccp_mods) v1.0.1 загружается…
   [Info   :KDetector by CCCP_MODS (tg: @cccp_mods)] [Core] KDetector by CCCP_MODS (tg: @cccp_mods) готов. Открыть окно: F8…
   ```
   Строки `[Warning…][Patches]` означают, что какая-то точка интеграции не найдена: соответствующая функция отключена (не вся программа).
3. Проверьте, что появились файлы:
   - `BepInEx\config\dev.kdetector.amongus.cfg` — конфигурация (пример — `dist\KDetector.cfg.example`);
   - `BepInEx\plugins\KDetector\Data\` — `KnownClients.json`, `ProtocolRules.json`, `RpcShield.json`, `ActionPolicies.json`;
   - база `Data\KDetector.kh` создаётся при первой записи события.
4. Нажмите **F8** — откроется окно KDetector by CCCP_MODS (tg: @cccp_mods). Страница **Diagnostics** покажет версию игры, BepInEx и состояние каждого патча.
5. Зайдите в лобби. На странице **Live Players** должны появиться игроки с уровнем и платформой.
6. В чате лобби введите `/kd status` — ответ увидите только вы; сообщение не уйдёт другим игрокам.

### Безопасная проверка

- **Dry Run**: Auto Actions → «Dry Run» (или `/kd dryrun on`). Все решения вычисляются и журналируются, но ничего не отменяется и никто не удаляется. Рекомендуется первые игры провести так.
- **Неподтверждённые данные не считаются доказательством**: на странице Detections у каждого события факты отделены от гипотезы, а вид доказательства указан явно («признак известного клиента» ≠ «подтверждённое нарушение»). Одно событие не даёт высокого риска.
- **Kick/Ban**: проверяйте в **приватном лобби** со своим вторым аккаунтом или друзьями. Без полномочий хоста кнопки неактивны и объясняют причину.
- **Не используйте чит-клиенты для «проверки» античита** на публичных серверах — это нарушает правила игры.

---

## 7. Сборка в Visual Studio (необязательно)

1. Установите Visual Studio 2022 Community с нагрузкой **«Разработка классических приложений .NET»**.
2. **Файл → Открыть → Проект или решение…** → выберите `KDetector.sln`.
3. Укажите путь к игре одним из способов:
   - создайте переменную среды `AMONGUS` со значением пути к игре (Пуск → «Изменение системных переменных среды» → «Переменные среды…» → «Создать») и перезапустите Visual Studio;
   - или откройте `src\KDetector.Plugin\KDetector.Plugin.csproj` (правый клик по проекту KDetector.Plugin → «Изменить файл проекта») и после строки `<PropertyGroup>` добавьте `<AmongUsPath>C:\путь\к\Among Us</AmongUsPath>`.
4. Вверху выберите конфигурацию **Release**.
5. **Сборка → Собрать решение** (Ctrl+Shift+B). Ошибки — в окне **Вид → Список ошибок**; полный журнал — **Вид → Вывод** («Показать выходные данные из: Сборка»).
6. DLL: `src\KDetector.Plugin\bin\Release\KDetector.dll`.
7. NuGet-пакеты восстанавливаются автоматически при сборке (или правый клик по решению → «Восстановить пакеты NuGet»).

Чтобы DLL копировалась в игру после каждой сборки: `dotnet build … -p:CopyToGame=true`.
