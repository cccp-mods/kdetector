# KDetector by CCCP_MODS (tg: @cccp_mods) — Этап 1: исследование и проверка совместимости

Дата проверки: 2026-10-12
Метод: чтение публичных README/релизов и исходного кода (shallow clone) BetterAmongUs и MalumMenu, официальная документация BepInEx, проверка доступности инструментов сборки в рабочем окружении.

> Правило документа: каждое утверждение помечено уровнем подтверждения.
> **[✔ код]** — увидено в исходном коде публичного репозитория;
> **[✔ док]** — указано в официальной документации/README/релизе;
> **[? проверить]** — требует проверки по interop-сборкам установленной игры;
> **[✖]** — не подтверждено / неприменимо.

---

## 1. Целевая среда (самое важное для сборки)

| Параметр | Значение | Подтверждение |
|---|---|---|
| Актуальная версия Among Us | **2026.9.29** (MalumMenu называет её «19») | [✔ док] релиз BAU v1.3.4 (29.09.2026), README MalumMenu v3.3.1 |
| Архитектура Steam-версии | **x64** — Steam-клиент перешёл с 32 на 64 бит в 2026.9.29 | [✔ док] релиз BAU v1.3.4 |
| Варианты дистрибуции | Steam/itch.io и Epic/Microsoft Store — разные сборки BAU | [✔ док] README BAU |
| Вариант BepInEx | **BepInEx 6 Bleeding Edge, Unity.IL2CPP-win-x64**; BAU требует be.735 или новее | [✔ док] docs.bepinex.dev, релиз BAU v1.3.3 |
| Пакет BepInEx для компиляции | `BepInEx.Unity.IL2CPP` 6.0.0-be.735 (только compile-time, `ExcludeAssets="runtime;native"`) | [✔ код] BetterAmongUs.csproj |
| Игровые сборки для компиляции | NuGet-пакет `AmongUs.GameLibs.Steam` 2026.9.29 (interop-сборки, без копирования из игры) | [✔ код] BetterAmongUs.csproj |
| Генерация reference-сборок | `BepInEx.IL2CPP.MSBuild` 2.0.1 | [✔ код] |
| NuGet-источники | nuget.org, `https://nuget.bepinex.dev/v3/index.json`, `https://nuget.samboy.dev/v3/index.json` | [✔ код] nuget.config BAU |
| Target Framework | **net6.0** (рантайм BepInEx IL2CPP — CoreCLR .NET 6) | [✔ код] csproj BAU; [? проверить] для be.7xx |
| .NET SDK | SDK 9.x компилирует net6.0 (BAU фиксирует 9.0.312 с rollForward latestMajor) | [✔ код] global.json BAU |
| Базовый класс плагина | `BasePlugin` + `[BepInPlugin]` + `[BepInProcess]`, метод `Load()` | [✔ код] BAUPlugin.cs |
| Harmony | Встроен в BepInEx (HarmonyX), атрибуты `[HarmonyPatch]`, `[HarmonyPrefix]` | [✔ код] |
| Логи BepInEx | `BepInEx/LogOutput.log` (BAU пишет туда) / `LogOutput.txt` по документации | [✔ док] — имя файла зависит от сборки BepInEx |
| Конфиг BepInEx | `BepInEx/config/*.cfg` | [✔ док] |

**Вывод для KDetector:** net6.0, BepInEx 6 be.735+, x64, ссылки через `AmongUs.GameLibs.Steam` 2026.9.29. Для Epic/MS Store нужен отдельный пакет GameLibs (имя пакета [? проверить]).

### Окружение текущей сессии
- .NET SDK: **отсутствует**.
- nuget.org, nuget.bepinex.dev, builds.dotnet.microsoft.com: **заблокированы политикой сети** (HTTP 403 от прокси).
- Следствие: **скомпилировать KDetector.dll в этой сессии невозможно**. Код будет написан и проверен на уровне структуры; реальная сборка — через `build.ps1` на машине пользователя. Фиктивная DLL создаваться не будет.

---

## 2. Подтверждённые точки интеграции с игрой

Имена ниже взяты из кода BAU, который компилируется против GameLibs 2026.9.29. Это сильное подтверждение существования API, но сигнатуры всё равно сверяются с interop-сборками при первой сборке ([? проверить] сигнатуры).

| Назначение | API | Где увидено |
|---|---|---|
| Входящие RPC объекта | `InnerNetObject.HandleRpc(byte callId, MessageReader reader)`; подтипы `PlayerControl`, `PlayerPhysics`, `CustomNetworkTransform` | NetworkManager.cs |
| Весь входящий поток GameData | `InnerNetClient.HandleGameData(MessageReader)` | InnerNetClientPatch.cs |
| Исходящий поток | `InnerNetClient.SendOrDisconnect(MessageWriter)` | InnerNetClientPatch.cs |
| Саботажи/системы | `ShipStatus.UpdateSystem(SystemTypes, PlayerControl, MessageReader)` | NetworkManager.cs |
| Платформа клиента | `PlatformSpecificData.Deserialize` (postfix), поля `Platform`, `XboxPlatformId`, `PsnPlatformId`; enum `Platforms` | PlatformSpoofPatch.cs |
| Данные клиента | `ClientData.PlatformData` (через `GetClient()`) | PlatformSpoofPatch.cs |
| Уровень игрока | `NetworkedPlayerInfo.PlayerLevel` (0-based, в UI показывается +1); RPC `RpcCalls.SetLevel` | PlayerInfoDisplay.cs, SetLevelHandler.cs |
| Идентификаторы | `NetworkedPlayerInfo.FriendCode`, `NetworkedPlayerInfo.Puid` | PlayerControlUtils.cs |
| Kick / Ban (хост) | `AmongUsClient.Instance.KickPlayer(int clientId, bool ban)`; `InnerNetClient.CanKick/CanBan` | PlayerControlUtils.cs |
| Чат-команды | `ChatController.SendChat` (prefix) | ChatCommandsPatch.cs |
| Голосование за кик | `VoteBanSystem.AddVote` | VoteBanSystemPatch.cs |
| Инициализация игрока | `PlayerControl.ClientInitialize` | InitializePlayerTimeoutPatch.cs |
| Официальная жалоба | `ReportPlayer(ReportReasons.Cheating_Hacking)` (через обёртку BAU; исходный метод [? проверить]) | Cheats/*.cs |

### Выбор точки перехвата RPC для KDetector
BAU полностью заменяет `HandleGameData` собственным диспетчером. Это даёт полный контроль, но очень хрупко при обновлениях игры и конфликтует с другими модами, патчащими тот же метод.

KDetector будет использовать **менее инвазивный путь**: prefix на `HandleRpc` конкретных типов (`PlayerControl`, `PlayerPhysics`, `CustomNetworkTransform`) и на `ShipStatus.UpdateSystem`. Возврат `false` из prefix отменяет обработку только одного RPC. Перед применением каждого патча — проверка существования метода через `AccessTools`; при отсутствии модуль отключается с сообщением в Diagnostics.

[? проверить]: в IL2CPP `HandleRpc` — переопределённый virtual-метод; нужно убедиться, что у каждого подтипа есть собственная реализация в interop-сборке (иначе патчится базовый метод).

---

## 3. BetterAmongUs — сводка

- Репозиторий: https://github.com/D1GQ/BetterAmongUs, лицензия **GPL-3.0**. Последний релиз **v1.3.4** (29.09.2026), AU 2026.9.29.
- Код не копируется. Ниже — только поведение и факты (идентификаторы протокола, имена API игры). Если KDetector когда-либо заимствует код BAU, KDetector обязан распространяться под GPL-3.0.
- Важные особенности поведения BAU, которые KDetector **сознательно не повторяет**:
  - BAU помечает игрока как подменяющего платформу при **одном** признаке (неизвестная платформа или длина Xbox/PSN ID вне диапазона) и сразу отправляет официальную жалобу. KDetector трактует это как наблюдение средней уверенности без автоматических наказаний.
  - BAU по умолчанию флагает уровень выше порога (`DetectedLevelAbove`). KDetector не считает сам уровень доказательством.
  - BAU загружает списки и объявления с GitHub. KDetector не делает внешних сетевых запросов.

---

## 4. Публично известные чит-клиенты

Ключевой вывод: **из клиентского плагина видна только сетевая активность** (RPC, данные объектов, метаданные клиента). Ни файлы, ни память чужих устройств недоступны. Клиент «распознаётся» только если он сам отправляет уникальное сообщение.

### 4.1. Таблица кандидатов

| Семейство | Версии AU | Наблюдаемый признак | Проверяемо из плагина | Достоверность | Риск ложного срабатывания / обхода | Источник |
|---|---|---|---|---|---|---|
| **MalumMenu** v3.3.1 | 2026.9.29 (и ранее, см. README) | **Уникального handshake-RPC нет.** Видны только последствия: поток RPC `Pet` через `SendOption.None` («Overload»), `MurderPlayer` вне правил, `SnapTo`, `UpdateSystem` (саботажи), `ProtectPlayer`, `CompleteTask`, `StartMeeting`, `VotingComplete`, подмена `Platforms` через конфиг | Да, как **поведение** | Идентификация клиента: **нет**. Недопустимые действия: средняя–высокая | Подмена платформы выбирает **корректное** значение enum, поэтому Invalid Platform её не видит. Флуд Pet легко отличить от нормы по частоте | [✔ код] MalumMenu src |
| **SickoMenu** | данные BAU | Пользовательский RPC id 420 → байт **164** | Да (тип RPC) | Средняя: другой мод может использовать тот же id | Коллизия id с легитимными модами | [✔ код] BAU CustomRPC.cs, не проверено по коду SickoMenu |
| **AUM (Among Us Menu)** | данные BAU | RPC id 42069 → байт **85**, первый байт = PlayerId отправителя; чат-RPC **101** | Да | Средняя | Коллизия id | [✔ код] BAU |
| **KillNetwork** | данные BAU | RPC **250**, чат-RPC **119** | Да | Средняя | Коллизия id | [✔ код] BAU |
| **ModMenuCrew** | данные BAU | RPC **202**, чат-RPC **201** (структура: tag, packed senderId, name, content, timestamp, type) | Да | Средняя–высокая при совпадении структуры и senderId | Коллизия id | [✔ код] BAU |

Версия правил: `known-clients@2026.10.12-r1`. Все id хранятся в редактируемом файле сигнатур, привязанном к версии игры; ни одна сигнатура не захардкожена в логике.

### 4.2. Принцип KDetector для Known Clients
1. Совпадение id RPC → событие «Known client indicator», **не** «подтверждённый читер».
2. Совпадение id + совпадение структуры payload + согласованный senderId → уверенность повышается.
3. Сигнатура отключается, если игрок/лобби помечены как модифицированные (modded protocol), чтобы не ловить легитимные моды.
4. MalumMenu: модуль Known Clients его **не идентифицирует**; его действия ловят RPC Shield и Invalid Action Detector. В GUI так и пишется.

---

## 5. Платформы и Starlight

- `Platforms` — enum игры; проверка допустимости через `Enum.IsDefined` по текущим interop-сборкам [✔ код].
- **Starlight** (Android-лаунчер модов) отправляет нестандартный id платформы **112**. BAU в v1.3.4 исправил ложные срабатывания на нём [✔ код/док]. KDetector держит 112 в allowlist по умолчанию с меткой «Starlight (custom)».
- Xbox/MS Store: BAU ожидает длину `XboxPlatformId` 10–16 цифр, PSN 14–20 [✔ код BAU]. Это эвристика стороннего проекта, а не спецификация. KDetector использует её как сигнал низкой–средней уверенности и делает диапазоны настраиваемыми.
- Заявленная платформа не доказывает реальное устройство: MalumMenu позволяет выбрать любую корректную платформу [✔ код].

## 6. Уровень

- Хранится как `PlayerLevel` (0-based), приходит через `RpcCalls.SetLevel` [✔ код].
- Реальный уровень аккаунта клиентский плагин **проверить не может** — сервер не даёт такого API клиенту [✖ подтверждённого API нет].
- Что KDetector реально проверяет: формат/диапазон значения, повторные `SetLevel` за одно подключение, изменения уровня внутри сессии.

## 7. RPC Shield: исследованные векторы спама

| Вектор | Объект | Признак | Безопасна ли отмена |
|---|---|---|---|
| Pet-флуд («Overload») | `PlayerPhysics` | десятки–сотни `Pet` в одном пакете, `SendOption.None` | Да, отмена `Pet`/`CancelPet` не влияет на исход матча [? проверить в игре] |
| Повторные `UpdateSystem` (саботажи) | `ShipStatus` | частота, саботаж от не-импостора, саботаж в собрании | Только для доказанно недопустимых случаев; иначе — наблюдение |
| Чат-флуд | `PlayerControl` | `SendChat`/`SendQuickChat` с высокой частотой | Да (скрытие сообщения) |
| Косметика-флуд | `PlayerControl` | `SetHatStr`/`SetSkinStr`/… вне лобби или очень часто | Да |
| `MurderPlayer`, `StartMeeting`, `SetRole` от не-хоста | `PlayerControl` | host-only RPC от клиента | Отмена у не-хоста может вызвать рассинхрон → по умолчанию только наблюдение |

Значения лимитов по умолчанию будут консервативными и подобраны в Dry Run.

---

## 8. Хостовые полномочия

- Kick/Ban: `AmongUsClient.Instance.KickPlayer(clientId, ban)` — работает только у хоста [✔ код].
- «Ban» здесь — бан в текущем лобби (сервер не пускает игрока обратно в эту комнату). Глобального бана **нет**.
- Официальная жалоба (`Cheating_Hacking`) — доступна любому игроку; KDetector делает её только по ручному действию.

## 9. Открытые вопросы (проверяются при первой сборке на машине пользователя)

1. Точные сигнатуры `HandleRpc` у подтипов в GameLibs 2026.9.29.
2. Имя пакета GameLibs для Epic/MS Store.
3. Имя лог-файла BepInEx в be.735+ (`LogOutput.log` vs `LogOutput.txt`).
4. Наличие `ReportPlayer` как метода игры (а не обёртки BAU).
5. Поведение игры при отмене `Pet`/`CancelPet` у не-хоста.

## 10. Дополнение после реализации (2026-10-12)

### MalumMenu: механизм подмены (по исходному коду v3.3.1)
- **Платформа**: постфикс на `Constants.GetPlatformData` возвращает новый `PlatformSpecificData` только с `Platform` и `PlatformName`; `XboxPlatformId`/`PsnPlatformId` остаются 0. Отсюда проверяемый признак: заявлена Xbox/MS Store/PlayStation, а ID консоли = 0 → `platform.console-id-mismatch` (уверенность 0.65). При подмене на ПК-платформу признака нет.
- **Уровень**: меняется локально сохранённая статистика (`DataManager.Player.stats.level`) — это обычное корректное значение, клиентом не отличимое от настоящего.
- **Friend Code**: «гостевой» режим подставляет другой код — поэтому база сопоставляет игроков в первую очередь по HashPuid, а при расхождении PUID записи не объединяются.

### Подтверждённые API (по коду модов, компилирующихся против 2026.9.29)
`NetworkedPlayerInfo.ClientId`, `AmongUsClient.Instance.HostId/ClientId/GameId`, `GameCode.IntToGameName(int)`, `ChatController.freeChatField.Clear()`,
`HudManager.Instance.Chat.AddChat(PlayerControl, string, bool)`, `HudManager.InstanceExists`, `ChatController.IsOpenOrOpening`,
`PassiveButton.ReceiveClickDown/ReceiveClickUp/ReceiveMouseOver`, IMGUI: `GUI.Window` + `GUI.WindowFunction`, `GUILayout.Label/Button/Box` со стилем,
`BeginVertical(GUIStyle, …)`, `BeginScrollView(Vector2, bool, bool)`, `HorizontalSlider`, `GUI.backgroundColor/contentColor`, `GUIStyle.normal.background`,
`Texture2D(int,int,TextureFormat,bool)` + `SetPixels` + `Apply`, `Input.inputString/mousePosition/GetMouseButtonDown/GetKey(Down)`, `GUIUtility.systemCopyBuffer`.
Rich-text `<color>` в стандартных стилях работает (используется в MalumMenu).
**Не подтверждены и не используются**: `GUILayout.TextField`, `GUIStyleState.textColor`, `GUI.Box(Rect, …)`, `GUI.matrix`, `Event.current`.

### Проверки, выполненные в среде разработки
- Ядро и тесты: собраны .NET SDK 8.0.131 (Ubuntu archive), **132/132 теста**.
- Плагин: собран в режиме Local против **настоящих** `BepInEx.Core`, `BepInEx.Unity.IL2CPP`, `0Harmony`, `Il2CppInterop.Runtime` (BepInEx 6.0.0-pre.2 IL2CPP x64 с GitHub) и **заглушек** сигнатур игры/Unity, составленных по коду модов выше: 0 ошибок, 0 предупреждений. DLL не распространяется — заглушки не являются игровыми сборками.
- Стенд «склеивающего» кода (36 проверок): `ConfigBinder` на настоящем `BepInEx.Configuration.ConfigFile`, поиск целей патчей через настоящий `AccessTools`, логика префиксов RPC и чата, трекер игроков, Kick/Ban. Применение Harmony-детуров в стенде невозможно (MonoMod из pre.2 не поддерживает .NET 8 на Linux) — в игре патчи ставит BepInEx на своём .NET 6.

### Статус открытых вопросов
| # | Вопрос | Статус |
|---|---|---|
| 1 | Сигнатуры `HandleRpc` у подтипов | Код использует `AccessTools.DeclaredMethod(type, "HandleRpc", byte, MessageReader)`; если у типа нет своего метода — модуль отключается с сообщением. Проверяется при первом запуске (Diagnostics). |
| 2 | Пакет GameLibs для Epic/MS Store | Обойдено: сборка по умолчанию идёт против interop-сборок из папки игры пользователя (режим Local). |
| 3 | Имя лог-файла BepInEx | Документация упоминает оба варианта; KDetector дополнительно пишет свой журнал `plugins/KDetector/Logs/KDetector.log`. |
| 4 | `ReportPlayer` как метод игры | Не используется (официальная жалоба не реализована). |
| 5 | Безопасность отмены `Pet`/`CancelPet` у не-хоста | По коду игры не проверялось; отмена визуальной анимации не влияет на состояние матча. Проверить в приватном лобби (Dry Run → обычный режим). |

## Источники
- BetterAmongUs: https://github.com/D1GQ/BetterAmongUs, релизы: https://github.com/D1GQ/BetterAmongUs/releases
- BepInEx IL2CPP: https://docs.bepinex.dev/master/articles/user_guide/installation/unity_il2cpp.html
- MalumMenu: https://github.com/scp222thj/MalumMenu
