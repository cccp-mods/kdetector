using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Game;
using KDetector.Core.Logging;
using KDetector.Core.Players;
using KDetector.Core.Risk;

namespace KDetector.Core.Actions;

/// <summary>Действия хоста. Реализация в игровом слое проверяет полномочия в момент вызова.</summary>
public interface IHostActions
{
    /// <summary>Проверка прямо сейчас: локальный клиент — хост онлайн-лобби.</summary>
    bool LocalIsHostNow();

    /// <summary>Доступна ли операция в текущей версии игры (API найден).</summary>
    bool KickAvailable { get; }

    /// <summary>Выполнить Kick/Ban. Возвращает false и причину, если не удалось.</summary>
    bool TryKick(int clientId, bool ban, out string error);
}

public enum NotifyLevel
{
    Info,
    Warning,
    Alert,
}

public interface INotifier
{
    void Notify(NotifyLevel level, string title, string text);
}

/// <summary>Операции с базой, нужные движку действий (реализует DatabaseService).</summary>
public interface IDetectionStore
{
    void RecordEvent(DetectionEvent evt);
    void SetWatchlist(PlayerIdentity player, string sessionId, bool value);
    void RecordAction(PlayerIdentity player, string sessionId, string action, string outcome, string reason);
}

public interface IReportWriter
{
    string? Write(PlayerIdentity player, RiskAssessment risk, IReadOnlyList<DetectionEvent> events);
}

public enum ActionOutcome
{
    Executed,
    DryRun,
    Skipped,
    Failed,
}

public sealed class ActionRecord
{
    public DateTime Utc { get; set; }
    public string PlayerName { get; set; } = string.Empty;
    public string PlayerKey { get; set; } = string.Empty;
    public int ClientId { get; set; } = -1;
    public ActionKind Kind { get; set; }
    public string RuleId { get; set; } = string.Empty;
    public ActionOutcome Outcome { get; set; }
    public string Reason { get; set; } = string.Empty;
    public bool Automatic { get; set; } = true;
}

public sealed class ReviewItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime Utc { get; set; }
    public PlayerIdentity Player { get; set; } = new();
    public string PlayerKey { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public int RiskScore { get; set; }
    public bool Resolved { get; set; }
}

/// <summary>
/// Централизованный выбор и выполнение реакций на события обнаружения.
/// Каждое действие проверяет: включено ли, уверенность, число независимых доказательств, риск, вид доказательства,
/// cooldown, whitelist, Dry Run, режим совместимости и — для Kick/Ban — полномочия хоста в момент выполнения.
/// </summary>
public sealed class ActionEngine
{
    private readonly KdSettings _settings;
    private readonly IClock _clock;
    private readonly KdLog _log;
    private readonly RiskModel _risk;
    private readonly Func<GameContext> _context;
    private readonly object _sync = new();
    private readonly Dictionary<string, DateTime> _cooldowns = new();
    private readonly HashSet<int> _inFlight = new();
    private DateTime _lastHostAction = DateTime.MinValue;
    private ActionPolicySet _custom;

    public ActionEngine(KdSettings settings, IClock clock, KdLog log, RiskModel risk, Func<GameContext> context, ActionPolicySet custom)
    {
        _settings = settings;
        _clock = clock;
        _log = log;
        _risk = risk;
        _context = context;
        _custom = custom;
        _custom.Normalize();
    }

    public IHostActions? Host { get; set; }
    public INotifier? Notifier { get; set; }
    public IDetectionStore? Store { get; set; }
    public IReportWriter? Reports { get; set; }
    public Func<string, IReadOnlyList<DetectionEvent>>? EventsForPlayer { get; set; }

    /// <summary>Отметка «подозрительный» для текущей сессии.</summary>
    public HashSet<string> MarkedSuspicious { get; } = new();

    public KDetector.Core.Common.RingBuffer<ActionRecord> History { get; } = new(500);
    public List<ReviewItem> ReviewQueue { get; } = new();

    /// <summary>Режим совместимости запрещает вмешательство (неподдерживаемая версия игры).</summary>
    public bool EnforcementBlockedByCompatibility { get; set; }

    public string EnforcementBlockReason { get; set; } = string.Empty;

    public ActionPolicySet CustomPolicy
    {
        get => _custom;
        set
        {
            _custom = value;
            _custom.Normalize();
        }
    }

    public ActionPolicySet ActivePolicy =>
        _settings.General.Profile == ActionProfileName.Custom ? _custom : ActionProfiles.Get(_settings.General.Profile);

    private bool DryRun => _settings.General.DryRun;

    /// <summary>
    /// Синхронное решение об отмене RPC (вызывается из сетевого префикса).
    /// Возвращает true, если отменить можно и нужно.
    /// </summary>
    public bool ShouldCancel(DetectionCandidate candidate, DetectionCategory category, bool whitelisted, out string reason)
    {
        reason = string.Empty;
        if (!candidate.Cancelable)
        {
            reason = "правило не разрешает отмену";
            return false;
        }

        if (whitelisted)
        {
            reason = "игрок в whitelist";
            return false;
        }

        if (EnforcementBlockedByCompatibility)
        {
            reason = "режим совместимости: только наблюдение";
            return false;
        }

        var rule = ActivePolicy.For(candidate.RuleId, category).FirstOrDefault(a => a.Kind == ActionKind.CancelRpc && a.Enabled);
        if (rule == null)
        {
            reason = "отмена не включена в профиле";
            return false;
        }

        if (candidate.Confidence < rule.MinConfidence)
        {
            reason = $"уверенность {candidate.Confidence:0.00} ниже порога отмены {rule.MinConfidence:0.00}";
            return false;
        }

        if (rule.EvidenceKinds.Count > 0 && !rule.EvidenceKinds.Contains(candidate.Evidence))
        {
            reason = "вид доказательства не допускает отмену в профиле";
            return false;
        }

        if (DryRun || (category == DetectionCategory.RpcSpam && _settings.RpcShield.DryRun))
        {
            reason = "Dry Run: была бы отменена";
            return false;
        }

        reason = "отменено";
        return true;
    }

    /// <summary>Обработка зарегистрированного события (подписчик DetectionEngine).</summary>
    public void Handle(DetectionEvent evt)
    {
        var policy = ActivePolicy.For(evt.RuleId, evt.Category);
        var risk = _risk.Assess(evt.PlayerKey);
        evt.RecommendedAction = Recommend(policy, evt, risk);

        foreach (var rule in policy)
        {
            if (!rule.Enabled || rule.Kind == ActionKind.CancelRpc) continue;

            try
            {
                if (!ConditionsMet(rule, evt, risk, out var why))
                {
                    if (rule.Kind is ActionKind.Kick or ActionKind.Ban && _settings.Logging.DiagnosticMode)
                        _log.Debug("Actions", $"{rule.Kind} для {evt.Player.Display} не применён: {why}");
                    continue;
                }

                if (evt.Whitelisted && rule.Kind is not (ActionKind.Log or ActionKind.RecordDatabase))
                    continue;

                if (!PassCooldown(rule, evt)) continue;
                Execute(rule, evt, risk);
            }
            catch (Exception ex)
            {
                _log.Error("Actions", $"Действие {rule.Kind} завершилось с ошибкой", ex);
            }
        }
    }

    private bool ConditionsMet(ActionRule rule, DetectionEvent evt, RiskAssessment risk, out string why)
    {
        why = string.Empty;
        if (evt.Confidence < rule.MinConfidence)
        {
            why = $"уверенность {evt.Confidence:0.00} < {rule.MinConfidence:0.00}";
            return false;
        }

        if (rule.EvidenceKinds.Count > 0 && !rule.EvidenceKinds.Contains(evt.Evidence))
        {
            why = "вид доказательства не подходит";
            return false;
        }

        if (risk.IndependentEvidence < rule.MinIndependentEvidence)
        {
            why = $"независимых доказательств {risk.IndependentEvidence} < {rule.MinIndependentEvidence}";
            return false;
        }

        if (risk.Score < rule.MinRiskScore)
        {
            why = $"риск {risk.Score} < {rule.MinRiskScore}";
            return false;
        }

        if (rule.RequireConfirmedViolation && risk.ConfirmedViolations == 0)
        {
            why = "нет подтверждённых нарушений (только подозрения)";
            return false;
        }

        return true;
    }

    private bool PassCooldown(ActionRule rule, DetectionEvent evt)
    {
        var seconds = rule.CooldownSeconds;
        if (rule.Kind == ActionKind.Notify) seconds = Math.Max(seconds, _settings.Notifications.CooldownSeconds);
        if (seconds <= 0) return true;

        var key = $"{rule.Kind}|{evt.PlayerKey}|{(rule.Kind == ActionKind.Notify ? evt.RuleId : string.Empty)}";
        var now = _clock.UtcNow;
        lock (_sync)
        {
            if (_cooldowns.TryGetValue(key, out var until) && until > now) return false;
            _cooldowns[key] = now.AddSeconds(seconds);
            if (_cooldowns.Count > 5000)
                foreach (var k in _cooldowns.Where(p => p.Value < now).Select(p => p.Key).ToList())
                    _cooldowns.Remove(k);
        }

        return true;
    }

    private void Execute(ActionRule rule, DetectionEvent evt, RiskAssessment risk)
    {
        var dry = DryRun;
        var prefix = dry ? "[Dry Run] " : string.Empty;
        switch (rule.Kind)
        {
            case ActionKind.Log:
                _log.Info("Detection", $"{prefix}{evt.Player.Display} [{evt.RuleId}] {evt.Summary} (уверенность {evt.Confidence:0.00}, риск {risk.Score})");
                break;

            case ActionKind.Notify:
                if (!_settings.Notifications.Enabled || evt.Severity < _settings.Notifications.MinSeverity) break;
                Notifier?.Notify(evt.Severity >= Severity.High ? NotifyLevel.Alert : NotifyLevel.Warning,
                    $"{prefix}{evt.Player.Display}: {DetectionText.Category(evt.Category)}", evt.Summary);
                Record(evt, ActionKind.Notify, ActionOutcome.Executed, string.Empty);
                break;

            case ActionKind.MarkSuspicious:
                lock (_sync) MarkedSuspicious.Add(evt.PlayerKey);
                break;

            case ActionKind.Watchlist:
                Store?.SetWatchlist(evt.Player, evt.SessionId, true);
                Record(evt, ActionKind.Watchlist, ActionOutcome.Executed, "добавлен в watchlist");
                break;

            case ActionKind.RecordDatabase:
                Store?.RecordEvent(evt);
                break;

            case ActionKind.RequestHostReview:
                AddReview(evt, risk);
                break;

            case ActionKind.Report:
                {
                    var path = Reports?.Write(evt.Player, risk, EventsForPlayer?.Invoke(evt.PlayerKey) ?? new[] { evt });
                    Record(evt, ActionKind.Report, path != null ? ActionOutcome.Executed : ActionOutcome.Failed, path ?? "не удалось записать отчёт");
                    break;
                }

            case ActionKind.Kick:
            case ActionKind.Ban:
                AutoHostAction(rule.Kind == ActionKind.Ban, evt, risk, dry);
                break;
        }
    }

    private void AutoHostAction(bool ban, DetectionEvent evt, RiskAssessment risk, bool dry)
    {
        var kind = ban ? ActionKind.Ban : ActionKind.Kick;
        var allowed = ban ? _settings.AutoActions.AllowAutoBan : _settings.AutoActions.AllowAutoKick;
        if (!allowed)
        {
            // Автоматика выключена — предлагаем хосту рассмотреть вручную, ничего не выполняя.
            AddReview(evt, risk);
            Record(evt, kind, ActionOutcome.Skipped, ban ? "автобан выключен (AllowAutoBan=false), добавлено в очередь рассмотрения" : "автокик выключен (AllowAutoKick=false), добавлено в очередь рассмотрения");
            return;
        }

        if (EnforcementBlockedByCompatibility)
        {
            Record(evt, kind, ActionOutcome.Skipped, "режим совместимости: " + EnforcementBlockReason);
            return;
        }

        var now = _clock.UtcNow;
        lock (_sync)
        {
            if ((now - _lastHostAction).TotalSeconds < _settings.AutoActions.HostActionCooldownSeconds)
            {
                Record(evt, kind, ActionOutcome.Skipped, "глобальная пауза между автоматическими Kick/Ban");
                return;
            }
        }

        if (dry)
        {
            Record(evt, kind, ActionOutcome.DryRun, $"был бы выполнен {kind} (риск {risk.Score}, независимых доказательств {risk.IndependentEvidence})");
            Notifier?.Notify(NotifyLevel.Alert, $"[Dry Run] {kind}: {evt.Player.Display}", $"Риск {risk.Score}. Действие не выполнено (Dry Run).");
            return;
        }

        if (TryHostAction(evt.Player, ban, automatic: true, evt.RuleId, $"риск {risk.Score}: {evt.Summary}", out var error))
        {
            lock (_sync) _lastHostAction = now;
            Notifier?.Notify(NotifyLevel.Alert, $"{kind}: {evt.Player.Display}", $"Автоматически. Риск {risk.Score}.");
        }
        else
        {
            _log.Warn("Actions", $"Автоматический {kind} {evt.Player.Display} не выполнен: {error}");
        }
    }

    /// <summary>
    /// Kick/Ban (ручной или автоматический). Полномочия хоста проверяются здесь, непосредственно перед вызовом.
    /// Защита от повторного запуска: один и тот же клиент не может обрабатываться одновременно.
    /// </summary>
    public bool TryHostAction(PlayerIdentity target, bool ban, bool automatic, string ruleId, string reason, out string error)
    {
        var kind = ban ? ActionKind.Ban : ActionKind.Kick;
        error = string.Empty;
        var ctx = _context();

        if (Host == null || !Host.KickAvailable)
            error = "операция недоступна в текущей версии игры";
        else if (!Host.LocalIsHostNow())
            error = "вы не хост этого лобби";
        else if (target.IsLocal)
            error = "нельзя применить к себе";
        else if (target.IsHost)
            error = "нельзя применить к хосту";
        else if (target.ClientId < 0)
            error = "игрок не найден в лобби";

        if (error.Length == 0)
        {
            lock (_sync)
            {
                if (!_inFlight.Add(target.ClientId)) error = "действие уже выполняется";
            }
        }

        if (error.Length > 0)
        {
            History.Add(new ActionRecord
            {
                Utc = _clock.UtcNow, PlayerName = target.Display, PlayerKey = target.Key(ctx.SessionId), ClientId = target.ClientId,
                Kind = kind, RuleId = ruleId, Outcome = ActionOutcome.Skipped, Reason = error, Automatic = automatic,
            });
            return false;
        }

        try
        {
            var ok = Host!.TryKick(target.ClientId, ban, out var hostError);
            var outcome = ok ? ActionOutcome.Executed : ActionOutcome.Failed;
            History.Add(new ActionRecord
            {
                Utc = _clock.UtcNow, PlayerName = target.Display, PlayerKey = target.Key(ctx.SessionId), ClientId = target.ClientId,
                Kind = kind, RuleId = ruleId, Outcome = outcome, Reason = ok ? reason : hostError, Automatic = automatic,
            });
            Store?.RecordAction(target, ctx.SessionId, kind.ToString(), outcome.ToString(), ok ? reason : hostError);
            _log.Info("Actions", $"{(automatic ? "Авто" : "Ручной")} {kind} {target.Display}: {outcome} ({(ok ? reason : hostError)})");
            error = hostError;
            return ok;
        }
        finally
        {
            lock (_sync) _inFlight.Remove(target.ClientId);
        }
    }

    private void AddReview(DetectionEvent evt, RiskAssessment risk)
    {
        lock (_sync)
        {
            var existing = ReviewQueue.FirstOrDefault(r => !r.Resolved && r.PlayerKey == evt.PlayerKey);
            if (existing != null)
            {
                existing.RiskScore = risk.Score;
                existing.Reason = evt.Summary;
                existing.Utc = evt.TimestampUtc;
                return;
            }

            ReviewQueue.Add(new ReviewItem
            {
                Utc = evt.TimestampUtc, Player = evt.Player.Clone(), PlayerKey = evt.PlayerKey, Reason = evt.Summary, RiskScore = risk.Score,
            });
            if (ReviewQueue.Count > 100) ReviewQueue.RemoveAt(0);
        }

        var ctx = _context();
        var who = ctx.LocalIsHost ? "Рассмотрите удаление игрока" : "Вы не хост: можно сообщить хосту";
        Notifier?.Notify(NotifyLevel.Warning, $"Требует рассмотрения: {evt.Player.Display}", $"{who}. Риск {risk.Score}. {evt.Summary}");
    }

    public void ResolveReview(Guid id)
    {
        lock (_sync)
        {
            var item = ReviewQueue.FirstOrDefault(r => r.Id == id);
            if (item != null) item.Resolved = true;
        }
    }

    private void Record(DetectionEvent evt, ActionKind kind, ActionOutcome outcome, string reason)
    {
        History.Add(new ActionRecord
        {
            Utc = _clock.UtcNow, PlayerName = evt.Player.Display, PlayerKey = evt.PlayerKey, ClientId = evt.Player.ClientId,
            Kind = kind, RuleId = evt.RuleId, Outcome = outcome, Reason = reason,
        });
    }

    private string Recommend(List<ActionRule> policy, DetectionEvent evt, RiskAssessment risk)
    {
        if (evt.Whitelisted) return "Игрок в whitelist — только запись";
        var strongest = policy.Where(a => a.Enabled && a.Kind != ActionKind.Log && ConditionsMet(a, evt, risk, out _))
            .Select(a => a.Kind).DefaultIfEmpty(ActionKind.Log).OrderByDescending(Priority).First();
        return strongest switch
        {
            ActionKind.Ban => "Бан (хост)",
            ActionKind.Kick => "Исключение (хост)",
            ActionKind.Report => "Отчёт",
            ActionKind.RequestHostReview => "Ручное рассмотрение",
            ActionKind.CancelRpc => "Отмена RPC",
            ActionKind.RecordDatabase => "Запись в базу",
            ActionKind.Watchlist => "Watchlist",
            ActionKind.MarkSuspicious => "Отметить",
            ActionKind.Notify => "Уведомление",
            _ => "Журнал",
        };
    }

    private static int Priority(ActionKind k) => k switch
    {
        ActionKind.Ban => 10,
        ActionKind.Kick => 9,
        ActionKind.RequestHostReview => 8,
        ActionKind.Report => 7,
        ActionKind.CancelRpc => 6,
        ActionKind.Watchlist => 5,
        ActionKind.RecordDatabase => 4,
        ActionKind.MarkSuspicious => 3,
        ActionKind.Notify => 2,
        _ => 1,
    };

    public void ResetSession()
    {
        lock (_sync)
        {
            MarkedSuspicious.Clear();
            _inFlight.Clear();
            ReviewQueue.RemoveAll(r => r.Resolved);
        }
    }
}
