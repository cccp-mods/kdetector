using KDetector.Core.Configuration;
using KDetector.Core.Detection;

namespace KDetector.Core.Actions;

public enum ActionKind
{
    /// <summary>Записать в журнал.</summary>
    Log,

    /// <summary>Показать уведомление.</summary>
    Notify,

    /// <summary>Отметить игрока подозрительным в текущей сессии.</summary>
    MarkSuspicious,

    /// <summary>Добавить в watchlist (сохраняется в базе).</summary>
    Watchlist,

    /// <summary>Создать/обновить запись в базе.</summary>
    RecordDatabase,

    /// <summary>Отменить обработку недопустимого RPC (только безопасные случаи, проверенные правилом).</summary>
    CancelRpc,

    /// <summary>Поставить в очередь ручного рассмотрения (хост решает, удалять ли игрока).</summary>
    RequestHostReview,

    /// <summary>Автоматически исключить игрока (только хост, только при AllowAutoKick).</summary>
    Kick,

    /// <summary>Автоматически забанить в текущем лобби (только хост, только при AllowAutoBan).</summary>
    Ban,

    /// <summary>Сформировать текстовый отчёт в папке Reports.</summary>
    Report,
}

/// <summary>Условие применения одного действия.</summary>
public sealed class ActionRule
{
    public ActionKind Kind { get; set; }
    public bool Enabled { get; set; } = true;

    /// <summary>Минимальная уверенность события.</summary>
    public double MinConfidence { get; set; }

    /// <summary>Минимум независимых групп доказательств у игрока (включая текущее событие).</summary>
    public int MinIndependentEvidence { get; set; } = 1;

    /// <summary>Минимальная оценка риска игрока 0..100.</summary>
    public int MinRiskScore { get; set; }

    /// <summary>Пауза между повторами этого действия для одного игрока, секунд.</summary>
    public int CooldownSeconds { get; set; }

    /// <summary>Разрешённые виды доказательств. Пусто = любые.</summary>
    public List<EvidenceKind> EvidenceKinds { get; set; } = new();

    /// <summary>Поведение при конфликтующих данных: если у игрока есть только подозрения без подтверждённых нарушений — не применять.</summary>
    public bool RequireConfirmedViolation { get; set; }

    public ActionRule Clone()
    {
        var c = (ActionRule)MemberwiseClone();
        c.EvidenceKinds = EvidenceKinds.ToList();
        return c;
    }
}

public sealed class CategoryPolicy
{
    public DetectionCategory Category { get; set; }
    public List<ActionRule> Actions { get; set; } = new();
}

/// <summary>Набор политик (профиль). Переопределения по ruleId имеют приоритет над категорией.</summary>
public sealed class ActionPolicySet
{
    public int SchemaVersion { get; set; } = 1;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public List<CategoryPolicy> Categories { get; set; } = new();
    public Dictionary<string, List<ActionRule>> RuleOverrides { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public List<ActionRule> For(string ruleId, DetectionCategory category)
    {
        if (RuleOverrides.TryGetValue(ruleId, out var rules)) return rules;
        return Categories.FirstOrDefault(c => c.Category == category)?.Actions ?? new List<ActionRule>();
    }

    public ActionPolicySet Clone()
    {
        return new ActionPolicySet
        {
            SchemaVersion = SchemaVersion,
            Name = Name,
            Description = Description,
            Categories = Categories.Select(c => new CategoryPolicy { Category = c.Category, Actions = c.Actions.Select(a => a.Clone()).ToList() }).ToList(),
            RuleOverrides = RuleOverrides.ToDictionary(p => p.Key, p => p.Value.Select(a => a.Clone()).ToList(), StringComparer.OrdinalIgnoreCase),
        };
    }

    /// <summary>Гарантирует наличие политики для каждой категории (пустой — если отсутствует в файле).</summary>
    public void Normalize()
    {
        foreach (DetectionCategory cat in Enum.GetValues(typeof(DetectionCategory)))
            if (Categories.All(c => c.Category != cat))
                Categories.Add(new CategoryPolicy { Category = cat });
        Categories = Categories.OrderBy(c => c.Category).ToList();
    }
}

/// <summary>Встроенные профили. Ни один профиль не банит по одной метрике; автоматические Kick/Ban дополнительно требуют включения в настройках.</summary>
public static class ActionProfiles
{
    public static ActionPolicySet Get(ActionProfileName name) => name switch
    {
        ActionProfileName.Passive => Passive(),
        ActionProfileName.Strict => Strict(),
        _ => Balanced(),
    };

    private static ActionRule A(ActionKind kind, double conf = 0, int indep = 1, int risk = 0, int cooldown = 0, bool confirmed = false, params EvidenceKind[] kinds) => new()
    {
        Kind = kind,
        MinConfidence = conf,
        MinIndependentEvidence = indep,
        MinRiskScore = risk,
        CooldownSeconds = cooldown,
        RequireConfirmedViolation = confirmed,
        EvidenceKinds = kinds.ToList(),
    };

    private static ActionPolicySet Build(string name, string description, Func<DetectionCategory, List<ActionRule>> factory)
    {
        var set = new ActionPolicySet { Name = name, Description = description };
        foreach (DetectionCategory cat in Enum.GetValues(typeof(DetectionCategory)))
            set.Categories.Add(new CategoryPolicy { Category = cat, Actions = factory(cat) });
        return set;
    }

    /// <summary>Наблюдение и журналирование без наказаний и без отмены RPC.</summary>
    public static ActionPolicySet Passive() => Build("Passive", "Только журнал, база и уведомления. Ничего не отменяется и никто не удаляется.", _ => new List<ActionRule>
    {
        A(ActionKind.Log),
        A(ActionKind.RecordDatabase, 0.5),
        A(ActionKind.Notify, 0.7),
    });

    /// <summary>Уведомления, запись и отмена только надёжно подтверждённых недопустимых операций / безопасного флуда.</summary>
    public static ActionPolicySet Balanced() => Build("Balanced", "Уведомления, запись в базу, отмена флуда в безопасных категориях и подтверждённых недопустимых действий. Без Kick/Ban.", cat =>
    {
        var list = new List<ActionRule>
        {
            A(ActionKind.Log),
            A(ActionKind.Notify, 0.5),
            A(ActionKind.MarkSuspicious, 0.5),
            A(ActionKind.RecordDatabase, 0.5),
            A(ActionKind.Watchlist, 0.6, indep: 2, risk: 40),
            A(ActionKind.RequestHostReview, 0.6, indep: 2, risk: 55, cooldown: 120),
        };
        if (cat == DetectionCategory.RpcSpam) list.Add(A(ActionKind.CancelRpc, 0.4));
        if (cat == DetectionCategory.InvalidAction) list.Add(A(ActionKind.CancelRpc, 0.7, kinds: EvidenceKind.ConfirmedInvalidAction));
        return list;
    });

    /// <summary>Более строгие пороги; Kick/Ban в политике есть, но выполняются только при AllowAutoKick/AllowAutoBan и полномочиях хоста.</summary>
    public static ActionPolicySet Strict() => Build("Strict", "Ниже пороги, отмена всех безопасно отменяемых нарушений, автоматические Kick/Ban при нескольких независимых доказательствах (требуют включения в настройках).", cat =>
    {
        var list = new List<ActionRule>
        {
            A(ActionKind.Log),
            A(ActionKind.Notify, 0.35),
            A(ActionKind.MarkSuspicious, 0.35),
            A(ActionKind.RecordDatabase, 0.35),
            A(ActionKind.Watchlist, 0.5, indep: 1, risk: 30),
            A(ActionKind.RequestHostReview, 0.5, indep: 2, risk: 45, cooldown: 60),
            A(ActionKind.Report, 0.6, indep: 2, risk: 55, cooldown: 600),
            A(ActionKind.Kick, 0.75, indep: 2, risk: 70, cooldown: 30),
            A(ActionKind.Ban, 0.85, indep: 3, risk: 85, cooldown: 30, confirmed: true),
        };
        if (cat is DetectionCategory.RpcSpam) list.Add(A(ActionKind.CancelRpc, 0.3));
        if (cat is DetectionCategory.InvalidAction) list.Add(A(ActionKind.CancelRpc, 0.55));
        return list;
    });
}
