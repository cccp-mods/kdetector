using System.Globalization;
using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Players;
using KDetector.Core.Risk;

namespace KDetector.Core.Commands;

public sealed class CommandResult
{
    public static readonly CommandResult NotACommand = new() { Handled = false };

    public bool Handled { get; set; } = true;
    public List<string> Lines { get; } = new();

    public CommandResult Add(string line)
    {
        Lines.Add(line);
        return this;
    }
}

/// <summary>
/// Команды KDetector (/kd …). Обрабатываются локально: игровой слой не отправляет такие сообщения в чат лобби.
/// Опасные операции (удаление данных, бан) требуют подтверждения кодом в течение ограниченного времени.
/// </summary>
public sealed class CommandProcessor
{
    private readonly KDetectorCore _core;
    private readonly Random _random = new();
    private PendingConfirmation? _pending;

    public CommandProcessor(KDetectorCore core)
    {
        _core = core;
    }

    private KdSettings Settings => _core.Settings;

    public bool IsCommand(string? text)
    {
        if (!Settings.Commands.Enabled || string.IsNullOrWhiteSpace(text)) return false;
        var t = text!.TrimStart();
        var prefix = Settings.Commands.Prefix;
        return t.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) &&
               (t.Length == prefix.Length || char.IsWhiteSpace(t[prefix.Length]));
    }

    public CommandResult Execute(string text)
    {
        if (!IsCommand(text)) return CommandResult.NotACommand;
        var args = Tokenize(text.Trim().Substring(Settings.Commands.Prefix.Length));
        var result = new CommandResult();
        if (args.Count == 0) return Help(result);

        var cmd = args[0].ToLowerInvariant();
        args.RemoveAt(0);
        try
        {
            return cmd switch
            {
                "help" or "?" or "commands" => Help(result),
                "status" => Status(result),
                "players" => Players(result),
                "player" => Player(result, args),
                "detections" or "events" => Detections(result, args),
                "export" => Export(result),
                "remove" => Remove(result, args),
                "removeall" => RemoveAll(result),
                "confirm" => Confirm(result, args),
                "cancel" => CancelPending(result),
                "kick" => HostAction(result, args, false),
                "ban" => HostAction(result, args, true),
                "dryrun" => DryRun(result, args),
                "profile" => Profile(result, args),
                "whitelist" => Whitelist(result, args),
                "backup" => Backup(result),
                "shield" => Shield(result),
                _ => result.Add($"Неизвестная команда «{cmd}». {Settings.Commands.Prefix} help — список команд."),
            };
        }
        catch (Exception ex)
        {
            _core.Log.Error("Commands", $"Ошибка команды {cmd}", ex);
            return result.Add("Команда завершилась с ошибкой: " + ex.Message);
        }
    }

    public static List<string> Tokenize(string s)
    {
        var list = new List<string>();
        var cur = new System.Text.StringBuilder();
        var quoted = false;
        foreach (var ch in s)
        {
            if (ch == '"')
            {
                quoted = !quoted;
                continue;
            }

            if (char.IsWhiteSpace(ch) && !quoted)
            {
                if (cur.Length > 0)
                {
                    list.Add(cur.ToString());
                    cur.Clear();
                }

                continue;
            }

            cur.Append(ch);
        }

        if (cur.Length > 0) list.Add(cur.ToString());
        return list;
    }

    private CommandResult Help(CommandResult r)
    {
        var p = Settings.Commands.Prefix;
        r.Add(ProductIdentity.DisplayName + " — команды:");
        r.Add($"{p} status — состояние, профиль, режимы");
        r.Add($"{p} players — игроки лобби (ID, риск, события)");
        r.Add($"{p} player <ID|имя> — подробности и объяснение риска");
        r.Add($"{p} detections [N] — последние события");
        r.Add($"{p} shield — статистика RPC Shield");
        r.Add($"{p} whitelist <ID> — добавить игрока в whitelist");
        r.Add($"{p} kick <ID> / {p} ban <ID> — только хост; бан требует подтверждения");
        r.Add($"{p} dryrun on|off — режим без вмешательства");
        r.Add($"{p} profile passive|balanced|strict|custom");
        r.Add($"{p} export — экспорт базы; {p} backup — резервная копия");
        r.Add($"{p} remove <FriendCode|HashPuid|RecordId> / {p} removeall — удаление (с подтверждением)");
        r.Add($"{p} confirm <код> / {p} cancel — подтвердить/отменить опасное действие");
        return r;
    }

    private CommandResult Status(CommandResult r)
    {
        var ctx = _core.Context;
        var s = Settings;
        r.Add($"{ProductIdentity.DisplayName} {(s.General.Enabled ? "включён" : "ВЫКЛЮЧЕН")}, профиль {s.General.Profile}{(s.General.DryRun ? ", Dry Run" : string.Empty)}.");
        r.Add($"Фаза: {ctx.Phase}; хост: {(ctx.LocalIsHost ? "вы" : "нет")}; сервер: {(ctx.OnOfficialServer ? "официальный" : "не официальный")}{(ctx.ModdedProtocol ? ", модифицированный протокол" : string.Empty)}.");
        r.Add($"Версия игры: {ctx.GameVersion} ({(ctx.VersionSupported ? "поддерживается" : "НЕ поддерживается — " + s.Compatibility.UnsupportedMode)}).");
        r.Add($"RPC Shield: {(s.RpcShield.Enabled ? "вкл" : "выкл")}{(s.RpcShield.DryRun ? " (Dry Run)" : string.Empty)}; проверено RPC: {_core.Inspector.Inspected}, отменено: {_core.Inspector.Cancelled}.");
        r.Add($"Событий за сессию: {_core.Engine.SessionEventCount}; записей в базе: {_core.Database.Count}.");
        return r;
    }

    private CommandResult Players(CommandResult r)
    {
        var players = _core.Players.Snapshot();
        if (players.Count == 0) return r.Add("Игроков нет (вы не в лобби?).");
        foreach (var p in players)
        {
            var risk = _core.Risk.Assess(p.Identity.Key(_core.Context.SessionId));
            r.Add($"[{p.Identity.PlayerId}] {p.Identity.Display}{(p.Identity.IsHost ? " (хост)" : string.Empty)}{(p.Identity.IsLocal ? " (вы)" : string.Empty)} — риск {risk.Score} ({RiskModel.LevelText(risk.Level)}), событий {p.EventCount}");
        }

        return r;
    }

    private CommandResult Player(CommandResult r, List<string> args)
    {
        var p = ResolvePlayer(args, r);
        if (p == null) return r;
        var id = p.Identity;
        var risk = _core.Risk.Assess(id.Key(_core.Context.SessionId));
        r.Add($"{id.Display}: PlayerId {id.PlayerId}, ClientId {id.ClientId}, уровень {id.LevelDisplay}, платформа {id.Platform?.Display ?? "—"}");
        r.Add($"Friend Code: {(string.IsNullOrEmpty(id.FriendCode) ? "—" : id.FriendCode)}; HashPuid: {(string.IsNullOrEmpty(id.HashPuid) ? "—" : id.HashPuid)}");
        foreach (var line in risk.Explanation.Take(6)) r.Add(line);
        return r;
    }

    private CommandResult Detections(CommandResult r, List<string> args)
    {
        var n = 8;
        if (args.Count > 0 && int.TryParse(args[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed)) n = Math.Max(1, Math.Min(30, parsed));
        var events = _core.Engine.Feed.Latest(n);
        if (events.Count == 0) return r.Add("Событий пока нет.");
        foreach (var e in events)
            r.Add($"{e.TimestampUtc.ToLocalTime():HH:mm:ss} {e.Player.Display}: {e.Summary} ({e.Confidence:0.00})");
        return r;
    }

    private CommandResult Export(CommandResult r)
    {
        var path = _core.ExportDatabase(null);
        return r.Add(path != null ? $"Экспортировано в {path}" : "Экспорт не удался — подробности в журнале.");
    }

    private CommandResult Backup(CommandResult r)
    {
        var path = _core.Database.Backup();
        return r.Add(path != null ? $"Резервная копия: {Path.GetFileName(path)}" : "Резервная копия не создана (база пуста или ошибка — см. журнал).");
    }

    private CommandResult Remove(CommandResult r, List<string> args)
    {
        if (args.Count == 0) return r.Add($"Использование: {Settings.Commands.Prefix} remove <FriendCode|HashPuid|RecordId>");
        var found = _core.Database.FindByIdentifier(args[0]);
        if (found.Count == 0) return r.Add("Записи не найдены.");
        var ids = found.Select(f => f.RecordId).ToList();
        var names = string.Join(", ", found.Take(5).Select(f => f.PlayerName));
        return RequestConfirmation(r, $"удалить записей: {found.Count} ({names})", () =>
        {
            var n = _core.Database.Delete(ids);
            return $"Удалено записей: {n}.";
        });
    }

    private CommandResult RemoveAll(CommandResult r)
    {
        var count = _core.Database.Count;
        if (count == 0) return r.Add("База пуста.");
        return RequestConfirmation(r, $"удалить ВСЕ записи базы ({count}). Перед удалением будет создана резервная копия", () =>
        {
            var n = _core.Database.DeleteAll();
            return $"Удалено записей: {n}. Восстановление — из резервной копии (страница Database).";
        });
    }

    private CommandResult HostAction(CommandResult r, List<string> args, bool ban)
    {
        var p = ResolvePlayer(args, r);
        if (p == null) return r;
        if (!_core.Context.LocalIsHost) return r.Add("Недоступно: вы не хост этого лобби.");
        var target = p.Identity.Clone();
        if (!ban)
        {
            var ok = _core.Actions.TryHostAction(target, false, automatic: false, "manual", "команда kick", out var error);
            return r.Add(ok ? $"Kick выполнен: {target.Display}." : $"Kick не выполнен: {error}.");
        }

        return RequestConfirmation(r, $"забанить {target.Display} в этом лобби", () =>
        {
            var ok = _core.Actions.TryHostAction(target, true, automatic: false, "manual", "команда ban", out var error);
            return ok ? $"Ban выполнен: {target.Display}." : $"Ban не выполнен: {error}.";
        });
    }

    private CommandResult DryRun(CommandResult r, List<string> args)
    {
        if (args.Count > 0)
        {
            var v = args[0].ToLowerInvariant();
            if (v is "on" or "1" or "true" or "вкл") _core.UpdateSetting(() => Settings.General.DryRun = true);
            else if (v is "off" or "0" or "false" or "выкл") _core.UpdateSetting(() => Settings.General.DryRun = false);
            else return r.Add("Использование: dryrun on|off");
        }

        return r.Add($"Dry Run: {(Settings.General.DryRun ? "включён" : "выключен")}.");
    }

    private CommandResult Profile(CommandResult r, List<string> args)
    {
        if (args.Count > 0)
        {
            if (!Enum.TryParse<ActionProfileName>(args[0], true, out var profile) || !Enum.IsDefined(typeof(ActionProfileName), profile))
                return r.Add("Профили: passive, balanced, strict, custom.");
            _core.UpdateSetting(() => Settings.General.Profile = profile);
        }

        var policy = _core.Actions.ActivePolicy;
        r.Add($"Профиль: {Settings.General.Profile}. {policy.Description}");
        r.Add($"Автокик: {(Settings.AutoActions.AllowAutoKick ? "разрешён" : "выключен")}; автобан: {(Settings.AutoActions.AllowAutoBan ? "разрешён" : "выключен")}.");
        return r;
    }

    private CommandResult Whitelist(CommandResult r, List<string> args)
    {
        var p = ResolvePlayer(args, r);
        if (p == null) return r;
        var record = _core.Database.EnsureRecord(p.Identity);
        if (record == null) return r.Add("Нельзя добавить в whitelist: у игрока нет Friend Code / PUID (нечем надёжно идентифицировать).");
        _core.Database.SetWhitelist(record.RecordId, true);
        return r.Add($"{p.Identity.Display} добавлен в whitelist.");
    }

    private CommandResult Shield(CommandResult r)
    {
        var stats = _core.Shield.Stats.ToList();
        if (stats.Count == 0) return r.Add("RPC Shield: данных пока нет.");
        foreach (var pair in stats.OrderByDescending(p => p.Value.Exceeded))
            r.Add($"{pair.Key}: всего {pair.Value.Total}, превышений {pair.Value.Exceeded}, отменено {pair.Value.Cancelled}");
        return r;
    }

    // ---------- подтверждения ----------

    private CommandResult RequestConfirmation(CommandResult r, string description, Func<string> action)
    {
        var code = Hashing.ShortCode(_random);
        _pending = new PendingConfirmation(code, description, action, _core.Clock.UtcNow.AddSeconds(Settings.Commands.ConfirmTimeoutSeconds));
        r.Add($"Подтвердите: {description}.");
        r.Add($"Введите {Settings.Commands.Prefix} confirm {code} в течение {Settings.Commands.ConfirmTimeoutSeconds} с, или {Settings.Commands.Prefix} cancel.");
        return r;
    }

    private CommandResult Confirm(CommandResult r, List<string> args)
    {
        var pending = _pending;
        if (pending == null) return r.Add("Нет действия, ожидающего подтверждения.");
        if (_core.Clock.UtcNow > pending.ExpiresUtc)
        {
            _pending = null;
            return r.Add("Время подтверждения истекло. Повторите команду.");
        }

        if (args.Count == 0 || !string.Equals(args[0], pending.Code, StringComparison.OrdinalIgnoreCase))
            return r.Add("Неверный код подтверждения.");

        _pending = null; // защита от повторного выполнения
        return r.Add(pending.Action());
    }

    private CommandResult CancelPending(CommandResult r)
    {
        if (_pending == null) return r.Add("Нечего отменять.");
        _pending = null;
        return r.Add("Действие отменено.");
    }

    private LivePlayer? ResolvePlayer(List<string> args, CommandResult r)
    {
        if (args.Count == 0)
        {
            r.Add("Укажите игрока: PlayerId (число из /kd players), #ClientId или начало имени.");
            return null;
        }

        var arg = string.Join(" ", args);
        var players = _core.Players.Snapshot();
        LivePlayer? found = null;
        if (arg.StartsWith("#", StringComparison.Ordinal) && int.TryParse(arg.Substring(1), out var clientId))
            found = players.FirstOrDefault(p => p.Identity.ClientId == clientId);
        else if (byte.TryParse(arg, NumberStyles.Integer, CultureInfo.InvariantCulture, out var playerId))
            found = players.FirstOrDefault(p => p.Identity.PlayerId == playerId);

        if (found == null)
        {
            var byName = players.Where(p => p.Identity.Name.StartsWith(arg, StringComparison.OrdinalIgnoreCase)).ToList();
            if (byName.Count == 1) found = byName[0];
            else if (byName.Count > 1)
            {
                r.Add($"Несколько игроков начинаются с «{arg}». Укажите PlayerId.");
                return null;
            }
        }

        if (found == null) r.Add($"Игрок «{arg}» не найден в лобби.");
        return found;
    }

    private sealed class PendingConfirmation
    {
        public PendingConfirmation(string code, string description, Func<string> action, DateTime expiresUtc)
        {
            Code = code;
            Description = description;
            Action = action;
            ExpiresUtc = expiresUtc;
        }

        public string Code { get; }
        public string Description { get; }
        public Func<string> Action { get; }
        public DateTime ExpiresUtc { get; }
    }
}
