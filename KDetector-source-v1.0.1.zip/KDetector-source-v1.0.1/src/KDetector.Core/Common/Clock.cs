namespace KDetector.Core.Common;

/// <summary>Источник времени. Абстракция нужна для детерминированных тестов окон и cooldown.</summary>
public interface IClock
{
    DateTime UtcNow { get; }

    /// <summary>Монотонное время в миллисекундах (не зависит от перевода системных часов).</summary>
    long MonotonicMs { get; }
}

public sealed class SystemClock : IClock
{
    public static readonly SystemClock Instance = new();
    private static readonly System.Diagnostics.Stopwatch Watch = System.Diagnostics.Stopwatch.StartNew();

    public DateTime UtcNow => DateTime.UtcNow;
    public long MonotonicMs => Watch.ElapsedMilliseconds;
}

/// <summary>Управляемые часы для тестов.</summary>
public sealed class ManualClock : IClock
{
    private long _ms;
    private DateTime _utc;

    public ManualClock(DateTime? start = null)
    {
        _utc = start ?? new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    }

    public DateTime UtcNow => _utc;
    public long MonotonicMs => _ms;

    public void Advance(TimeSpan delta)
    {
        _ms += (long)delta.TotalMilliseconds;
        _utc = _utc.Add(delta);
    }

    public void AdvanceMs(long ms) => Advance(TimeSpan.FromMilliseconds(ms));
}
