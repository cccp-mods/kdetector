using System.Security.Cryptography;
using System.Text;

namespace KDetector.Core.Common;

/// <summary>
/// Хеширование идентификаторов. Сырые PUID никогда не сохраняются в базе:
/// хранится только усечённый SHA-256 (16 hex-символов), достаточный для сопоставления
/// записей и не позволяющий восстановить исходное значение.
/// </summary>
public static class Hashing
{
    public const int HashPuidLength = 16;

    public static string HashPuid(string? puid)
    {
        if (string.IsNullOrWhiteSpace(puid))
            return string.Empty;

        using var sha = SHA256.Create();
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(puid.Trim()));
        var sb = new StringBuilder(HashPuidLength);
        for (var i = 0; i < HashPuidLength / 2; i++)
            sb.Append(bytes[i].ToString("x2"));
        return sb.ToString();
    }

    /// <summary>Короткий стабильный код для подтверждения опасных команд.</summary>
    public static string ShortCode(Random random)
    {
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var chars = new char[4];
        for (var i = 0; i < chars.Length; i++)
            chars[i] = alphabet[random.Next(alphabet.Length)];
        return new string(chars);
    }
}
