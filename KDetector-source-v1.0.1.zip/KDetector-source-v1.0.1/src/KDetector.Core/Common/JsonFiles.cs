using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using KDetector.Core.Logging;

namespace KDetector.Core.Common;

/// <summary>Загрузка/сохранение редактируемых JSON-файлов данных с безопасным откатом на встроенные значения.</summary>
public static class JsonFiles
{
    public static readonly JsonSerializerOptions Options = CreateOptions(true);
    public static readonly JsonSerializerOptions CompactOptions = CreateOptions(false);

    private static JsonSerializerOptions CreateOptions(bool indented)
    {
        var o = new JsonSerializerOptions
        {
            WriteIndented = indented,
            PropertyNameCaseInsensitive = true,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true,
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping, // кириллица остаётся читаемой в файле
            DefaultIgnoreCondition = JsonIgnoreCondition.Never,
        };
        o.Converters.Add(new JsonStringEnumConverter());
        return o;
    }

    /// <summary>
    /// Читает файл. Если файла нет — записывает встроенное значение и возвращает его.
    /// Если файл повреждён — НЕ перезаписывает его (пользовательские правки сохраняются), возвращает встроенное значение и предупреждение.
    /// </summary>
    public static T LoadOrCreate<T>(string path, Func<T> builtIn, KdLog log, string source, out string? warning) where T : class
    {
        warning = null;
        try
        {
            if (!File.Exists(path))
            {
                var value = builtIn();
                Save(path, value);
                log.Info(source, $"Создан файл по умолчанию: {path}");
                return value;
            }

            var text = File.ReadAllText(path, Encoding.UTF8);
            var loaded = JsonSerializer.Deserialize<T>(text, Options);
            if (loaded != null) return loaded;
            warning = $"Файл {Path.GetFileName(path)} пуст — используются встроенные правила.";
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            warning = $"Файл {Path.GetFileName(path)} не прочитан ({ex.Message}) — используются встроенные правила. Файл не изменён.";
        }

        log.Warn(source, warning);
        return builtIn();
    }

    public static void Save<T>(string path, T value)
    {
        var dir = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        var tmp = path + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(value, Options), new UTF8Encoding(false));
        File.Move(tmp, path, true);
    }
}
