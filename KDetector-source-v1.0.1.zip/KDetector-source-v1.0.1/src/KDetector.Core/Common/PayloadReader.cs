using System.Text;

namespace KDetector.Core.Common;

/// <summary>
/// Безопасный читатель копии полезной нагрузки RPC в формате Hazel:
/// little-endian целые, packed int (7-битный varint), строки = packed длина + UTF-8.
/// Никогда не бросает исключений наружу: каждая операция возвращает false при нехватке данных.
/// Работает только с ограниченной копией байтов, а не с игровым MessageReader.
/// </summary>
public sealed class PayloadReader
{
    private readonly byte[] _data;
    private int _pos;

    public PayloadReader(byte[] data)
    {
        _data = data ?? Array.Empty<byte>();
    }

    public int Position => _pos;
    public int Remaining => _data.Length - _pos;

    public bool TryReadByte(out byte value)
    {
        value = 0;
        if (Remaining < 1) return false;
        value = _data[_pos++];
        return true;
    }

    public bool TryReadInt32(out int value)
    {
        value = 0;
        if (Remaining < 4) return false;
        value = _data[_pos] | (_data[_pos + 1] << 8) | (_data[_pos + 2] << 16) | (_data[_pos + 3] << 24);
        _pos += 4;
        return true;
    }

    public bool TryReadUInt64(out ulong value)
    {
        value = 0;
        if (Remaining < 8) return false;
        for (var i = 7; i >= 0; i--)
            value = (value << 8) | _data[_pos + i];
        _pos += 8;
        return true;
    }

    public bool TryReadPackedUInt32(out uint value)
    {
        value = 0;
        var shift = 0;
        for (var i = 0; i < 5; i++)
        {
            if (!TryReadByte(out var b)) return false;
            value |= (uint)(b & 0x7F) << shift;
            if ((b & 0x80) == 0) return true;
            shift += 7;
        }

        return false; // слишком длинное значение — некорректная сериализация
    }

    public bool TryReadPackedInt32(out int value)
    {
        var ok = TryReadPackedUInt32(out var raw);
        value = unchecked((int)raw);
        return ok;
    }

    public bool TryReadString(out string value, int maxBytes = 512)
    {
        value = string.Empty;
        if (!TryReadPackedInt32(out var len)) return false;
        if (len < 0 || len > maxBytes || len > Remaining) return false;
        try
        {
            value = Encoding.UTF8.GetString(_data, _pos, len);
        }
        catch (ArgumentException)
        {
            return false;
        }

        _pos += len;
        return true;
    }

    public static PayloadReader Empty => new(Array.Empty<byte>());

    /// <summary>Короткое шестнадцатеричное представление для отчётов (ограничено, чтобы не раздувать логи).</summary>
    public static string ToHexPreview(byte[]? data, int maxBytes = 32)
    {
        if (data == null || data.Length == 0) return "(пусто)";
        var n = Math.Min(maxBytes, data.Length);
        var sb = new StringBuilder(n * 3 + 8);
        for (var i = 0; i < n; i++)
        {
            if (i > 0) sb.Append(' ');
            sb.Append(data[i].ToString("X2"));
        }

        if (data.Length > n) sb.Append(" …(+").Append(data.Length - n).Append(" байт)");
        return sb.ToString();
    }
}
