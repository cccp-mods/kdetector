namespace KDetector.Core.Common;

/// <summary>Public display identity for user-facing text. Internal namespaces, paths and command IDs stay stable.</summary>
public static class ProductIdentity
{
    public const string DisplayName = "KDetector by CCCP_MODS (tg: @cccp_mods)";
}
