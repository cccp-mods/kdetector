namespace KDetector.Core.Common;

/// <summary>
/// Потокобезопасный кольцевой буфер фиксированной ёмкости.
/// Используется для лент событий и журналов, чтобы память не росла бесконечно.
/// </summary>
public sealed class RingBuffer<T>
{
    private readonly T[] _items;
    private readonly object _sync = new();
    private int _start;
    private int _count;
    private long _version;

    public RingBuffer(int capacity)
    {
        if (capacity < 1) throw new ArgumentOutOfRangeException(nameof(capacity));
        _items = new T[capacity];
    }

    public int Capacity => _items.Length;

    public int Count
    {
        get { lock (_sync) return _count; }
    }

    /// <summary>Увеличивается при каждом изменении; UI использует его, чтобы не пересчитывать представление каждый кадр.</summary>
    public long Version
    {
        get { lock (_sync) return _version; }
    }

    public void Add(T item)
    {
        lock (_sync)
        {
            var index = (_start + _count) % _items.Length;
            _items[index] = item;
            if (_count < _items.Length)
                _count++;
            else
                _start = (_start + 1) % _items.Length;
            _version++;
        }
    }

    public void Clear()
    {
        lock (_sync)
        {
            Array.Clear(_items, 0, _items.Length);
            _start = 0;
            _count = 0;
            _version++;
        }
    }

    /// <summary>Снимок содержимого от старых к новым.</summary>
    public List<T> Snapshot()
    {
        lock (_sync)
        {
            var list = new List<T>(_count);
            for (var i = 0; i < _count; i++)
                list.Add(_items[(_start + i) % _items.Length]);
            return list;
        }
    }

    /// <summary>Последние N элементов, от новых к старым.</summary>
    public List<T> Latest(int max)
    {
        lock (_sync)
        {
            var n = Math.Min(max, _count);
            var list = new List<T>(n);
            for (var i = 0; i < n; i++)
                list.Add(_items[(_start + _count - 1 - i) % _items.Length]);
            return list;
        }
    }
}
