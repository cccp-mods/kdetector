using KDetector.Core.Logging;
using KDetector.Core.Common;

namespace KDetector.Core.Configuration;

/// <summary>
/// Описание параметра для привязки к BepInEx ConfigFile и для проверки диапазона.
/// Min/Max = NaN означает «без ограничения».
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class SettingAttribute : Attribute
{
    public SettingAttribute(string description)
    {
        Description = description;
    }

    public string Description { get; }
    public double Min { get; set; } = double.NaN;
    public double Max { get; set; } = double.NaN;

    /// <summary>Допустимые значения строки через запятую (без учёта регистра).</summary>
    public string Allowed { get; set; } = string.Empty;

    /// <summary>Изменение вступает в силу только после перезапуска игры.</summary>
    public bool RequiresRestart { get; set; }
}

[AttributeUsage(AttributeTargets.Class)]
public sealed class SectionAttribute : Attribute
{
    public SectionAttribute(string name, string title)
    {
        Name = name;
        Title = title;
    }

    public string Name { get; }
    public string Title { get; }
}

public enum ActionProfileName
{
    Passive,
    Balanced,
    Strict,
    Custom,
}

public enum UnsupportedVersionMode
{
    /// <summary>Только наблюдение: отмена RPC и автоматические Kick/Ban отключены.</summary>
    ObserveOnly,

    /// <summary>Сетевые проверки полностью отключены.</summary>
    DisableNetworkChecks,

    /// <summary>Работать как на поддерживаемой версии (на свой риск).</summary>
    Ignore,
}

[Section("General", "Общие")]
public sealed class GeneralSettings
{
    [Setting("Главный выключатель " + ProductIdentity.DisplayName + ".")]
    public bool Enabled { get; set; } = true;

    [Setting("Профиль автоматических действий: Passive, Balanced, Strict, Custom.")]
    public ActionProfileName Profile { get; set; } = ActionProfileName.Balanced;

    [Setting("Dry Run: все решения вычисляются и журналируются, но RPC не отменяются, Kick/Ban не выполняются.")]
    public bool DryRun { get; set; } = false;
}

[Section("Detection", "Обнаружение")]
public sealed class DetectionSettings
{
    [Setting("Минимальная уверенность (0..1), ниже которой наблюдения не регистрируются как события.", Min = 0, Max = 1)]
    public double GlobalMinConfidence { get; set; } = 0.25;

    [Setting("Размер ленты последних событий в памяти.", Min = 50, Max = 5000, RequiresRestart = true)]
    public int EventFeedCapacity { get; set; } = 500;

    [Setting("Период полураспада риска в минутах: насколько быстро старые события перестают влиять на оценку.", Min = 1, Max = 1440)]
    public double RiskHalfLifeMinutes { get; set; } = 30;

    [Setting("Whitelist: Friend Code или HashPuid через запятую. События таких игроков записываются, но автоматические меры не применяются. Дополняет whitelist в базе.")]
    public string Whitelist { get; set; } = string.Empty;
}

[Section("LevelSpoofing", "Уровень")]
public sealed class LevelSettings
{
    [Setting("Включить детектор подозрительных значений уровня.")]
    public bool Enabled { get; set; } = true;

    [Setting("Проверять некорректные значения (переполнение / отрицательное число, переданное как беззнаковое).")]
    public bool CheckInvalidValues { get; set; } = true;

    [Setting("Проверять аномальные изменения уровня в пределах одного подключения.")]
    public bool CheckAnomalousChanges { get; set; } = true;

    [Setting("Проверять диапазон уровня. ВЫКЛЮЧЕНО по умолчанию: официальный предел уровня не подтверждён.")]
    public bool RangeCheckEnabled { get; set; } = false;

    [Setting("Минимальный допустимый уровень (как показывает игра), если включена проверка диапазона.", Min = 1, Max = 1000000)]
    public int MinLevel { get; set; } = 1;

    [Setting("Максимальный допустимый уровень (как показывает игра), если включена проверка диапазона.", Min = 1, Max = 100000000)]
    public int MaxLevel { get; set; } = 100000;

    [Setting("Уверенность для некорректного значения.", Min = 0, Max = 1)]
    public double InvalidValueConfidence { get; set; } = 0.6;

    [Setting("Уверенность для аномального изменения.", Min = 0, Max = 1)]
    public double ChangeConfidence { get; set; } = 0.35;

    [Setting("Сколько повышений уровня за один матч считать нормой (после завершения игры уровень может вырасти).", Min = 1, Max = 100)]
    public int MaxIncreasePerMatch { get; set; } = 3;
}

[Section("PlatformSpoofing", "Подмена платформы")]
public sealed class PlatformSpoofSettings
{
    [Setting("Включить проверку согласованности сетевых данных платформы.")]
    public bool Enabled { get; set; } = true;

    [Setting("Проверять идентификатор консоли для Xbox / Microsoft Store / PlayStation (наличие и длина).")]
    public bool CheckConsoleIdConsistency { get; set; } = true;

    [Setting("Имена значений перечисления игры, для которых ожидается XboxPlatformId (через запятую).")]
    public string XboxEnumNames { get; set; } = "Xbox,StandaloneWin10";

    [Setting("Имена значений перечисления игры, для которых ожидается PsnPlatformId (через запятую).")]
    public string PsnEnumNames { get; set; } = "Playstation";

    [Setting("Минимальная длина XboxPlatformId в цифрах (эвристика, не спецификация).", Min = 1, Max = 20)]
    public int XboxIdMinDigits { get; set; } = 10;

    [Setting("Максимальная длина XboxPlatformId в цифрах.", Min = 1, Max = 20)]
    public int XboxIdMaxDigits { get; set; } = 16;

    [Setting("Минимальная длина PsnPlatformId в цифрах (эвристика, не спецификация).", Min = 1, Max = 20)]
    public int PsnIdMinDigits { get; set; } = 14;

    [Setting("Максимальная длина PsnPlatformId в цифрах.", Min = 1, Max = 20)]
    public int PsnIdMaxDigits { get; set; } = 20;

    [Setting("Уверенность при отсутствии / неверной длине идентификатора консоли.", Min = 0, Max = 1)]
    public double ConsoleIdConfidence { get; set; } = 0.55;

    [Setting("Фиксировать смену платформы в пределах одного подключения.")]
    public bool CheckSessionChanges { get; set; } = true;

    [Setting("Уверенность при смене платформы в пределах подключения.", Min = 0, Max = 1)]
    public double ChangeConfidence { get; set; } = 0.5;

    [Setting("Через сколько секунд после появления игрока проверять платформу (данные приходят асинхронно).", Min = 0, Max = 60)]
    public double CheckDelaySeconds { get; set; } = 3;
}

[Section("InvalidPlatform", "Некорректная платформа")]
public sealed class InvalidPlatformSettings
{
    [Setting("Включить проверку значений, не входящих в перечисление платформ текущей версии.")]
    public bool Enabled { get; set; } = true;

    [Setting("Дополнительно разрешённые нестандартные идентификаторы платформ (через запятую). 112 = Starlight (Android).")]
    public string AllowedCustomPlatformIds { get; set; } = "112";

    [Setting("Регистрировать значение Unknown (определено в игре, но не соответствует реальной платформе).")]
    public bool FlagUnknownValue { get; set; } = true;

    [Setting("Уверенность для значения, не определённого в перечислении игры.", Min = 0, Max = 1)]
    public double UndefinedConfidence { get; set; } = 0.6;

    [Setting("Уверенность для значения Unknown.", Min = 0, Max = 1)]
    public double UnknownConfidence { get; set; } = 0.3;

    [Setting("Имя значения перечисления, означающего неизвестную платформу.")]
    public string UnknownEnumName { get; set; } = "Unknown";
}

[Section("KnownClients", "Известные клиенты")]
public sealed class KnownClientSettings
{
    [Setting("Включить сопоставление с публичными сигнатурами сторонних клиентов.")]
    public bool Enabled { get; set; } = true;

    [Setting("Файл сигнатур в папке Data (редактируемый JSON).")]
    public string SignatureFile { get; set; } = "KnownClients.json";

    [Setting("Не применять сигнатуры в лобби с модифицированным протоколом (там свои пользовательские RPC).")]
    public bool DisableOnModdedProtocol { get; set; } = true;

    [Setting("Не применять сигнатуры вне официальных серверов.")]
    public bool DisableOnUnofficialServer { get; set; } = true;
}

[Section("InvalidActions", "Недопустимые действия")]
public sealed class InvalidActionSettings
{
    [Setting("Включить проверку действий, противоречащих фазе игры и правилам протокола.")]
    public bool Enabled { get; set; } = true;

    [Setting("Файл правил протокола в папке Data (редактируемый JSON).")]
    public string RulesFile { get; set; } = "ProtocolRules.json";

    [Setting("Приостанавливать проверки вне официальных серверов (модифицированные режимы игры).")]
    public bool SuspendOnUnofficialServer { get; set; } = true;

    [Setting("Приостанавливать проверки в лобби с модифицированным протоколом.")]
    public bool SuspendOnModdedProtocol { get; set; } = true;

    [Setting("Сколько секунд после смены фазы игры не применять правила, зависящие от фазы (RPC начала/конца матча приходят рядом со сменой фазы).", Min = 0, Max = 30)]
    public double PhaseGraceSeconds { get; set; } = 3;
}

[Section("RpcShield", "RPC Shield")]
public sealed class RpcShieldSettings
{
    [Setting("Включить RPC Shield (контроль частоты RPC).")]
    public bool Enabled { get; set; } = true;

    [Setting("Dry Run только для RPC Shield: превышения фиксируются, но ничего не отменяется.")]
    public bool DryRun { get; set; } = false;

    [Setting("Общий лимит RPC от одного игрока за окно (все типы вместе).", Min = 10, Max = 10000)]
    public int GlobalLimit { get; set; } = 120;

    [Setting("Окно общего лимита, мс.", Min = 100, Max = 60000)]
    public int GlobalWindowMs { get; set; } = 1000;

    [Setting("Журналировать RPC с номером, которого нет в перечислении игры (без блокировки).")]
    public bool LogUnknownRpcs { get; set; } = true;

    [Setting("Файл категорий и лимитов в папке Data (редактируемый JSON).")]
    public string RulesFile { get; set; } = "RpcShield.json";

    [Setting("Не чаще одного события обнаружения на игрока и категорию за указанное число секунд.", Min = 1, Max = 3600)]
    public int EventCooldownSeconds { get; set; } = 30;
}

[Section("AutoActions", "Автоматические действия")]
public sealed class AutoActionSettings
{
    [Setting("Разрешить автоматический Kick (только когда вы хост). Выключено по умолчанию.")]
    public bool AllowAutoKick { get; set; } = false;

    [Setting("Разрешить автоматический Ban в текущем лобби (только когда вы хост). Выключено по умолчанию.")]
    public bool AllowAutoBan { get; set; } = false;

    [Setting("Минимальная пауза между автоматическими Kick/Ban, секунд.", Min = 1, Max = 600)]
    public int HostActionCooldownSeconds { get; set; } = 10;

    [Setting("Файл пользовательского профиля Custom в папке Data (редактируемый JSON).")]
    public string CustomPolicyFile { get; set; } = "ActionPolicies.json";
}

[Section("Database", "База данных")]
public sealed class DatabaseSettings
{
    [Setting("Папка базы. Пусто = BepInEx/plugins/KDetector/Data.", RequiresRestart = true)]
    public string Directory { get; set; } = string.Empty;

    [Setting("Имя файла базы без расширения.", RequiresRestart = true)]
    public string FileName { get; set; } = "KDetector";

    [Setting("Расширение файла базы: kh или kd. Используется одна активная база.", Allowed = "kh,kd", RequiresRestart = true)]
    public string Extension { get; set; } = "kh";

    [Setting("Сохранять изменения на диск не чаще, чем раз в N секунд (запись в фоновом потоке).", Min = 1, Max = 300)]
    public int FlushIntervalSeconds { get; set; } = 5;

    [Setting("Автоматические резервные копии.")]
    public bool AutoBackup { get; set; } = true;

    [Setting("Интервал автоматических резервных копий, минут.", Min = 5, Max = 10080)]
    public int BackupIntervalMinutes { get; set; } = 60;

    [Setting("Сколько резервных копий хранить.", Min = 1, Max = 200)]
    public int MaxBackups { get; set; } = 10;

    [Setting("Автоматическая очистка базы. Выключено по умолчанию.")]
    public bool AutoCleanup { get; set; } = false;

    [Setting("Удалять записи, не обновлявшиеся дольше N дней (при включённой автоочистке).", Min = 1, Max = 36500)]
    public int RetentionDays { get; set; } = 180;

    [Setting("Максимальное число записей (при включённой автоочистке удаляются самые старые).", Min = 10, Max = 1000000)]
    public int MaxRecords { get; set; } = 5000;

    [Setting("Очищать только эти категории (через запятую, пусто = все). Например: RpcSpam,LevelSpoofing.")]
    public string CleanupCategories { get; set; } = string.Empty;

    [Setting("Не удалять записи со статусом рассмотрения, выставленным вручную.")]
    public bool KeepReviewed { get; set; } = true;

    [Setting("Не удалять записи из whitelist.")]
    public bool KeepWhitelisted { get; set; } = true;

    [Setting("Не удалять записи, по которым выполнялись действия (Kick/Ban).")]
    public bool KeepActionHistory { get; set; } = true;

    [Setting("Максимум событий, хранимых в одной записи (старые вытесняются).", Min = 5, Max = 1000)]
    public int MaxEventsPerRecord { get; set; } = 50;
}

[Section("Logging", "Журнал")]
public sealed class LoggingSettings
{
    [Setting("Минимальный уровень сообщений: Debug, Info, Warning, Error.")]
    public KdLogLevel Level { get; set; } = KdLogLevel.Info;

    [Setting("Писать собственный файл журнала " + ProductIdentity.DisplayName + " с ротацией.", RequiresRestart = true)]
    public bool FileLogging { get; set; } = true;

    [Setting("Максимальный размер файла журнала, КБ.", Min = 64, Max = 102400, RequiresRestart = true)]
    public int MaxFileSizeKb { get; set; } = 1024;

    [Setting("Сколько архивных файлов журнала хранить.", Min = 1, Max = 20, RequiresRestart = true)]
    public int MaxFiles { get; set; } = 3;

    [Setting("Режим диагностики: подробный журнал и расширенные сведения на странице Diagnostics.")]
    public bool DiagnosticMode { get; set; } = false;
}

[Section("Notifications", "Уведомления")]
public sealed class NotificationSettings
{
    [Setting("Показывать уведомления.")]
    public bool Enabled { get; set; } = true;

    [Setting("Минимальная серьёзность для уведомления: Info, Low, Medium, High, Critical.")]
    public Detection.Severity MinSeverity { get; set; } = Detection.Severity.Medium;

    [Setting("Дублировать уведомления локальным сообщением в чат (видно только вам).")]
    public bool ShowInChat { get; set; } = false;

    [Setting("Не чаще одного уведомления на игрока и правило за N секунд.", Min = 1, Max = 3600)]
    public int CooldownSeconds { get; set; } = 20;

    [Setting("Сколько секунд показывать всплывающее уведомление.", Min = 1, Max = 60)]
    public double ToastSeconds { get; set; } = 6;
}

[Section("GUI", "Интерфейс")]
public sealed class GuiSettings
{
    [Setting("Клавиша открытия окна (имя UnityEngine.KeyCode, например F8, Insert, Home).")]
    public string Hotkey { get; set; } = "F8";

    [Setting("Масштаб интерфейса.", Min = 0.75, Max = 2.0)]
    public double Scale { get; set; } = 1.0;

    [Setting("Запоминать положение и размер окна.")]
    public bool RememberWindow { get; set; } = true;

    [Setting("Положение окна X.", Min = -10000, Max = 10000)]
    public int WindowX { get; set; } = 80;

    [Setting("Положение окна Y.", Min = -10000, Max = 10000)]
    public int WindowY { get; set; } = 60;

    [Setting("Ширина окна.", Min = 640, Max = 4000)]
    public int WindowWidth { get; set; } = 980;

    [Setting("Высота окна.", Min = 420, Max = 3000)]
    public int WindowHeight { get; set; } = 620;

    [Setting("Показывать всплывающие уведомления при закрытом окне.")]
    public bool ToastsWhenClosed { get; set; } = true;
}

[Section("Compatibility", "Совместимость")]
public sealed class CompatibilitySettings
{
    [Setting("Поддерживаемые версии Among Us (Application.version), через запятую.")]
    public string SupportedVersions { get; set; } = "2026.9.29";

    [Setting("Поведение на неподдерживаемой версии: ObserveOnly, DisableNetworkChecks, Ignore.")]
    public UnsupportedVersionMode UnsupportedMode { get; set; } = UnsupportedVersionMode.ObserveOnly;

    [Setting("Имена официальных регионов (ServerManager.CurrentRegion.Name), через запятую.")]
    public string OfficialRegions { get; set; } = "North America,Europe,Asia";
}

[Section("Commands", "Команды")]
public sealed class CommandSettings
{
    [Setting("Включить команды в чате (обрабатываются локально и не отправляются другим игрокам).")]
    public bool Enabled { get; set; } = true;

    [Setting("Префикс команд. Должен начинаться с / и не содержать пробелов.")]
    public string Prefix { get; set; } = "/kd";

    [Setting("Сколько секунд ждать подтверждения опасной команды.", Min = 5, Max = 300)]
    public int ConfirmTimeoutSeconds { get; set; } = 30;
}

/// <summary>Настройки отдельного правила обнаружения.</summary>
public sealed class RuleSettings
{
    [Setting("Правило включено.")]
    public bool Enabled { get; set; } = true;

    [Setting("Минимальная уверенность (0 = значение правила по умолчанию).", Min = 0, Max = 1)]
    public double MinConfidence { get; set; } = 0;

    [Setting("Сколько наблюдений нужно в пределах окна, чтобы зарегистрировать событие.", Min = 1, Max = 1000)]
    public int Threshold { get; set; } = 1;

    [Setting("Окно для порога, секунд.", Min = 1, Max = 86400)]
    public int WindowSeconds { get; set; } = 60;

    [Setting("Исключения: Friend Code или HashPuid через запятую.")]
    public string Exceptions { get; set; } = string.Empty;

    public RuleSettings Clone() => (RuleSettings)MemberwiseClone();
}

/// <summary>Корень всех настроек KDetector.</summary>
public sealed class KdSettings
{
    public GeneralSettings General { get; set; } = new();
    public DetectionSettings Detection { get; set; } = new();
    public LevelSettings Level { get; set; } = new();
    public PlatformSpoofSettings PlatformSpoof { get; set; } = new();
    public InvalidPlatformSettings InvalidPlatform { get; set; } = new();
    public KnownClientSettings KnownClients { get; set; } = new();
    public InvalidActionSettings InvalidActions { get; set; } = new();
    public RpcShieldSettings RpcShield { get; set; } = new();
    public AutoActionSettings AutoActions { get; set; } = new();
    public DatabaseSettings Database { get; set; } = new();
    public LoggingSettings Logging { get; set; } = new();
    public NotificationSettings Notifications { get; set; } = new();
    public GuiSettings Gui { get; set; } = new();
    public CompatibilitySettings Compatibility { get; set; } = new();
    public CommandSettings Commands { get; set; } = new();

    /// <summary>Настройки правил по идентификатору правила.</summary>
    public Dictionary<string, RuleSettings> Rules { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public RuleSettings Rule(string ruleId)
    {
        if (!Rules.TryGetValue(ruleId, out var s))
        {
            s = new RuleSettings();
            Rules[ruleId] = s;
        }

        return s;
    }

    /// <summary>Все секции-объекты (для привязки к конфигурации и сброса).</summary>
    public IEnumerable<object> Sections()
    {
        yield return General;
        yield return Detection;
        yield return Level;
        yield return PlatformSpoof;
        yield return InvalidPlatform;
        yield return KnownClients;
        yield return InvalidActions;
        yield return RpcShield;
        yield return AutoActions;
        yield return Database;
        yield return Logging;
        yield return Notifications;
        yield return Gui;
        yield return Compatibility;
        yield return Commands;
    }

    public static List<string> SplitList(string? value) =>
        string.IsNullOrWhiteSpace(value)
            ? new List<string>()
            : value!.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => s.Length > 0)
                .ToList();
}
