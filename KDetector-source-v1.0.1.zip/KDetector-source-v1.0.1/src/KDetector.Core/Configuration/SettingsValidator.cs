using System.Globalization;
using System.Reflection;
using KDetector.Core.Common;

namespace KDetector.Core.Configuration;

/// <summary>
/// Проверка корректности настроек. Неверные значения не роняют плагин:
/// заменяются безопасными (граница диапазона или значение по умолчанию), а пользователь получает предупреждение.
/// </summary>
public static class SettingsValidator
{
    public static List<string> Validate(KdSettings settings)
    {
        var warnings = new List<string>();

        foreach (var section in settings.Sections())
            ValidateObject(section, SectionName(section.GetType()), warnings);

        foreach (var pair in settings.Rules)
            ValidateObject(pair.Value, "Rule." + pair.Key, warnings);

        // Связанные значения.
        if (settings.Level.MinLevel > settings.Level.MaxLevel)
        {
            warnings.Add($"LevelSpoofing: MinLevel ({settings.Level.MinLevel}) больше MaxLevel ({settings.Level.MaxLevel}) — значения поменяны местами.");
            (settings.Level.MinLevel, settings.Level.MaxLevel) = (settings.Level.MaxLevel, settings.Level.MinLevel);
        }

        var p = settings.PlatformSpoof;
        if (p.XboxIdMinDigits > p.XboxIdMaxDigits)
        {
            warnings.Add("PlatformSpoofing: XboxIdMinDigits больше XboxIdMaxDigits — значения поменяны местами.");
            (p.XboxIdMinDigits, p.XboxIdMaxDigits) = (p.XboxIdMaxDigits, p.XboxIdMinDigits);
        }

        if (p.PsnIdMinDigits > p.PsnIdMaxDigits)
        {
            warnings.Add("PlatformSpoofing: PsnIdMinDigits больше PsnIdMaxDigits — значения поменяны местами.");
            (p.PsnIdMinDigits, p.PsnIdMaxDigits) = (p.PsnIdMaxDigits, p.PsnIdMinDigits);
        }

        var prefix = settings.Commands.Prefix?.Trim() ?? string.Empty;
        if (prefix.Length < 2 || prefix[0] != '/' || prefix.Any(char.IsWhiteSpace))
        {
            warnings.Add($"Commands: недопустимый префикс '{settings.Commands.Prefix}', используется /kd.");
            settings.Commands.Prefix = "/kd";
        }
        else
        {
            settings.Commands.Prefix = prefix;
        }

        if (string.IsNullOrWhiteSpace(settings.Gui.Hotkey))
        {
            warnings.Add("GUI: клавиша не задана, используется F8.");
            settings.Gui.Hotkey = "F8";
        }

        foreach (var id in KdSettings.SplitList(settings.InvalidPlatform.AllowedCustomPlatformIds))
        {
            if (!int.TryParse(id, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
                warnings.Add($"InvalidPlatform: '{id}' в AllowedCustomPlatformIds не является числом и будет проигнорирован.");
        }

        foreach (var name in new[]
                 {
                     settings.KnownClients.SignatureFile, settings.InvalidActions.RulesFile,
                     settings.RpcShield.RulesFile, settings.AutoActions.CustomPolicyFile,
                 })
        {
            if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                warnings.Add($"Имя файла '{name}' содержит недопустимые символы.");
        }

        if (settings.Database.FileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || string.IsNullOrWhiteSpace(settings.Database.FileName))
        {
            warnings.Add($"Database: недопустимое имя файла '{settings.Database.FileName}', используется {ProductIdentity.DisplayName}.");
            settings.Database.FileName = "KDetector";
        }

        return warnings;
    }

    public static string SectionName(Type t) => t.GetCustomAttribute<SectionAttribute>()?.Name ?? t.Name;

    public static string SectionTitle(Type t) => t.GetCustomAttribute<SectionAttribute>()?.Title ?? t.Name;

    private static void ValidateObject(object target, string sectionName, List<string> warnings)
    {
        var defaults = Activator.CreateInstance(target.GetType());
        foreach (var prop in SettingProperties(target.GetType()))
        {
            var attr = prop.GetCustomAttribute<SettingAttribute>()!;
            var value = prop.GetValue(target);
            var def = prop.GetValue(defaults);

            switch (value)
            {
                case int i:
                    {
                        var clamped = (int)Clamp(i, attr);
                        if (clamped != i)
                        {
                            warnings.Add($"{sectionName}.{prop.Name}: {i} вне диапазона, установлено {clamped}.");
                            prop.SetValue(target, clamped);
                        }

                        break;
                    }
                case double d:
                    {
                        if (double.IsNaN(d) || double.IsInfinity(d))
                        {
                            warnings.Add($"{sectionName}.{prop.Name}: некорректное число, установлено значение по умолчанию.");
                            prop.SetValue(target, def);
                            break;
                        }

                        var clamped = Clamp(d, attr);
                        if (Math.Abs(clamped - d) > double.Epsilon)
                        {
                            warnings.Add($"{sectionName}.{prop.Name}: {d.ToString(CultureInfo.InvariantCulture)} вне диапазона, установлено {clamped.ToString(CultureInfo.InvariantCulture)}.");
                            prop.SetValue(target, clamped);
                        }

                        break;
                    }
                case string s when !string.IsNullOrEmpty(attr.Allowed):
                    {
                        var allowed = KdSettings.SplitList(attr.Allowed);
                        var normalized = s.Trim().TrimStart('.').ToLowerInvariant();
                        if (!allowed.Contains(normalized, StringComparer.OrdinalIgnoreCase))
                        {
                            warnings.Add($"{sectionName}.{prop.Name}: '{s}' недопустимо (допустимо: {attr.Allowed}), установлено '{def}'.");
                            prop.SetValue(target, def);
                        }
                        else if (normalized != s)
                        {
                            prop.SetValue(target, normalized);
                        }

                        break;
                    }
                case null when prop.PropertyType == typeof(string):
                    prop.SetValue(target, def ?? string.Empty);
                    break;
                case Enum e when !Enum.IsDefined(e.GetType(), e):
                    warnings.Add($"{sectionName}.{prop.Name}: значение {e} не определено, установлено {def}.");
                    prop.SetValue(target, def);
                    break;
            }
        }
    }

    private static double Clamp(double v, SettingAttribute attr)
    {
        if (!double.IsNaN(attr.Min) && v < attr.Min) return attr.Min;
        if (!double.IsNaN(attr.Max) && v > attr.Max) return attr.Max;
        return v;
    }

    public static IEnumerable<PropertyInfo> SettingProperties(Type t) =>
        t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.CanRead && p.CanWrite && p.GetCustomAttribute<SettingAttribute>() != null);

    /// <summary>Сбрасывает одну секцию к значениям по умолчанию (копированием свойств, чтобы ссылки оставались валидными).</summary>
    public static void ResetSection(object section)
    {
        var defaults = Activator.CreateInstance(section.GetType());
        foreach (var prop in SettingProperties(section.GetType()))
            prop.SetValue(section, prop.GetValue(defaults));
    }

    public static void ResetAll(KdSettings settings)
    {
        foreach (var section in settings.Sections())
            ResetSection(section);
        foreach (var rule in settings.Rules.Values)
            ResetSection(rule);
    }
}
