using System.Text;
using System.Text.Json;
using KDetector.Core.Actions;
using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Logging;
using KDetector.Core.Players;
using KDetector.Core.Risk;

namespace KDetector.Core.Database;

public enum RecordSort
{
    LastSeenDesc,
    LastSeenAsc,
    EventCountDesc,
    EventCountAsc,
    RiskDesc,
    NameAsc,
}

/// <summary>Параметры поиска/фильтра страницы Database и команд.</summary>
public sealed class RecordQuery
{
    public string Text { get; set; } = string.Empty;
    public DetectionCategory? Category { get; set; }
    public string? RiskLevel { get; set; }
    public ReviewStatus? Status { get; set; }
    public bool? Whitelisted { get; set; }
    public bool? Watchlist { get; set; }
    public RecordSort Sort { get; set; } = RecordSort.LastSeenDesc;
}

public sealed class DatabaseHealth
{
    public string Path { get; set; } = string.Empty;
    public bool Loaded { get; set; }
    public int Records { get; set; }
    public int PreservedFutureLines { get; set; }
    public long FileSizeBytes { get; set; }
    public DateTime? LastSavedUtc { get; set; }
    public DateTime? LastBackupUtc { get; set; }
    public int BackupCount { get; set; }
    public bool Dirty { get; set; }
    public string? LastError { get; set; }
    public List<string> Warnings { get; set; } = new();
}

public sealed class ImportResult
{
    public int Added { get; set; }
    public int Merged { get; set; }
    public int Skipped { get; set; }
    public int Corrupt { get; set; }
}

/// <summary>
/// Потокобезопасный сервис базы: изменения применяются в памяти сразу (быстро, на игровом потоке),
/// а запись на диск выполняет фоновый поток не чаще FlushIntervalSeconds. Сетевые обработчики никогда не ждут диска.
/// </summary>
public sealed class DatabaseService : IDetectionStore, IWhitelistProvider, IDisposable
{
    private readonly KdSettings _settings;
    private readonly KdLog _log;
    private readonly IClock _clock;
    private readonly object _sync = new();

    // Отдельная блокировка ввода-вывода: порядок захвата всегда _sync → _ioLock, фоновый поток берёт их по очереди, не вложенно.
    private readonly object _ioLock = new();

    // Поколение содержимого: растёт при загрузке/восстановлении, чтобы фоновый поток не записал устаревший снимок поверх восстановленной базы.
    private int _generation;
    private readonly KdDatabase _db;
    private readonly Thread _worker;
    private readonly AutoResetEvent _wake = new(false);
    private volatile bool _disposed;
    private bool _dirty;
    private DateTime _lastBackupUtc = DateTime.MinValue;
    private DateTime _lastCleanupUtc = DateTime.MinValue;
    private string? _lastError;
    private readonly List<string> _warnings = new();

    public DatabaseService(string path, KdSettings settings, KdLog log, IClock clock, bool startWorker = true)
    {
        _settings = settings;
        _log = log;
        _clock = clock;
        _db = new KdDatabase(path);
        _worker = new Thread(WorkerLoop) { IsBackground = true, Name = "KDetector.Database" };
        if (startWorker) _worker.Start();
    }

    public string Path => _db.Path;
    public bool IsLoaded { get; private set; }

    /// <summary>Увеличивается при каждом изменении — UI пересчитывает таблицу только при изменении.</summary>
    public long Version { get; private set; }

    public Func<string, RiskAssessment>? RiskProvider { get; set; }

    /// <summary>Пользовательское изменение записей (whitelist, статус, удаление, импорт, восстановление).</summary>
    public event Action? Changed;

    public LoadReport Load()
    {
        lock (_sync)
        {
            try
            {
                var report = _db.Load();
                Interlocked.Increment(ref _generation);
                IsLoaded = true;
                _lastError = null;
                _warnings.Clear();
                _warnings.AddRange(report.Warnings);
                foreach (var w in report.Warnings) _log.Warn("Database", w);
                var last = _db.ListBackups().FirstOrDefault();
                if (last != null) _lastBackupUtc = last.LastWriteTimeUtc;
                _log.Info("Database", $"Загружено записей: {report.Loaded} ({_db.Path}).");
                Version++;
                return report;
            }
            catch (DatabaseAccessException ex)
            {
                // База не загружена: запись на диск запрещена, чтобы не затереть существующий файл.
                IsLoaded = false;
                _lastError = ex.Message;
                _log.Error("Database", ex.Message);
                return new LoadReport { Warnings = { ex.Message } };
            }
        }
    }

    public void AddWarning(string warning)
    {
        lock (_sync) _warnings.Add(warning);
    }

    // ================= IDetectionStore =================

    public void RecordEvent(DetectionEvent evt)
    {
        var p = evt.Player;
        if (string.IsNullOrEmpty(p.FriendCode) && string.IsNullOrEmpty(p.HashPuid))
            return; // нет стабильного идентификатора — только сессия

        lock (_sync)
        {
            if (!IsLoaded) return;
            var r = FindOrCreate(p, evt.TimestampUtc);
            r.LastSeenUtc = evt.TimestampUtc;
            r.GameVersion = evt.GameVersion;
            r.DetectionEvents.Add(new StoredEvent
            {
                EventId = evt.Id.ToString("N"), Utc = evt.TimestampUtc, RuleId = evt.RuleId, RuleVersion = evt.RuleVersion,
                Category = evt.Category, Evidence = evt.Evidence, Severity = evt.Severity, Confidence = evt.Confidence,
                Summary = evt.Summary, Hypothesis = evt.Hypothesis, Facts = evt.Facts.Select(f => f.ToString()).Take(12).ToList(),
                SessionId = evt.SessionId, GameVersion = evt.GameVersion, ObservationCount = evt.ObservationCount,
            });

            var max = Math.Max(5, _settings.Database.MaxEventsPerRecord);
            if (r.DetectionEvents.Count > max) r.DetectionEvents.RemoveRange(0, r.DetectionEvents.Count - max);
            if (!r.RuleIds.Contains(evt.RuleId)) r.RuleIds.Add(evt.RuleId);
            if (!r.Evidence.Contains(evt.Summary))
            {
                r.Evidence.Add(evt.Summary);
                if (r.Evidence.Count > 30) r.Evidence.RemoveAt(0);
            }

            r.Confidence = Math.Max(r.Confidence, evt.Confidence);
            var risk = RiskProvider?.Invoke(evt.PlayerKey);
            if (risk != null)
            {
                r.RiskScore = risk.Score;
                r.RiskLevel = risk.Level.ToString();
            }

            MarkDirty();
        }
    }

    public void SetWatchlist(PlayerIdentity player, string sessionId, bool value)
    {
        lock (_sync)
        {
            if (!IsLoaded || (string.IsNullOrEmpty(player.FriendCode) && string.IsNullOrEmpty(player.HashPuid))) return;
            var r = FindOrCreate(player, _clock.UtcNow);
            if (r.Watchlist == value) return;
            r.Watchlist = value;
            MarkDirty();
        }
    }

    public void RecordAction(PlayerIdentity player, string sessionId, string action, string outcome, string reason)
    {
        lock (_sync)
        {
            if (!IsLoaded || (string.IsNullOrEmpty(player.FriendCode) && string.IsNullOrEmpty(player.HashPuid))) return;
            var r = FindOrCreate(player, _clock.UtcNow);
            r.ActionHistory.Add(new StoredAction { Utc = _clock.UtcNow, Action = action, Outcome = outcome, Reason = reason });
            if (r.ActionHistory.Count > 100) r.ActionHistory.RemoveAt(0);
            MarkDirty();
        }
    }

    // ================= IWhitelistProvider =================

    public bool IsWhitelisted(PlayerIdentity player)
    {
        lock (_sync)
        {
            var r = _db.Find(player.FriendCode, player.HashPuid);
            return r != null && r.WhitelistStatus == WhitelistStatus.Whitelisted;
        }
    }

    public DetectionRecord? FindByPlayer(PlayerIdentity player)
    {
        lock (_sync) return _db.Find(player.FriendCode, player.HashPuid);
    }

    // ================= UI / команды =================

    public List<DetectionRecord> Query(RecordQuery q)
    {
        lock (_sync)
        {
            IEnumerable<DetectionRecord> e = _db.Records;
            if (!string.IsNullOrWhiteSpace(q.Text))
            {
                var t = q.Text.Trim();
                e = e.Where(r =>
                    r.PlayerName.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    r.FriendCode.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    r.HashPuid.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    r.PreviousNames.Any(n => n.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0) ||
                    r.RecordId.StartsWith(t, StringComparison.OrdinalIgnoreCase));
            }

            if (q.Category.HasValue) e = e.Where(r => r.DetectionEvents.Any(ev => ev.Category == q.Category.Value));
            if (!string.IsNullOrEmpty(q.RiskLevel)) e = e.Where(r => string.Equals(r.RiskLevel, q.RiskLevel, StringComparison.OrdinalIgnoreCase));
            if (q.Status.HasValue) e = e.Where(r => r.ReviewStatus == q.Status.Value);
            if (q.Whitelisted.HasValue) e = e.Where(r => (r.WhitelistStatus == WhitelistStatus.Whitelisted) == q.Whitelisted.Value);
            if (q.Watchlist.HasValue) e = e.Where(r => r.Watchlist == q.Watchlist.Value);

            e = q.Sort switch
            {
                RecordSort.LastSeenAsc => e.OrderBy(r => r.LastSeenUtc),
                RecordSort.EventCountDesc => e.OrderByDescending(r => r.DetectionEvents.Count).ThenByDescending(r => r.LastSeenUtc),
                RecordSort.EventCountAsc => e.OrderBy(r => r.DetectionEvents.Count).ThenByDescending(r => r.LastSeenUtc),
                RecordSort.RiskDesc => e.OrderByDescending(r => r.RiskScore).ThenByDescending(r => r.LastSeenUtc),
                RecordSort.NameAsc => e.OrderBy(r => r.PlayerName, StringComparer.OrdinalIgnoreCase),
                _ => e.OrderByDescending(r => r.LastSeenUtc),
            };
            return e.ToList();
        }
    }

    public int Count
    {
        get { lock (_sync) return _db.Records.Count; }
    }

    public DetectionRecord? Get(string recordId)
    {
        lock (_sync) return _db.Get(recordId);
    }

    /// <summary>Поиск по идентификатору для команд: RecordId (или его начало), Friend Code, HashPuid.</summary>
    public List<DetectionRecord> FindByIdentifier(string identifier)
    {
        identifier = identifier.Trim();
        if (identifier.Length == 0) return new List<DetectionRecord>();
        lock (_sync)
        {
            return _db.Records.Where(r =>
                    string.Equals(r.FriendCode, identifier, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(r.HashPuid, identifier, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(r.RecordId, identifier, StringComparison.OrdinalIgnoreCase) ||
                    (identifier.Length >= 6 && r.RecordId.StartsWith(identifier, StringComparison.OrdinalIgnoreCase)))
                .ToList();
        }
    }

    public bool Update(string recordId, Action<DetectionRecord> change)
    {
        lock (_sync)
        {
            if (!IsLoaded) return false;
            var r = _db.Get(recordId);
            if (r == null) return false;
            change(r);
            MarkDirty();
        }

        RaiseChanged();
        return true;
    }

    private void RaiseChanged()
    {
        try
        {
            Changed?.Invoke();
        }
        catch (Exception ex)
        {
            _log.Error("Database", "Ошибка обработчика изменения базы", ex);
        }
    }

    public bool SetNote(string recordId, string note) => Update(recordId, r => r.Notes = note.Length > 2000 ? note.Substring(0, 2000) : note);
    public bool SetReviewStatus(string recordId, ReviewStatus status) => Update(recordId, r => r.ReviewStatus = status);
    public bool SetWhitelist(string recordId, bool value) => Update(recordId, r => r.WhitelistStatus = value ? WhitelistStatus.Whitelisted : WhitelistStatus.None);
    public bool SetWatchlist(string recordId, bool value) => Update(recordId, r => r.Watchlist = value);

    /// <summary>Создать/получить запись для живого игрока (например, чтобы добавить в whitelist из карточки игрока).</summary>
    public DetectionRecord? EnsureRecord(PlayerIdentity player)
    {
        if (string.IsNullOrEmpty(player.FriendCode) && string.IsNullOrEmpty(player.HashPuid)) return null;
        DetectionRecord r;
        lock (_sync)
        {
            if (!IsLoaded) return null;
            r = FindOrCreate(player, _clock.UtcNow);
            MarkDirty();
        }

        RaiseChanged();
        return r;
    }

    /// <summary>Удаление записей. Перед массовым удалением создаётся резервная копия.</summary>
    public int Delete(IReadOnlyCollection<string> recordIds)
    {
        if (recordIds.Count == 0) return 0;
        int n;
        lock (_sync)
        {
            if (!IsLoaded) return 0;
            if (recordIds.Count > 1) BackupWithLatest("before-delete");
            var set = new HashSet<string>(recordIds, StringComparer.OrdinalIgnoreCase);
            n = _db.RemoveWhere(r => set.Contains(r.RecordId));
            if (n > 0) MarkDirty();
            _log.Info("Database", $"Удалено записей: {n}.");
        }

        RaiseChanged();
        return n;
    }

    public int DeleteAll()
    {
        lock (_sync)
        {
            if (!IsLoaded) return 0;
            BackupWithLatest("before-delete-all");
            var n = _db.Clear();
            MarkDirty();
            _log.Warn("Database", $"Удалены все записи ({n}). Резервная копия создана перед удалением.");
            RaiseChanged();
            return n;
        }
    }

    // ================= экспорт / импорт =================

    public int Export(string path, IReadOnlyCollection<string>? recordIds = null)
    {
        string content;
        int count;
        lock (_sync)
        {
            var set = recordIds == null ? null : new HashSet<string>(recordIds, StringComparer.OrdinalIgnoreCase);
            var records = _db.Records.Where(r => set == null || set.Contains(r.RecordId)).ToList();
            var sb = new StringBuilder();
            foreach (var r in records) sb.Append(JsonSerializer.Serialize(r, JsonFiles.CompactOptions)).Append('\n');
            content = sb.ToString();
            count = records.Count;
        }

        KdDatabase.WriteAtomic(path, content);
        _log.Info("Database", $"Экспортировано записей: {count} → {path}");
        return count;
    }

    /// <summary>Импорт JSONL: записи с тем же игроком объединяются (события по EventId без дублей), новые добавляются.</summary>
    public ImportResult Import(string path)
    {
        var result = new ImportResult();
        var temp = new KdDatabase(path);
        var report = temp.Load();
        result.Corrupt = report.Corrupt;

        lock (_sync)
        {
            if (!IsLoaded) throw new InvalidOperationException("База не загружена");
            BackupWithLatest("before-import");
            foreach (var incoming in temp.Records)
            {
                if (!incoming.HasStableIdentity)
                {
                    result.Skipped++;
                    continue;
                }

                var existing = _db.Find(incoming.FriendCode, incoming.HashPuid) ?? _db.Get(incoming.RecordId);
                if (existing == null)
                {
                    if (_db.Get(incoming.RecordId) != null) incoming.RecordId = Guid.NewGuid().ToString("N");
                    _db.Add(incoming);
                    result.Added++;
                    continue;
                }

                var ids = new HashSet<string>(existing.DetectionEvents.Select(e => e.EventId));
                foreach (var ev in incoming.DetectionEvents.Where(ev => ids.Add(ev.EventId)))
                    existing.DetectionEvents.Add(ev);
                existing.DetectionEvents.Sort((a, b) => a.Utc.CompareTo(b.Utc));
                foreach (var rid in incoming.RuleIds.Where(rid => !existing.RuleIds.Contains(rid))) existing.RuleIds.Add(rid);
                foreach (var ev in incoming.Evidence.Where(ev => !existing.Evidence.Contains(ev))) existing.Evidence.Add(ev);
                existing.ActionHistory.AddRange(incoming.ActionHistory);
                if (incoming.FirstSeenUtc < existing.FirstSeenUtc) existing.FirstSeenUtc = incoming.FirstSeenUtc;
                if (incoming.LastSeenUtc > existing.LastSeenUtc) existing.LastSeenUtc = incoming.LastSeenUtc;
                existing.Confidence = Math.Max(existing.Confidence, incoming.Confidence);
                if (!string.IsNullOrEmpty(incoming.Notes) && !existing.Notes.Contains(incoming.Notes))
                    existing.Notes = string.IsNullOrEmpty(existing.Notes) ? incoming.Notes : existing.Notes + "\n" + incoming.Notes;
                result.Merged++;
            }

            MarkDirty();
        }

        RaiseChanged();
        _log.Info("Database", $"Импорт: добавлено {result.Added}, объединено {result.Merged}, пропущено {result.Skipped}, повреждено {result.Corrupt}.");
        return result;
    }

    // ================= резервные копии =================

    public string? Backup(string reason = "manual")
    {
        lock (_sync)
        {
            FlushLocked();
            return TryBackup(reason);
        }
    }

    public List<FileInfo> Backups()
    {
        lock (_sync) return _db.ListBackups();
    }

    /// <summary>Восстановление из резервной копии: текущая база сначала сохраняется в отдельную копию.</summary>
    public LoadReport Restore(string backupPath)
    {
        lock (_sync)
        {
            if (!File.Exists(backupPath)) throw new FileNotFoundException("Резервная копия не найдена", backupPath);
            FlushLocked();
            TryBackup("before-restore");
            lock (_ioLock)
            {
                Interlocked.Increment(ref _generation); // любой ранее снятый фоновым потоком снимок становится устаревшим
                File.Copy(backupPath, _db.Path, true);
            }
            _dirty = false;
            var report = Load();
            _log.Warn("Database", $"База восстановлена из {System.IO.Path.GetFileName(backupPath)}.");
            RaiseChanged();
            return report;
        }
    }

    /// <summary>
    /// Резервная копия, включающая последние изменения: сначала незаписанные изменения сохраняются на диск
    /// (фоновая запись идёт с интервалом), затем копируется файл. Вызывается под блокировкой _sync.
    /// </summary>
    private string? BackupWithLatest(string reason)
    {
        FlushLocked();
        return TryBackup(reason);
    }

    private string? TryBackup(string reason)
    {
        try
        {
            string? path;
            lock (_ioLock) path = _db.CreateBackup(_settings.Database.MaxBackups, reason);
            if (path != null) _lastBackupUtc = _clock.UtcNow;
            return path;
        }
        catch (Exception ex)
        {
            _log.Error("Database", "Не удалось создать резервную копию", ex);
            return null;
        }
    }

    // ================= очистка =================

    /// <summary>Очистка по настройкам. Возвращает число удалённых записей и событий.</summary>
    public (int records, int events) Cleanup(bool manual)
    {
        var s = _settings.Database;
        if (!manual && !s.AutoCleanup) return (0, 0);
        lock (_sync)
        {
            if (!IsLoaded) return (0, 0);
            BackupWithLatest(manual ? "before-cleanup" : "before-autocleanup");
            var now = _clock.UtcNow;
            var cutoff = now.AddDays(-s.RetentionDays);
            var categories = KdSettings.SplitList(s.CleanupCategories)
                .Select(c => Enum.TryParse<DetectionCategory>(c, true, out var cat) ? cat : (DetectionCategory?)null)
                .Where(c => c.HasValue).Select(c => c!.Value).ToHashSet();

            bool Protected(DetectionRecord r) =>
                (s.KeepReviewed && r.ReviewStatus != ReviewStatus.New) ||
                (s.KeepWhitelisted && r.WhitelistStatus == WhitelistStatus.Whitelisted) ||
                (s.KeepActionHistory && r.ActionHistory.Count > 0);

            bool InScope(StoredEvent e) => categories.Count == 0 || categories.Contains(e.Category);

            var removedEvents = 0;
            foreach (var r in _db.Records.Where(r => !Protected(r)))
                removedEvents += r.DetectionEvents.RemoveAll(e => e.Utc < cutoff && InScope(e));

            var removed = _db.RemoveWhere(r => !Protected(r) && r.LastSeenUtc < cutoff &&
                                               (categories.Count == 0 || r.DetectionEvents.All(InScope)));

            var excess = _db.Records.Count - s.MaxRecords;
            if (excess > 0)
            {
                var victims = _db.Records.Where(r => !Protected(r) && (categories.Count == 0 || r.DetectionEvents.All(InScope)))
                    .OrderBy(r => r.LastSeenUtc).Take(excess).Select(r => r.RecordId).ToHashSet();
                removed += _db.RemoveWhere(r => victims.Contains(r.RecordId));
            }

            if (removed > 0 || removedEvents > 0) MarkDirty();
            _lastCleanupUtc = now;
            _log.Info("Database", $"Очистка ({(manual ? "вручную" : "авто")}): удалено записей {removed}, событий {removedEvents}.");
            return (removed, removedEvents);
        }
    }

    public DatabaseHealth Health()
    {
        lock (_sync)
        {
            long size = 0;
            try
            {
                if (File.Exists(_db.Path)) size = new FileInfo(_db.Path).Length;
            }
            catch
            {
                // нет доступа — размер неизвестен
            }

            return new DatabaseHealth
            {
                Path = _db.Path,
                Loaded = IsLoaded,
                Records = _db.Records.Count,
                PreservedFutureLines = _db.PreservedLineCount,
                FileSizeBytes = size,
                LastSavedUtc = _db.LastSavedUtc,
                LastBackupUtc = _lastBackupUtc == DateTime.MinValue ? null : _lastBackupUtc,
                BackupCount = _db.ListBackups().Count,
                Dirty = _dirty,
                LastError = _lastError,
                Warnings = _warnings.ToList(),
            };
        }
    }

    // ================= запись на диск =================

    private DetectionRecord FindOrCreate(PlayerIdentity p, DateTime utc)
    {
        var r = _db.Find(p.FriendCode, p.HashPuid);
        if (r == null)
        {
            r = new DetectionRecord
            {
                FirstSeenUtc = utc,
                LastSeenUtc = utc,
                PlayerName = p.Name,
                FriendCode = p.FriendCode,
                HashPuid = p.HashPuid,
            };
            _db.Add(r);
        }

        if (!string.IsNullOrEmpty(p.Name) && !string.Equals(r.PlayerName, p.Name, StringComparison.Ordinal))
        {
            if (!string.IsNullOrEmpty(r.PlayerName) && !r.PreviousNames.Contains(r.PlayerName))
            {
                r.PreviousNames.Add(r.PlayerName);
                if (r.PreviousNames.Count > 20) r.PreviousNames.RemoveAt(0);
            }

            r.PlayerName = p.Name;
        }

        if (string.IsNullOrEmpty(r.FriendCode) && !string.IsNullOrEmpty(p.FriendCode)) r.FriendCode = p.FriendCode;
        if (string.IsNullOrEmpty(r.HashPuid) && !string.IsNullOrEmpty(p.HashPuid)) r.HashPuid = p.HashPuid;
        if (p.PlayerId != 255) r.PlayerId = p.PlayerId;
        if (p.Platform != null) r.Platform = p.Platform.Display;
        if (p.Level.HasValue) r.Level = p.LevelDisplay;
        return r;
    }

    private void MarkDirty()
    {
        _dirty = true;
        Version++;
    }

    /// <summary>Немедленная запись (при выходе из игры).</summary>
    public void Flush()
    {
        lock (_sync) FlushLocked();
    }

    private void FlushLocked()
    {
        if (!_dirty || !IsLoaded) return;
        try
        {
            var content = _db.Serialize();
            lock (_ioLock) KdDatabase.WriteAtomic(_db.Path, content);
            _db.MarkSaved();
            _dirty = false;
            _lastError = null;
        }
        catch (Exception ex)
        {
            _lastError = "Ошибка записи базы: " + ex.Message;
            _log.Throttled("db-write", 60000, KdLogLevel.Error, "Database", _lastError);
        }
    }

    private void WorkerLoop()
    {
        while (!_disposed)
        {
            _wake.WaitOne(TimeSpan.FromSeconds(Math.Max(1, _settings.Database.FlushIntervalSeconds)));
            if (_disposed) break;
            try
            {
                string? content = null;
                var generation = 0;
                lock (_sync)
                {
                    if (_dirty && IsLoaded)
                    {
                        content = _db.Serialize();
                        generation = Volatile.Read(ref _generation);
                        _dirty = false;
                    }
                }

                if (content != null)
                {
                    try
                    {
                        lock (_ioLock)
                        {
                            if (generation == Volatile.Read(ref _generation))
                                KdDatabase.WriteAtomic(_db.Path, content);
                        }

                        lock (_sync)
                        {
                            _db.MarkSaved();
                            _lastError = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        lock (_sync)
                        {
                            _dirty = true; // повторим позже
                            _lastError = "Ошибка записи базы: " + ex.Message;
                        }

                        _log.Throttled("db-write", 60000, KdLogLevel.Error, "Database", "Ошибка записи базы: " + ex.Message);
                    }
                }

                var s = _settings.Database;
                var now = _clock.UtcNow;
                if (s.AutoBackup && IsLoaded && (now - _lastBackupUtc).TotalMinutes >= s.BackupIntervalMinutes)
                    lock (_sync) TryBackup("auto");
                if (s.AutoCleanup && IsLoaded && (now - _lastCleanupUtc).TotalHours >= 6)
                    Cleanup(false);
            }
            catch (Exception ex)
            {
                _log.Error("Database", "Ошибка фоновой обработки базы", ex);
            }
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _wake.Set();
        if (_worker.IsAlive) _worker.Join(3000);
        Flush();
    }
}
