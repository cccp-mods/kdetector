using System.Text.Json.Serialization;
using KDetector.Core.Detection;

namespace KDetector.Core.Database;

public enum ReviewStatus
{
    /// <summary>Не рассматривалась.</summary>
    New,

    /// <summary>На рассмотрении.</summary>
    UnderReview,

    /// <summary>Проверено: нарушение подтверждено вручную.</summary>
    Confirmed,

    /// <summary>Проверено: нарушения нет (ложное срабатывание).</summary>
    Cleared,

    /// <summary>Не требует внимания.</summary>
    Ignored,
}

public enum WhitelistStatus
{
    None,
    Whitelisted,
}

/// <summary>Сохранённое событие обнаружения (компактная форма DetectionEvent).</summary>
public sealed class StoredEvent
{
    public string EventId { get; set; } = string.Empty;
    public DateTime Utc { get; set; }
    public string RuleId { get; set; } = string.Empty;
    public int RuleVersion { get; set; }
    public DetectionCategory Category { get; set; }
    public EvidenceKind Evidence { get; set; }
    public Severity Severity { get; set; }
    public double Confidence { get; set; }
    public string Summary { get; set; } = string.Empty;
    public string Hypothesis { get; set; } = string.Empty;
    public List<string> Facts { get; set; } = new();
    public string SessionId { get; set; } = string.Empty;
    public string GameVersion { get; set; } = string.Empty;
    public int ObservationCount { get; set; } = 1;
}

public sealed class StoredAction
{
    public DateTime Utc { get; set; }
    public string Action { get; set; } = string.Empty;
    public string Outcome { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
}

/// <summary>
/// Запись базы KDetector (одна строка JSON Lines). Неизвестные значения остаются пустыми.
/// В базу попадают только игроки со стабильным идентификатором (Friend Code или HashPuid):
/// записи «только по имени» нельзя надёжно отнести к аккаунту, поэтому они живут лишь в текущей сессии.
/// </summary>
public sealed class DetectionRecord
{
    public const int CurrentSchemaVersion = 1;

    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public string RecordId { get; set; } = Guid.NewGuid().ToString("N");
    public DateTime FirstSeenUtc { get; set; }
    public DateTime LastSeenUtc { get; set; }
    public string PlayerName { get; set; } = string.Empty;
    public List<string> PreviousNames { get; set; } = new();

    /// <summary>Последний известный PlayerId в лобби (меняется между лобби, хранится справочно).</summary>
    public int? PlayerId { get; set; }

    public string FriendCode { get; set; } = string.Empty;
    public string HashPuid { get; set; } = string.Empty;
    public string Platform { get; set; } = string.Empty;
    public string Level { get; set; } = string.Empty;
    public string GameVersion { get; set; } = string.Empty;
    public List<StoredEvent> DetectionEvents { get; set; } = new();
    public List<string> RuleIds { get; set; } = new();

    /// <summary>Краткие формулировки доказательств (без дубликатов).</summary>
    public List<string> Evidence { get; set; } = new();

    /// <summary>Максимальная уверенность среди событий.</summary>
    public double Confidence { get; set; }

    public string RiskLevel { get; set; } = string.Empty;
    public int RiskScore { get; set; }
    public List<StoredAction> ActionHistory { get; set; } = new();
    public ReviewStatus ReviewStatus { get; set; } = ReviewStatus.New;
    public WhitelistStatus WhitelistStatus { get; set; } = WhitelistStatus.None;
    public bool Watchlist { get; set; }
    public string Notes { get; set; } = string.Empty;

    [JsonIgnore]
    public int EventCount => DetectionEvents.Count;

    [JsonIgnore]
    public bool HasStableIdentity => !string.IsNullOrEmpty(FriendCode) || !string.IsNullOrEmpty(HashPuid);

    [JsonIgnore]
    public IEnumerable<DetectionCategory> Categories => DetectionEvents.Select(e => e.Category).Distinct();

    public bool Matches(string friendCode, string hashPuid)
    {
        if (!string.IsNullOrEmpty(hashPuid) && !string.IsNullOrEmpty(HashPuid))
            return string.Equals(hashPuid, HashPuid, StringComparison.OrdinalIgnoreCase);
        if (!string.IsNullOrEmpty(friendCode) && !string.IsNullOrEmpty(FriendCode))
            return string.Equals(friendCode, FriendCode, StringComparison.OrdinalIgnoreCase);
        return false;
    }
}
