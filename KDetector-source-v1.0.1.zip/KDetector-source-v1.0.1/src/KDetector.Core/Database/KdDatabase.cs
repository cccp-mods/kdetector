using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using KDetector.Core.Common;

namespace KDetector.Core.Database;

/// <summary>Результат загрузки базы.</summary>
public sealed class LoadReport
{
    public int Loaded { get; set; }
    public int Migrated { get; set; }
    public int Corrupt { get; set; }
    public int DuplicateIdsFixed { get; set; }
    public int FutureSchemaPreserved { get; set; }
    public string? QuarantineFile { get; set; }
    public List<string> Warnings { get; } = new();
}

/// <summary>
/// Файловое хранилище в формате UTF-8 JSON Lines: одна запись — одна строка, файл можно открыть любым текстовым редактором.
/// Надёжность:
/// • запись через временный файл в той же папке и атомарную замену;
/// • повреждённые строки не удаляются молча: копируются в файл карантина рядом с базой;
/// • записи более новой схемы (от будущих версий плагина) сохраняются без изменений;
/// • уникальность RecordId; миграции схемы; резервные копии с ротацией.
/// Класс не потокобезопасен сам по себе — синхронизацию обеспечивает DatabaseService.
/// </summary>
public sealed class KdDatabase
{
    public const string BackupFolderName = "Backups";

    private readonly List<DetectionRecord> _records = new();
    private readonly List<string> _preservedLines = new();

    public KdDatabase(string path)
    {
        Path = path;
    }

    public string Path { get; private set; }
    public IReadOnlyList<DetectionRecord> Records => _records;
    public int PreservedLineCount => _preservedLines.Count;
    public DateTime? LastSavedUtc { get; private set; }
    public DateTime? LastLoadedUtc { get; private set; }

    public string BackupDirectory => System.IO.Path.Combine(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(Path))!, BackupFolderName);

    /// <summary>
    /// Определяет активный файл базы: используется одна база. Если файла с выбранным расширением нет,
    /// но есть файл с альтернативным (.kh ↔ .kd), используется он — чтобы не появилось двух баз.
    /// </summary>
    public static string ResolvePath(string directory, string fileName, string extension, out string? note)
    {
        note = null;
        extension = extension.Trim().TrimStart('.').ToLowerInvariant();
        var alt = extension == "kd" ? "kh" : "kd";
        var preferred = System.IO.Path.Combine(directory, fileName + "." + extension);
        var alternative = System.IO.Path.Combine(directory, fileName + "." + alt);

        if (File.Exists(preferred))
        {
            if (File.Exists(alternative))
                note = $"Найдены оба файла ({System.IO.Path.GetFileName(preferred)} и {System.IO.Path.GetFileName(alternative)}). Активна база {System.IO.Path.GetFileName(preferred)}; второй файл не изменяется и может быть импортирован вручную.";
            return preferred;
        }

        if (File.Exists(alternative))
        {
            note = $"Используется существующая база {System.IO.Path.GetFileName(alternative)} (выбранное расширение .{extension} не найдено).";
            return alternative;
        }

        return preferred;
    }

    public LoadReport Load()
    {
        var report = new LoadReport();
        _records.Clear();
        _preservedLines.Clear();
        LastLoadedUtc = DateTime.UtcNow;

        if (!File.Exists(Path))
            return report; // отсутствующий файл = пустая база, будет создан при первом сохранении

        string[] lines;
        try
        {
            lines = File.ReadAllLines(Path, Encoding.UTF8);
        }
        catch (UnauthorizedAccessException ex)
        {
            throw new DatabaseAccessException($"Нет доступа к файлу базы: {Path}. Проверьте права или выберите другую папку в настройках.", ex);
        }
        catch (IOException ex)
        {
            throw new DatabaseAccessException($"Файл базы занят или недоступен: {Path} ({ex.Message}).", ex);
        }

        var corrupt = new List<string>();
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i].Trim();
            if (line.Length == 0 || line.StartsWith("//", StringComparison.Ordinal)) continue;

            try
            {
                var node = JsonNode.Parse(line) as JsonObject;
                if (node == null) throw new JsonException("строка не является объектом JSON");

                var version = node.TryGetPropertyValue("SchemaVersion", out var v) && v != null ? v.GetValue<int>() : 0;
                if (version > DetectionRecord.CurrentSchemaVersion)
                {
                    _preservedLines.Add(line);
                    report.FutureSchemaPreserved++;
                    continue;
                }

                if (version < DetectionRecord.CurrentSchemaVersion)
                {
                    node = DatabaseMigrations.Migrate(node, version);
                    report.Migrated++;
                }

                var record = node.Deserialize<DetectionRecord>(JsonFiles.CompactOptions) ?? throw new JsonException("пустая запись");
                Normalize(record);

                if (!ids.Add(record.RecordId))
                {
                    record.RecordId = Guid.NewGuid().ToString("N");
                    ids.Add(record.RecordId);
                    report.DuplicateIdsFixed++;
                }

                _records.Add(record);
                report.Loaded++;
            }
            catch (Exception ex) when (ex is JsonException or InvalidOperationException or FormatException or NotSupportedException or ArgumentException)
            {
                corrupt.Add($"// строка {i + 1}: {ex.Message}");
                corrupt.Add(lines[i]);
                report.Corrupt++;
            }
        }

        if (report.Corrupt > 0)
        {
            var q = Path + $".corrupt-{DateTime.UtcNow:yyyyMMdd-HHmmss}.txt";
            try
            {
                File.WriteAllLines(q, corrupt, new UTF8Encoding(false));
                report.QuarantineFile = q;
                report.Warnings.Add($"Повреждённых строк: {report.Corrupt}. Они сохранены в {System.IO.Path.GetFileName(q)}; остальные записи загружены.");
            }
            catch (Exception ex)
            {
                report.Warnings.Add($"Повреждённых строк: {report.Corrupt}. Не удалось записать файл карантина: {ex.Message}. Исходный файл не изменён до следующего сохранения — сделайте копию вручную.");
            }
        }

        if (report.DuplicateIdsFixed > 0) report.Warnings.Add($"Исправлено повторяющихся RecordId: {report.DuplicateIdsFixed}.");
        if (report.FutureSchemaPreserved > 0) report.Warnings.Add($"Записей более новой версии схемы: {report.FutureSchemaPreserved}. Они сохраняются без изменений.");
        return report;
    }

    private static void Normalize(DetectionRecord r)
    {
        if (string.IsNullOrWhiteSpace(r.RecordId)) r.RecordId = Guid.NewGuid().ToString("N");
        r.PlayerName ??= string.Empty;
        r.FriendCode ??= string.Empty;
        r.HashPuid ??= string.Empty;
        r.Platform ??= string.Empty;
        r.Level ??= string.Empty;
        r.GameVersion ??= string.Empty;
        r.Notes ??= string.Empty;
        r.RiskLevel ??= string.Empty;
        r.PreviousNames ??= new List<string>();
        r.DetectionEvents ??= new List<StoredEvent>();
        r.RuleIds ??= new List<string>();
        r.Evidence ??= new List<string>();
        r.ActionHistory ??= new List<StoredAction>();
        if (r.LastSeenUtc < r.FirstSeenUtc) r.LastSeenUtc = r.FirstSeenUtc;
    }

    /// <summary>Сериализация снимка (вызывается под блокировкой сервиса).</summary>
    public string Serialize()
    {
        var sb = new StringBuilder(_records.Count * 512 + 128);
        foreach (var r in _records)
            sb.Append(JsonSerializer.Serialize(r, JsonFiles.CompactOptions)).Append('\n');
        foreach (var line in _preservedLines)
            sb.Append(line).Append('\n');
        return sb.ToString();
    }

    /// <summary>Атомарная запись: временный файл → замена.</summary>
    public static void WriteAtomic(string path, string content)
    {
        var dir = System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(path))!;
        Directory.CreateDirectory(dir);
        var tmp = path + ".tmp";
        using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
        using (var writer = new StreamWriter(fs, new UTF8Encoding(false)))
        {
            writer.Write(content);
            writer.Flush();
            fs.Flush(true);
        }

        File.Move(tmp, path, true);
    }

    public void MarkSaved() => LastSavedUtc = DateTime.UtcNow;

    // ---------- операции над записями ----------

    public void Add(DetectionRecord record) => _records.Add(record);

    public DetectionRecord? Find(string friendCode, string hashPuid) =>
        _records.FirstOrDefault(r => r.Matches(friendCode, hashPuid));

    public DetectionRecord? Get(string recordId) =>
        _records.FirstOrDefault(r => string.Equals(r.RecordId, recordId, StringComparison.OrdinalIgnoreCase));

    public int RemoveWhere(Func<DetectionRecord, bool> predicate) => _records.RemoveAll(r => predicate(r));

    public int Clear()
    {
        var n = _records.Count;
        _records.Clear();
        return n;
    }

    // ---------- резервные копии ----------

    public string? CreateBackup(int maxBackups, string reason)
    {
        if (!File.Exists(Path)) return null;
        Directory.CreateDirectory(BackupDirectory);
        var name = $"{System.IO.Path.GetFileNameWithoutExtension(Path)}-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{reason}{System.IO.Path.GetExtension(Path)}";
        var target = System.IO.Path.Combine(BackupDirectory, name);
        var n = 1;
        while (File.Exists(target))
            target = System.IO.Path.Combine(BackupDirectory, System.IO.Path.GetFileNameWithoutExtension(name) + "-" + n++ + System.IO.Path.GetExtension(Path));
        File.Copy(Path, target);
        PruneBackups(maxBackups);
        return target;
    }

    public List<FileInfo> ListBackups()
    {
        if (!Directory.Exists(BackupDirectory)) return new List<FileInfo>();
        var stem = System.IO.Path.GetFileNameWithoutExtension(Path);
        return new DirectoryInfo(BackupDirectory).GetFiles(stem + "-*")
            .Where(f => f.Extension is ".kh" or ".kd")
            .OrderByDescending(f => f.LastWriteTimeUtc).ToList();
    }

    private void PruneBackups(int maxBackups)
    {
        foreach (var old in ListBackups().Skip(Math.Max(1, maxBackups)))
        {
            try
            {
                old.Delete();
            }
            catch
            {
                // не критично
            }
        }
    }
}

public sealed class DatabaseAccessException : Exception
{
    public DatabaseAccessException(string message, Exception inner) : base(message, inner)
    {
    }
}

/// <summary>Миграции схемы. Каждая миграция переводит JSON-объект на одну версию вперёд.</summary>
public static class DatabaseMigrations
{
    public static JsonObject Migrate(JsonObject node, int fromVersion)
    {
        var version = fromVersion;
        while (version < DetectionRecord.CurrentSchemaVersion)
        {
            node = version switch
            {
                0 => V0ToV1(node),
                _ => throw new NotSupportedException($"Нет миграции со схемы {version}"),
            };
            version++;
        }

        node["SchemaVersion"] = DetectionRecord.CurrentSchemaVersion;
        return node;
    }

    /// <summary>
    /// Схема 0 — записи без поля SchemaVersion (ручные правки или ранние черновики).
    /// Поддерживаются старые имена полей Name/Puid/Events/Note.
    /// </summary>
    private static JsonObject V0ToV1(JsonObject node)
    {
        Rename(node, "Name", "PlayerName");
        Rename(node, "Events", "DetectionEvents");
        Rename(node, "Note", "Notes");
        if (node.ContainsKey("Puid") && !node.ContainsKey("HashPuid"))
        {
            // Если в старой записи лежит сырой PUID — сохраняем только хеш.
            var raw = node["Puid"]?.GetValue<string>();
            node["HashPuid"] = Hashing.HashPuid(raw);
            node.Remove("Puid");
        }

        if (!node.ContainsKey("RecordId")) node["RecordId"] = Guid.NewGuid().ToString("N");
        return node;
    }

    private static void Rename(JsonObject node, string from, string to)
    {
        if (node.ContainsKey(from) && !node.ContainsKey(to))
        {
            var value = node[from];
            node.Remove(from);
            node[to] = value;
        }
    }
}
