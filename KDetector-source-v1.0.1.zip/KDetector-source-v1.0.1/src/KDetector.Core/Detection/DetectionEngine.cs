using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Game;
using KDetector.Core.Logging;
using KDetector.Core.Players;

namespace KDetector.Core.Detection;

/// <summary>Источник сведений о whitelist (база + конфигурация).</summary>
public interface IWhitelistProvider
{
    bool IsWhitelisted(PlayerIdentity player);
}

public sealed class NullWhitelist : IWhitelistProvider
{
    public static readonly NullWhitelist Instance = new();
    public bool IsWhitelisted(PlayerIdentity player) => false;
}

/// <summary>
/// Общая система событий обнаружения: применяет включённость правила, порог уверенности,
/// исключения, порог числа наблюдений в окне и публикует событие подписчикам
/// (модель риска, движок действий, база, интерфейс).
/// </summary>
public sealed class DetectionEngine
{
    private readonly RuleRegistry _registry;
    private readonly KdSettings _settings;
    private readonly IClock _clock;
    private readonly KdLog _log;
    private readonly Func<GameContext> _context;
    private readonly object _sync = new();
    private readonly Dictionary<string, Queue<long>> _pending = new();
    private long _lastPurgeMs;

    public DetectionEngine(RuleRegistry registry, KdSettings settings, IClock clock, KdLog log, Func<GameContext> context)
    {
        _registry = registry;
        _settings = settings;
        _clock = clock;
        _log = log;
        _context = context;
        Feed = new KDetector.Core.Common.RingBuffer<DetectionEvent>(Math.Max(50, settings.Detection.EventFeedCapacity));
    }

    public IWhitelistProvider Whitelist { get; set; } = NullWhitelist.Instance;

    /// <summary>Лента последних событий (для Dashboard и Detections).</summary>
    public KDetector.Core.Common.RingBuffer<DetectionEvent> Feed { get; }

    /// <summary>Подписчики получают каждое зарегистрированное событие. Исключение одного подписчика не мешает остальным.</summary>
    public event Action<DetectionEvent>? EventPublished;

    public long SessionEventCount { get; private set; }

    public RuleRegistry Registry => _registry;

    /// <summary>
    /// Обрабатывает кандидат. Возвращает событие, если оно зарегистрировано, иначе null.
    /// </summary>
    public DetectionEvent? Process(DetectionCandidate candidate)
    {
        if (!_settings.General.Enabled) return null;

        var rule = _registry.Get(candidate.RuleId);
        if (rule == null)
        {
            _log.Throttled("unknown-rule:" + candidate.RuleId, 60000, KdLogLevel.Warning, "Detection", $"Кандидат от незарегистрированного правила {candidate.RuleId} отброшен.");
            return null;
        }

        Interlocked.Increment(ref rule.Observations);
        var now = _clock.UtcNow;
        if (!_registry.IsActive(candidate.RuleId, now)) return null;

        var ruleSettings = _registry.Settings(candidate.RuleId);
        var minConfidence = ruleSettings.MinConfidence > 0
            ? ruleSettings.MinConfidence
            : Math.Max(_settings.Detection.GlobalMinConfidence, rule.Descriptor.DefaultMinConfidence);

        if (candidate.Confidence < minConfidence)
        {
            Interlocked.Increment(ref rule.SuppressedByConfidence);
            return null;
        }

        if (IsException(candidate.Player, ruleSettings.Exceptions))
        {
            Interlocked.Increment(ref rule.SuppressedByException);
            return null;
        }

        var ctx = _context();
        var playerKey = candidate.Player.Key(ctx.SessionId);
        var observationCount = 1;

        var threshold = Math.Max(1, ruleSettings.Threshold);
        if (threshold > 1)
        {
            var key = playerKey + "|" + candidate.RuleId + "|" + candidate.CorrelationKey;
            var windowMs = Math.Max(1, ruleSettings.WindowSeconds) * 1000L;
            var nowMs = _clock.MonotonicMs;
            lock (_sync)
            {
                PurgeIfNeeded(nowMs, windowMs);
                if (!_pending.TryGetValue(key, out var q))
                {
                    q = new Queue<long>();
                    _pending[key] = q;
                }

                while (q.Count > 0 && nowMs - q.Peek() >= windowMs) q.Dequeue();
                q.Enqueue(nowMs);
                if (q.Count < threshold)
                {
                    Interlocked.Increment(ref rule.SuppressedByThreshold);
                    return null;
                }

                observationCount = q.Count;
                q.Clear(); // после регистрации окно начинается заново — повторы не плодят событий каждый кадр
            }
        }

        var evt = new DetectionEvent
        {
            TimestampUtc = now,
            RuleId = rule.Descriptor.Id,
            RuleName = rule.Descriptor.Name,
            RuleVersion = rule.Descriptor.Version,
            Category = rule.Descriptor.Category,
            Evidence = candidate.Evidence,
            Severity = candidate.Severity,
            Confidence = Math.Round(Math.Max(0, Math.Min(1, candidate.Confidence)), 3),
            Player = candidate.Player.Clone(),
            PlayerKey = playerKey,
            Facts = candidate.Facts.ToList(),
            Summary = candidate.Summary,
            Hypothesis = candidate.Hypothesis,
            CorrelationKey = candidate.CorrelationKey,
            GameVersion = ctx.GameVersion,
            SessionId = ctx.SessionId,
            ObservationCount = observationCount,
            Whitelisted = SafeIsWhitelisted(candidate.Player),
            DryRun = _settings.General.DryRun,
        };

        Interlocked.Increment(ref rule.Events);
        rule.History.Add(evt);
        Feed.Add(evt);
        SessionEventCount++;

        Publish(evt);
        return evt;
    }

    /// <summary>
    /// Проходит ли кандидат фильтры правила (включено, уверенность, исключения) без учёта порога наблюдений.
    /// Используется для синхронного решения об отмене RPC.
    /// </summary>
    public bool WouldAccept(DetectionCandidate candidate, out DetectionCategory category)
    {
        category = default;
        var rule = _registry.Get(candidate.RuleId);
        if (rule == null || !_settings.General.Enabled) return false;
        if (!_registry.IsActive(candidate.RuleId, _clock.UtcNow)) return false;
        category = rule.Descriptor.Category;
        var rs = _registry.Settings(candidate.RuleId);
        var min = rs.MinConfidence > 0 ? rs.MinConfidence : Math.Max(_settings.Detection.GlobalMinConfidence, rule.Descriptor.DefaultMinConfidence);
        if (candidate.Confidence < min) return false;
        return !IsException(candidate.Player, rs.Exceptions);
    }

    private void Publish(DetectionEvent evt)
    {
        var handlers = EventPublished;
        if (handlers == null) return;
        foreach (var d in handlers.GetInvocationList())
        {
            try
            {
                ((Action<DetectionEvent>)d)(evt);
            }
            catch (Exception ex)
            {
                _log.Error("Detection", "Подписчик события обнаружения завершился с ошибкой", ex);
            }
        }
    }

    private bool SafeIsWhitelisted(PlayerIdentity player)
    {
        try
        {
            return Whitelist.IsWhitelisted(player);
        }
        catch (Exception ex)
        {
            _log.Error("Detection", "Ошибка проверки whitelist", ex);
            return false;
        }
    }

    internal static bool IsException(PlayerIdentity player, string exceptions)
    {
        if (string.IsNullOrWhiteSpace(exceptions)) return false;
        foreach (var item in KdSettings.SplitList(exceptions))
        {
            if (!string.IsNullOrEmpty(player.FriendCode) && item.Equals(player.FriendCode, StringComparison.OrdinalIgnoreCase)) return true;
            if (!string.IsNullOrEmpty(player.HashPuid) && item.Equals(player.HashPuid, StringComparison.OrdinalIgnoreCase)) return true;
        }

        return false;
    }

    private void PurgeIfNeeded(long nowMs, long windowMs)
    {
        if (nowMs - _lastPurgeMs < 30000 && _pending.Count < 5000) return;
        _lastPurgeMs = nowMs;
        var maxAge = Math.Max(windowMs, 3600_000L);
        foreach (var key in _pending.Where(p => p.Value.Count == 0 || nowMs - p.Value.Last() > maxAge).Select(p => p.Key).ToList())
            _pending.Remove(key);
    }

    /// <summary>Сброс накопленных порогов (например, при выходе из лобби).</summary>
    public void ResetPending()
    {
        lock (_sync) _pending.Clear();
    }

    public void ClearFeed()
    {
        Feed.Clear();
        SessionEventCount = 0;
    }
}
