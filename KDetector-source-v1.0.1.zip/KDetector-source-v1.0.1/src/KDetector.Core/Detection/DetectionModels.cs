using KDetector.Core.Players;

namespace KDetector.Core.Detection;

public enum DetectionCategory
{
    LevelSpoofing,
    PlatformSpoofing,
    InvalidPlatform,
    KnownClient,
    InvalidAction,
    RpcSpam,
    Identity,
}

/// <summary>
/// Характер доказательства. Разделение обязательно: совпадение сигнатуры клиента ≠ подтверждённое нарушение.
/// </summary>
public enum EvidenceKind
{
    /// <summary>Подозрительное, но допустимое протоколом поведение.</summary>
    SuspiciousBehavior,

    /// <summary>Сообщение, противоречащее известным правилам протокола или некорректно сериализованное.</summary>
    InvalidProtocol,

    /// <summary>Признак, совпадающий с публично известной сигнатурой стороннего клиента.</summary>
    KnownClientIndicator,

    /// <summary>Действие, однозначно невозможное в текущем состоянии игры.</summary>
    ConfirmedInvalidAction,
}

public enum Severity
{
    Info = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4,
}

/// <summary>Наблюдаемый факт: что именно увидели и откуда это значение.</summary>
public sealed class Fact
{
    public Fact()
    {
    }

    public Fact(string name, string value, string source)
    {
        Name = name;
        Value = value;
        Source = source;
    }

    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string Source { get; set; } = string.Empty;

    public override string ToString() => $"{Name} = {Value} [{Source}]";
}

/// <summary>Результат работы правила до применения порогов и исключений.</summary>
public sealed class DetectionCandidate
{
    public string RuleId { get; set; } = string.Empty;
    public PlayerIdentity Player { get; set; } = new();
    public Severity Severity { get; set; } = Severity.Low;
    public EvidenceKind Evidence { get; set; } = EvidenceKind.SuspiciousBehavior;

    /// <summary>Уверенность 0..1 в том, что наблюдение указывает на нарушение.</summary>
    public double Confidence { get; set; }

    public List<Fact> Facts { get; } = new();

    /// <summary>Краткое человекочитаемое описание того, что проверено.</summary>
    public string Summary { get; set; } = string.Empty;

    /// <summary>Гипотеза — отдельно от фактов. Может быть пустой.</summary>
    public string Hypothesis { get; set; } = string.Empty;

    /// <summary>
    /// Ключ корреляции: события с одним правилом и ключом считаются повторами одного наблюдения,
    /// а не независимыми доказательствами.
    /// </summary>
    public string CorrelationKey { get; set; } = string.Empty;

    /// <summary>Правило разрешает отменить вызвавшее событие (если политика и режим это позволяют).</summary>
    public bool Cancelable { get; set; }

    public DetectionCandidate AddFact(string name, string value, string source)
    {
        Facts.Add(new Fact(name, value, source));
        return this;
    }
}

/// <summary>Зарегистрированное событие обнаружения (после порогов, исключений и т.д.).</summary>
public sealed class DetectionEvent
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime TimestampUtc { get; set; }
    public string RuleId { get; set; } = string.Empty;
    public string RuleName { get; set; } = string.Empty;
    public int RuleVersion { get; set; }
    public DetectionCategory Category { get; set; }
    public EvidenceKind Evidence { get; set; }
    public Severity Severity { get; set; }
    public double Confidence { get; set; }
    public PlayerIdentity Player { get; set; } = new();
    public string PlayerKey { get; set; } = string.Empty;
    public List<Fact> Facts { get; set; } = new();
    public string Summary { get; set; } = string.Empty;
    public string Hypothesis { get; set; } = string.Empty;
    public string CorrelationKey { get; set; } = string.Empty;
    public string GameVersion { get; set; } = string.Empty;
    public string SessionId { get; set; } = string.Empty;

    /// <summary>Сколько исходных наблюдений объединено в это событие (порог/повторы).</summary>
    public int ObservationCount { get; set; } = 1;

    /// <summary>Рекомендуемое действие по политике (текст для пользователя).</summary>
    public string RecommendedAction { get; set; } = string.Empty;

    /// <summary>Игрок в whitelist: событие записано, но автоматические меры не применяются.</summary>
    public bool Whitelisted { get; set; }

    public bool DryRun { get; set; }
}

public static class DetectionText
{
    public static string Category(DetectionCategory c) => c switch
    {
        DetectionCategory.LevelSpoofing => "Уровень",
        DetectionCategory.PlatformSpoofing => "Подмена платформы",
        DetectionCategory.InvalidPlatform => "Некорректная платформа",
        DetectionCategory.KnownClient => "Известный клиент",
        DetectionCategory.InvalidAction => "Недопустимое действие",
        DetectionCategory.RpcSpam => "RPC-спам",
        DetectionCategory.Identity => "Идентичность",
        _ => c.ToString(),
    };

    public static string Evidence(EvidenceKind e) => e switch
    {
        EvidenceKind.SuspiciousBehavior => "Подозрительное поведение",
        EvidenceKind.InvalidProtocol => "Нарушение протокола",
        EvidenceKind.KnownClientIndicator => "Признак известного клиента",
        EvidenceKind.ConfirmedInvalidAction => "Подтверждённое недопустимое действие",
        _ => e.ToString(),
    };

    public static string Severity(Severity s) => s switch
    {
        Detection.Severity.Info => "Инфо",
        Detection.Severity.Low => "Низкая",
        Detection.Severity.Medium => "Средняя",
        Detection.Severity.High => "Высокая",
        Detection.Severity.Critical => "Критическая",
        _ => s.ToString(),
    };
}
