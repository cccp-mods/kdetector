using KDetector.Core.Common;
using KDetector.Core.Configuration;

namespace KDetector.Core.Detection;

public enum RuleAvailability
{
    /// <summary>Нужные данные доступны, правило работает.</summary>
    Available,

    /// <summary>Работает частично (например, только у хоста).</summary>
    Limited,

    /// <summary>Нужная точка интеграции не найдена в текущей версии игры — правило отключено.</summary>
    Unavailable,
}

/// <summary>Неизменяемое описание правила обнаружения.</summary>
public sealed class RuleDescriptor
{
    public string Id { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
    public int Version { get; init; } = 1;
    public DetectionCategory Category { get; init; }

    /// <summary>Какие данные проверяются (показывается в GUI).</summary>
    public string CheckedData { get; init; } = string.Empty;

    /// <summary>Что правило НЕ проверяет — честное ограничение для пользователя.</summary>
    public string Limitations { get; init; } = string.Empty;

    public double DefaultMinConfidence { get; init; } = 0.3;
    public int DefaultThreshold { get; init; } = 1;
    public int DefaultWindowSeconds { get; init; } = 60;

    public RuleSettings CreateDefaultSettings() => new()
    {
        Enabled = true,
        MinConfidence = 0,
        Threshold = DefaultThreshold,
        WindowSeconds = DefaultWindowSeconds,
        Exceptions = string.Empty,
    };
}

/// <summary>Состояние правила во время работы.</summary>
public sealed class RuleRuntime
{
    public RuleRuntime(RuleDescriptor descriptor)
    {
        Descriptor = descriptor;
    }

    public RuleDescriptor Descriptor { get; }
    public RuleAvailability Availability { get; set; } = RuleAvailability.Available;
    public string AvailabilityReason { get; set; } = string.Empty;

    /// <summary>Временное отключение до момента времени (UTC). Не сохраняется между запусками.</summary>
    public DateTime? DisabledUntilUtc { get; set; }

    public long Observations;
    public long Events;
    public long SuppressedByThreshold;
    public long SuppressedByConfidence;
    public long SuppressedByException;

    public KDetector.Core.Common.RingBuffer<DetectionEvent> History { get; } = new(100);
}

/// <summary>Реестр правил: расширяется без изменения остальной системы.</summary>
public sealed class RuleRegistry
{
    private readonly Dictionary<string, RuleRuntime> _rules = new(StringComparer.OrdinalIgnoreCase);
    private readonly KdSettings _settings;

    public RuleRegistry(KdSettings settings)
    {
        _settings = settings;
    }

    public void Register(RuleDescriptor descriptor)
    {
        if (string.IsNullOrWhiteSpace(descriptor.Id))
            throw new ArgumentException("Rule id is required", nameof(descriptor));
        if (_rules.ContainsKey(descriptor.Id))
            return; // повторная регистрация безопасно игнорируется

        _rules[descriptor.Id] = new RuleRuntime(descriptor);
        if (!_settings.Rules.ContainsKey(descriptor.Id))
            _settings.Rules[descriptor.Id] = descriptor.CreateDefaultSettings();
    }

    public RuleRuntime? Get(string id) => _rules.TryGetValue(id, out var r) ? r : null;

    public IReadOnlyList<RuleRuntime> All() => _rules.Values.OrderBy(r => r.Descriptor.Category).ThenBy(r => r.Descriptor.Id).ToList();

    public RuleSettings Settings(string id) => _settings.Rule(id);

    public bool IsActive(string id, DateTime utcNow)
    {
        var r = Get(id);
        if (r == null) return false;
        if (r.Availability == RuleAvailability.Unavailable) return false;
        if (r.DisabledUntilUtc.HasValue && r.DisabledUntilUtc.Value > utcNow) return false;
        return Settings(id).Enabled;
    }

    public void SetAvailability(string id, RuleAvailability availability, string reason)
    {
        var r = Get(id);
        if (r == null) return;
        r.Availability = availability;
        r.AvailabilityReason = reason;
    }

    public void SetAvailabilityForCategory(DetectionCategory category, RuleAvailability availability, string reason)
    {
        foreach (var r in _rules.Values.Where(r => r.Descriptor.Category == category))
        {
            r.Availability = availability;
            r.AvailabilityReason = reason;
        }
    }

    public void DisableTemporarily(string id, TimeSpan duration, DateTime utcNow)
    {
        var r = Get(id);
        if (r != null) r.DisabledUntilUtc = utcNow + duration;
    }

    public void ClearTemporaryDisable(string id)
    {
        var r = Get(id);
        if (r != null) r.DisabledUntilUtc = null;
    }

    /// <summary>Сброс настроек правила к его собственным значениям по умолчанию.</summary>
    public void ResetSettings(string id)
    {
        var r = Get(id);
        if (r == null) return;
        var target = Settings(id);
        var def = r.Descriptor.CreateDefaultSettings();
        target.Enabled = def.Enabled;
        target.MinConfidence = def.MinConfidence;
        target.Threshold = def.Threshold;
        target.WindowSeconds = def.WindowSeconds;
        target.Exceptions = def.Exceptions;
    }

    public void ResetAllSettings()
    {
        foreach (var id in _rules.Keys.ToList())
            ResetSettings(id);
    }

    public void ClearStatistics()
    {
        foreach (var r in _rules.Values)
        {
            Interlocked.Exchange(ref r.Observations, 0);
            Interlocked.Exchange(ref r.Events, 0);
            Interlocked.Exchange(ref r.SuppressedByThreshold, 0);
            Interlocked.Exchange(ref r.SuppressedByConfidence, 0);
            Interlocked.Exchange(ref r.SuppressedByException, 0);
            r.History.Clear();
        }
    }
}
