using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Network;

namespace KDetector.Core.Detection.Rules;

public enum PayloadCheck
{
    /// <summary>Только номер RPC.</summary>
    None,

    /// <summary>Первый байт полезной нагрузки равен PlayerId отправителя.</summary>
    FirstByteIsSenderPlayerId,

    /// <summary>Структура: string, string, int32 (чат-сообщение AUM по описанию BetterAmongUs).</summary>
    StringStringInt32,

    /// <summary>Структура: byte, packed int (=PlayerId отправителя), string, string, uint64, byte (по описанию BetterAmongUs).</summary>
    TaggedChatWithSenderId,
}

/// <summary>Сигнатура стороннего клиента. Все значения редактируемые и версионируемые (файл KnownClients.json).</summary>
public sealed class ClientSignature
{
    public string Id { get; set; } = string.Empty;
    public string Family { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public byte CallId { get; set; }

    /// <summary>Типы объектов, на которых ожидается RPC. Пусто = любой объект игрока.</summary>
    public List<NetObjectKind> ObjectKinds { get; set; } = new();

    public PayloadCheck PayloadCheck { get; set; } = PayloadCheck.None;

    /// <summary>Уверенность при совпадении только номера RPC.</summary>
    public double Confidence { get; set; } = 0.5;

    /// <summary>Уверенность при совпадении номера и структуры полезной нагрузки.</summary>
    public double ConfidenceWithPayload { get; set; } = 0.7;

    /// <summary>Версии игры (Application.version), для которых сигнатура проверена; "*" — любые.</summary>
    public List<string> GameVersions { get; set; } = new() { "*" };

    public string Source { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public sealed class SignatureCatalog
{
    public int SchemaVersion { get; set; } = 1;
    public string RulesVersion { get; set; } = string.Empty;
    public string ReviewedUtc { get; set; } = string.Empty;
    public string Notice { get; set; } = string.Empty;
    public List<ClientSignature> Signatures { get; set; } = new();

    /// <summary>
    /// Встроенный каталог. Номера RPC взяты из публичного исходного кода BetterAmongUs v1.3.4 (Enums/CustomRPC.cs,
    /// Modules/AntiCheat/RPCHandlers/Cheats/*). Независимо по исходникам самих клиентов не проверены — отсюда умеренная уверенность.
    /// MalumMenu в каталоге отсутствует сознательно: в его коде (v3.3.1) нет уникального идентифицирующего RPC.
    /// </summary>
    public static SignatureCatalog BuiltIn() => new()
    {
        SchemaVersion = 1,
        RulesVersion = "known-clients@2026.10.12-r1",
        ReviewedUtc = "2026-10-12",
        Notice = "Совпадение сигнатуры — признак (Known client indicator), а не доказательство. Номер RPC может совпасть с пользовательским RPC легитимного мода.",
        Signatures = new List<ClientSignature>
        {
            new()
            {
                Id = "sickomenu.rpc164", Family = "SickoMenu", CallId = 164, PayloadCheck = PayloadCheck.None,
                Confidence = 0.55, ConfidenceWithPayload = 0.55,
                Source = "BetterAmongUs v1.3.4: CustomRPC.Sicko = 420 (байт 164)",
            },
            new()
            {
                Id = "aum.rpc85", Family = "AUM (Among Us Menu)", CallId = 85, PayloadCheck = PayloadCheck.FirstByteIsSenderPlayerId,
                Confidence = 0.4, ConfidenceWithPayload = 0.65,
                Source = "BetterAmongUs v1.3.4: CustomRPC.AUM = 42069 (байт 85), первый байт = PlayerId отправителя",
            },
            new()
            {
                Id = "aum.chat101", Family = "AUM (Among Us Menu)", CallId = 101, PayloadCheck = PayloadCheck.StringStringInt32,
                Confidence = 0.4, ConfidenceWithPayload = 0.6,
                Source = "BetterAmongUs v1.3.4: CustomRPC.AUMChat = 101 (string, string, int32)",
            },
            new()
            {
                Id = "killnetwork.rpc250", Family = "KillNetwork", CallId = 250, PayloadCheck = PayloadCheck.None,
                Confidence = 0.55, ConfidenceWithPayload = 0.55,
                Source = "BetterAmongUs v1.3.4: CustomRPC.KillNetwork = 250",
            },
            new()
            {
                Id = "killnetwork.chat119", Family = "KillNetwork", CallId = 119, PayloadCheck = PayloadCheck.None,
                Confidence = 0.5, ConfidenceWithPayload = 0.5,
                Source = "BetterAmongUs v1.3.4: CustomRPC.KillNetworkChat = 119",
            },
            new()
            {
                Id = "modmenucrew.rpc202", Family = "ModMenuCrew", CallId = 202, PayloadCheck = PayloadCheck.None,
                Confidence = 0.5, ConfidenceWithPayload = 0.5,
                Source = "BetterAmongUs v1.3.4: CustomRPC.ModMenuCrew = 202",
            },
            new()
            {
                Id = "modmenucrew.chat201", Family = "ModMenuCrew", CallId = 201, PayloadCheck = PayloadCheck.TaggedChatWithSenderId,
                Confidence = 0.4, ConfidenceWithPayload = 0.7,
                Source = "BetterAmongUs v1.3.4: CustomRPC.ModMenuCrewChat = 201 (byte, packed senderId, string, string, uint64, byte)",
            },
        },
    };
}

/// <summary>Known Cheat Client Detection: сопоставление входящих RPC с каталогом сигнатур.</summary>
public sealed class KnownClientRules
{
    private readonly KdSettings _settings;
    private SignatureCatalog _catalog;
    private Dictionary<byte, List<ClientSignature>> _index = new();

    public KnownClientRules(KdSettings settings, SignatureCatalog catalog)
    {
        _settings = settings;
        _catalog = catalog;
        Rebuild(null);
    }

    public SignatureCatalog Catalog => _catalog;

    /// <summary>Сигнатуры, отключённые из-за конфликта с номером штатного RPC текущей версии.</summary>
    public List<string> Conflicts { get; } = new();

    public static RuleDescriptor Descriptor() => new()
    {
        Id = RuleIds.KnownClientSignature,
        Name = "Сигнатура известного клиента",
        Category = DetectionCategory.KnownClient,
        Description = "Входящий RPC совпадает с публично описанной сигнатурой стороннего клиента (номер и, где возможно, структура данных).",
        CheckedData = "Номер RPC, тип объекта, ограниченная копия полезной нагрузки (до 256 байт)",
        Limitations = "Не сканирует устройства. Клиенты без уникального сетевого признака (например, MalumMenu) этим правилом не опознаются — их действия ловят RPC Shield и проверка недопустимых действий.",
        DefaultMinConfidence = 0.3,
    };

    /// <summary>Перестраивает индекс; isVanillaRpc — проверка, определён ли номер в перечислении игры.</summary>
    public void Rebuild(Func<byte, bool>? isVanillaRpc, SignatureCatalog? catalog = null)
    {
        if (catalog != null) _catalog = catalog;
        Conflicts.Clear();
        var index = new Dictionary<byte, List<ClientSignature>>();
        foreach (var sig in _catalog.Signatures.Where(s => s.Enabled))
        {
            if (isVanillaRpc != null && isVanillaRpc(sig.CallId))
            {
                Conflicts.Add($"{sig.Id}: номер {sig.CallId} занят штатным RPC текущей версии — сигнатура отключена.");
                continue;
            }

            if (!index.TryGetValue(sig.CallId, out var list))
                index[sig.CallId] = list = new List<ClientSignature>();
            list.Add(sig);
        }

        _index = index;
    }

    /// <summary>Быстрая проверка без выделения памяти: нужен ли этот номер правилу.</summary>
    public bool IsCandidateCallId(byte callId) => _index.ContainsKey(callId);

    public DetectionCandidate? Evaluate(RpcObservation obs)
    {
        var s = _settings.KnownClients;
        if (!s.Enabled || obs.Sender == null || obs.RpcName != null) return null;
        if (s.DisableOnModdedProtocol && obs.Context.ModdedProtocol) return null;
        if (s.DisableOnUnofficialServer && !obs.Context.OnOfficialServer) return null;
        if (!_index.TryGetValue(obs.CallId, out var sigs)) return null;

        DetectionCandidate? best = null;
        foreach (var sig in sigs)
        {
            if (sig.ObjectKinds.Count > 0 && !sig.ObjectKinds.Contains(obs.ObjectKind)) continue;
            if (!VersionMatches(sig, obs.Context.GameVersion)) continue;

            var payloadResult = CheckPayload(sig.PayloadCheck, obs, out var payloadNote);
            if (payloadResult == PayloadMatch.Contradicts) continue; // структура явно другая — вероятно, это чужой мод с тем же номером

            var confidence = payloadResult == PayloadMatch.Matches ? sig.ConfidenceWithPayload : sig.Confidence;
            if (best != null && best.Confidence >= confidence) continue;

            best = new DetectionCandidate
            {
                RuleId = RuleIds.KnownClientSignature,
                Player = obs.Sender,
                Severity = Severity.High,
                Evidence = EvidenceKind.KnownClientIndicator,
                Confidence = confidence,
                Summary = $"RPC {obs.CallId} совпадает с сигнатурой «{sig.Family}» ({sig.Id}).",
                Hypothesis = $"Игрок, возможно, использует {sig.Family}. Это признак, а не доказательство.",
                CorrelationKey = sig.Id,
                Cancelable = false,
            }.AddFact("RPC", obs.RpcDisplay, "входящий RPC")
             .AddFact("Объект", obs.ObjectKind.ToString(), "входящий RPC")
             .AddFact("Проверка структуры", payloadNote, "полезная нагрузка")
             .AddFact("Источник сигнатуры", sig.Source, _catalog.RulesVersion);
        }

        return best;
    }

    private static bool VersionMatches(ClientSignature sig, string gameVersion) =>
        sig.GameVersions.Count == 0 || sig.GameVersions.Any(v => v == "*" || string.Equals(v, gameVersion, StringComparison.OrdinalIgnoreCase));

    private enum PayloadMatch
    {
        NotChecked,
        Matches,
        Contradicts,
    }

    private static PayloadMatch CheckPayload(PayloadCheck check, RpcObservation obs, out string note)
    {
        if (check == PayloadCheck.None)
        {
            note = "не проверялась (сигнатура только по номеру)";
            return PayloadMatch.NotChecked;
        }

        var bytes = obs.GetPayload(256);
        var r = new PayloadReader(bytes);
        var senderId = obs.Sender?.PlayerId ?? 255;
        switch (check)
        {
            case PayloadCheck.FirstByteIsSenderPlayerId:
                if (r.TryReadByte(out var b))
                {
                    note = b == senderId ? $"первый байт = PlayerId отправителя ({b})" : $"первый байт {b} ≠ PlayerId {senderId}";
                    return b == senderId ? PayloadMatch.Matches : PayloadMatch.Contradicts;
                }

                note = "нет данных";
                return PayloadMatch.Contradicts;

            case PayloadCheck.StringStringInt32:
                if (r.TryReadString(out _) && r.TryReadString(out _) && r.TryReadInt32(out _))
                {
                    note = "структура string, string, int32 совпала";
                    return PayloadMatch.Matches;
                }

                note = "структура не совпала";
                return PayloadMatch.Contradicts;

            case PayloadCheck.TaggedChatWithSenderId:
                if (r.TryReadByte(out _) && r.TryReadPackedInt32(out var sid) && r.TryReadString(out _) &&
                    r.TryReadString(out _) && r.TryReadUInt64(out _) && r.TryReadByte(out _))
                {
                    if (sid == senderId)
                    {
                        note = "структура совпала, senderId = PlayerId отправителя";
                        return PayloadMatch.Matches;
                    }

                    note = $"структура совпала, но senderId {sid} ≠ {senderId}";
                    return PayloadMatch.Contradicts;
                }

                note = "структура не совпала";
                return PayloadMatch.Contradicts;
        }

        note = "неизвестный тип проверки";
        return PayloadMatch.NotChecked;
    }
}
