using KDetector.Core.Configuration;
using KDetector.Core.Players;

namespace KDetector.Core.Detection.Rules;

/// <summary>
/// LVL Spoofer Detector.
/// Важно: настоящий уровень аккаунта клиентский плагин проверить НЕ может — у клиента нет доступа к серверным данным.
/// Проверяется только: представление значения, (опционально) пользовательский диапазон и изменения внутри одного подключения.
/// Высокий или низкий уровень сам по себе подозрением не считается.
/// </summary>
public sealed class LevelRules
{
    private const uint SignBit = 0x8000_0000;
    private readonly KdSettings _settings;
    private readonly object _sync = new();
    private readonly Dictionary<int, LevelState> _byClient = new();
    private int _matchesEnded;

    public LevelRules(KdSettings settings)
    {
        _settings = settings;
    }

    public static IEnumerable<RuleDescriptor> Descriptors()
    {
        yield return new RuleDescriptor
        {
            Id = RuleIds.LevelInvalidValue,
            Name = "Некорректное значение уровня",
            Category = DetectionCategory.LevelSpoofing,
            Description = "Значение уровня с установленным старшим битом: отрицательное число или переполнение, переданное как беззнаковое.",
            CheckedData = "NetworkedPlayerInfo.PlayerLevel (uint)",
            Limitations = "Не проверяет настоящий уровень аккаунта — такой проверки у клиента нет.",
            DefaultMinConfidence = 0.3,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.LevelOutOfRange,
            Name = "Уровень вне заданного диапазона",
            Category = DetectionCategory.LevelSpoofing,
            Description = "Уровень вне диапазона, заданного пользователем. По умолчанию выключено: официальный предел не подтверждён.",
            CheckedData = "NetworkedPlayerInfo.PlayerLevel",
            Limitations = "Диапазон задаётся вручную; само значение уровня не доказывает подмену.",
            DefaultMinConfidence = 0.2,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.LevelAnomalousChange,
            Name = "Аномальное изменение уровня",
            Category = DetectionCategory.LevelSpoofing,
            Description = "Уровень уменьшился или вырос сильнее, чем возможно после завершённых матчей, в пределах одного подключения.",
            CheckedData = "История PlayerLevel в текущем подключении + число завершённых матчей",
            Limitations = "Между подключениями история не сравнивается: уровень легитимно растёт со временем.",
            DefaultMinConfidence = 0.2,
        };
    }

    /// <summary>Вызывается игровым слоем при завершении матча (после него уровень может легитимно вырасти).</summary>
    public void OnMatchEnded()
    {
        lock (_sync) _matchesEnded++;
    }

    public void Forget(int clientId)
    {
        lock (_sync) _byClient.Remove(clientId);
    }

    public void Reset()
    {
        lock (_sync)
        {
            _byClient.Clear();
            _matchesEnded = 0;
        }
    }

    /// <summary>Наблюдение уровня. Возвращает 0..N кандидатов.</summary>
    public List<DetectionCandidate> Observe(PlayerIdentity player, uint rawLevel, string source)
    {
        var result = new List<DetectionCandidate>();
        var s = _settings.Level;
        if (!s.Enabled || player.IsLocal) return result;

        if (s.CheckInvalidValues && (rawLevel & SignBit) != 0)
        {
            var asSigned = unchecked((int)rawLevel);
            result.Add(new DetectionCandidate
            {
                RuleId = RuleIds.LevelInvalidValue,
                Player = player,
                Severity = Severity.Medium,
                Evidence = EvidenceKind.InvalidProtocol,
                Confidence = s.InvalidValueConfidence,
                Summary = $"Уровень передан как {rawLevel} (как знаковое число: {asSigned}).",
                Hypothesis = "Значение могло быть подставлено модифицированным клиентом; легитимный клиент такого значения не получает.",
                CorrelationKey = "invalid",
            }.AddFact("PlayerLevel (raw)", rawLevel.ToString(), source)
             .AddFact("Как int32", asSigned.ToString(), "вычислено"));
        }

        var display = (ulong)rawLevel + 1UL;
        if (s.RangeCheckEnabled && (rawLevel & SignBit) == 0 && (display < (ulong)s.MinLevel || display > (ulong)s.MaxLevel))
        {
            result.Add(new DetectionCandidate
            {
                RuleId = RuleIds.LevelOutOfRange,
                Player = player,
                Severity = Severity.Low,
                Evidence = EvidenceKind.SuspiciousBehavior,
                Confidence = 0.3,
                Summary = $"Уровень {display} вне пользовательского диапазона {s.MinLevel}–{s.MaxLevel}.",
                Hypothesis = "Диапазон задан вручную; это не доказательство подмены.",
                CorrelationKey = "range",
            }.AddFact("Уровень (как в игре)", display.ToString(), source)
             .AddFact("Диапазон", $"{s.MinLevel}–{s.MaxLevel}", "конфигурация"));
        }

        if (s.CheckAnomalousChanges && player.ClientId >= 0)
        {
            DetectionCandidate? change = null;
            lock (_sync)
            {
                // Значение 0 — это и «уровень 1», и значение по умолчанию до прихода данных игрока.
                // Чтобы не принять догрузку данных за изменение, 0 не используется как опорная точка.
                if (rawLevel == 0)
                {
                    // ничего не делаем: дождёмся реального значения
                }
                else if (_byClient.TryGetValue(player.ClientId, out var state))
                {
                    if (state.Value != rawLevel)
                    {
                        change = EvaluateChange(player, state, rawLevel, source, s);
                        state.Value = rawLevel;
                        state.MatchesAtValue = _matchesEnded;
                    }
                }
                else
                {
                    _byClient[player.ClientId] = new LevelState { Value = rawLevel, MatchesAtValue = _matchesEnded };
                }
            }

            if (change != null) result.Add(change);
        }

        return result;
    }

    private DetectionCandidate? EvaluateChange(PlayerIdentity player, LevelState state, uint newRaw, string source, LevelSettings s)
    {
        var matches = _matchesEnded - state.MatchesAtValue;
        var oldDisplay = (ulong)state.Value + 1UL;
        var newDisplay = (ulong)newRaw + 1UL;

        if (newRaw < state.Value)
        {
            return new DetectionCandidate
            {
                RuleId = RuleIds.LevelAnomalousChange,
                Player = player,
                Severity = Severity.Medium,
                Evidence = EvidenceKind.SuspiciousBehavior,
                Confidence = Math.Min(1, s.ChangeConfidence + 0.15),
                Summary = $"Уровень уменьшился в пределах подключения: {oldDisplay} → {newDisplay}.",
                Hypothesis = "Уровень в обычной игре не уменьшается; возможна подмена значения.",
                CorrelationKey = "decrease",
            }.AddFact("Было", oldDisplay.ToString(), source)
             .AddFact("Стало", newDisplay.ToString(), source)
             .AddFact("Завершённых матчей между наблюдениями", matches.ToString(), "трекер матчей");
        }

        var allowed = (ulong)Math.Max(0, matches) * (ulong)s.MaxIncreasePerMatch;
        var increase = (ulong)(newRaw - state.Value);
        if (increase > allowed)
        {
            return new DetectionCandidate
            {
                RuleId = RuleIds.LevelAnomalousChange,
                Player = player,
                Severity = Severity.Low,
                Evidence = EvidenceKind.SuspiciousBehavior,
                Confidence = s.ChangeConfidence,
                Summary = matches == 0
                    ? $"Уровень изменился без завершения матча: {oldDisplay} → {newDisplay}."
                    : $"Уровень вырос на {increase} за {matches} матч(ей) (норма до {allowed}).",
                Hypothesis = "Возможна подмена уровня. Учтите: данные игрока могут догружаться с задержкой.",
                CorrelationKey = "increase",
            }.AddFact("Было", oldDisplay.ToString(), source)
             .AddFact("Стало", newDisplay.ToString(), source)
             .AddFact("Завершённых матчей между наблюдениями", matches.ToString(), "трекер матчей");
        }

        return null;
    }

    private sealed class LevelState
    {
        public uint Value;
        public int MatchesAtValue;
    }
}
