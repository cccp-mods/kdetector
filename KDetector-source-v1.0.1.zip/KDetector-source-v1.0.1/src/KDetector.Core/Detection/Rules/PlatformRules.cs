using System.Globalization;
using KDetector.Core.Configuration;
using KDetector.Core.Players;

namespace KDetector.Core.Detection.Rules;

/// <summary>
/// Platform Spoofer Detector и Invalid Platform Detector.
/// Invalid Platform — значение не принадлежит перечислению платформ текущей версии (наблюдаемый факт).
/// Platform Spoofing — сетевые метаданные противоречат друг другу (подозрение).
/// Заявленная платформа не является доказательством реального устройства.
/// </summary>
public sealed class PlatformRules
{
    private readonly KdSettings _settings;
    private readonly object _sync = new();
    private readonly Dictionary<int, PlatformInfo> _firstSeen = new();

    public PlatformRules(KdSettings settings)
    {
        _settings = settings;
    }

    public static IEnumerable<RuleDescriptor> Descriptors()
    {
        yield return new RuleDescriptor
        {
            Id = RuleIds.PlatformConsoleIdMismatch,
            Name = "Несогласованный идентификатор консоли",
            Category = DetectionCategory.PlatformSpoofing,
            Description = "Заявлена платформа Xbox / Microsoft Store / PlayStation, но идентификатор консоли отсутствует или имеет неожиданную длину.",
            CheckedData = "PlatformSpecificData.Platform, XboxPlatformId, PsnPlatformId",
            Limitations = "Диапазоны длины — эвристика сообщества, не спецификация. Подмена на ПК-платформу (Steam/Epic) этой проверкой не обнаруживается.",
            DefaultMinConfidence = 0.3,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.PlatformSessionChange,
            Name = "Смена платформы в пределах подключения",
            Category = DetectionCategory.PlatformSpoofing,
            Description = "Данные платформы игрока изменились без переподключения.",
            CheckedData = "PlatformSpecificData в текущем подключении",
            Limitations = "Не сравнивает разные подключения: игрок может законно играть с разных устройств.",
            DefaultMinConfidence = 0.3,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.InvalidPlatformUndefined,
            Name = "Значение платформы вне перечисления игры",
            Category = DetectionCategory.InvalidPlatform,
            Description = "Числовое значение платформы не определено в перечислении Platforms текущей версии и не входит в список разрешённых нестандартных значений.",
            CheckedData = "PlatformSpecificData.Platform против перечисления Platforms из игровых сборок",
            Limitations = "Обнаруживает только неизвестное значение; не доказывает умышленную подмену. Новые версии игры могут добавить значения.",
            DefaultMinConfidence = 0.3,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.InvalidPlatformUnknown,
            Name = "Платформа Unknown",
            Category = DetectionCategory.InvalidPlatform,
            Description = "Клиент сообщил значение Unknown.",
            CheckedData = "PlatformSpecificData.Platform",
            Limitations = "Слабый сигнал: значение определено игрой.",
            DefaultMinConfidence = 0.2,
        };
    }

    public void Forget(int clientId)
    {
        lock (_sync) _firstSeen.Remove(clientId);
    }

    public void Reset()
    {
        lock (_sync) _firstSeen.Clear();
    }

    public HashSet<int> AllowedCustomIds()
    {
        var set = new HashSet<int>();
        foreach (var item in KdSettings.SplitList(_settings.InvalidPlatform.AllowedCustomPlatformIds))
            if (int.TryParse(item, NumberStyles.Integer, CultureInfo.InvariantCulture, out var id))
                set.Add(id);
        return set;
    }

    public List<DetectionCandidate> Observe(PlayerIdentity player, PlatformInfo info)
    {
        var result = new List<DetectionCandidate>();
        if (player.IsLocal) return result;

        var allowed = AllowedCustomIds();
        var isAllowedCustom = allowed.Contains(info.PlatformId);

        // ---- Invalid Platform: факт неизвестного значения
        var inv = _settings.InvalidPlatform;
        if (inv.Enabled && !isAllowedCustom)
        {
            if (info.EnumName == null)
            {
                result.Add(new DetectionCandidate
                {
                    RuleId = RuleIds.InvalidPlatformUndefined,
                    Player = player,
                    Severity = Severity.Medium,
                    Evidence = EvidenceKind.InvalidProtocol,
                    Confidence = inv.UndefinedConfidence,
                    Summary = $"Значение платформы {info.PlatformId} не определено в перечислении игры.",
                    Hypothesis = string.Empty,
                    CorrelationKey = "undefined:" + info.PlatformId,
                }.AddFact("Platform (число)", info.PlatformId.ToString(CultureInfo.InvariantCulture), info.Source)
                 .AddFact("Разрешённые нестандартные значения", string.Join(",", allowed), "конфигурация"));
            }
            else if (inv.FlagUnknownValue && string.Equals(info.EnumName, inv.UnknownEnumName, StringComparison.OrdinalIgnoreCase))
            {
                result.Add(new DetectionCandidate
                {
                    RuleId = RuleIds.InvalidPlatformUnknown,
                    Player = player,
                    Severity = Severity.Low,
                    Evidence = EvidenceKind.InvalidProtocol,
                    Confidence = inv.UnknownConfidence,
                    Summary = "Клиент сообщил платформу Unknown.",
                    CorrelationKey = "unknown",
                }.AddFact("Platform", info.Display, info.Source));
            }
        }

        // ---- Platform Spoofing: противоречие метаданных
        var sp = _settings.PlatformSpoof;
        if (sp.Enabled && sp.CheckConsoleIdConsistency && info.EnumName != null && !isAllowedCustom)
        {
            var xboxNames = KdSettings.SplitList(sp.XboxEnumNames);
            var psnNames = KdSettings.SplitList(sp.PsnEnumNames);
            if (xboxNames.Contains(info.EnumName, StringComparer.OrdinalIgnoreCase))
                CheckConsoleId(result, player, info, "XboxPlatformId", info.XboxPlatformId, sp.XboxIdMinDigits, sp.XboxIdMaxDigits, sp.ConsoleIdConfidence);
            else if (psnNames.Contains(info.EnumName, StringComparer.OrdinalIgnoreCase))
                CheckConsoleId(result, player, info, "PsnPlatformId", info.PsnPlatformId, sp.PsnIdMinDigits, sp.PsnIdMaxDigits, sp.ConsoleIdConfidence);
        }

        if (sp.Enabled && sp.CheckSessionChanges && player.ClientId >= 0)
        {
            PlatformInfo? previous = null;
            lock (_sync)
            {
                if (_firstSeen.TryGetValue(player.ClientId, out var first))
                {
                    if (!first.SameAs(info)) previous = first;
                    _firstSeen[player.ClientId] = info.Clone();
                }
                else
                {
                    _firstSeen[player.ClientId] = info.Clone();
                }
            }

            if (previous != null)
            {
                result.Add(new DetectionCandidate
                {
                    RuleId = RuleIds.PlatformSessionChange,
                    Player = player,
                    Severity = Severity.Medium,
                    Evidence = EvidenceKind.SuspiciousBehavior,
                    Confidence = sp.ChangeConfidence,
                    Summary = $"Платформа изменилась в пределах подключения: {previous.Display} → {info.Display}.",
                    Hypothesis = "Обычный клиент не меняет платформу без переподключения.",
                    CorrelationKey = "change",
                }.AddFact("Было", previous.Display, previous.Source)
                 .AddFact("Стало", info.Display, info.Source));
            }
        }

        return result;
    }

    private static void CheckConsoleId(List<DetectionCandidate> result, PlayerIdentity player, PlatformInfo info, string field, ulong id, int minDigits, int maxDigits, double confidence)
    {
        var digits = id == 0 ? 0 : id.ToString(CultureInfo.InvariantCulture).Length;
        if (id != 0 && digits >= minDigits && digits <= maxDigits) return;

        var missing = id == 0;
        result.Add(new DetectionCandidate
        {
            RuleId = RuleIds.PlatformConsoleIdMismatch,
            Player = player,
            Severity = Severity.Medium,
            Evidence = EvidenceKind.SuspiciousBehavior,
            // Отсутствующий идентификатор — более сильный признак, чем непривычная длина.
            Confidence = missing ? Math.Min(1, confidence + 0.1) : confidence,
            Summary = missing
                ? $"Заявлена платформа {info.Display}, но {field} отсутствует (0)."
                : $"Заявлена платформа {info.Display}, но длина {field} = {digits} цифр (ожидается {minDigits}–{maxDigits}).",
            Hypothesis = "Метаданные платформы противоречат друг другу; это характерно для подмены платформы клиентом.",
            CorrelationKey = field + (missing ? ":missing" : ":length"),
        }.AddFact("Platform", info.Display, info.Source)
         .AddFact(field, id.ToString(CultureInfo.InvariantCulture), info.Source)
         .AddFact("Ожидаемая длина", $"{minDigits}–{maxDigits}", "конфигурация (эвристика)"));
    }
}
