using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Game;
using KDetector.Core.Network;

namespace KDetector.Core.Detection.Rules;

public enum ProtocolCondition
{
    /// <summary>Нарушение при любом отправителе в указанных фазах.</summary>
    Always,

    /// <summary>Нарушение, если владелец объекта — не хост.</summary>
    SenderNotHost,
}

/// <summary>Одно правило протокола (файл ProtocolRules.json).</summary>
public sealed class ProtocolRule
{
    public string Id { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public string Description { get; set; } = string.Empty;
    public List<string> RpcNames { get; set; } = new();
    public ProtocolCondition Condition { get; set; } = ProtocolCondition.Always;

    /// <summary>Фазы, в которых RPC недопустим. Пусто = любая фаза онлайн-лобби/матча.</summary>
    public List<GamePhase> Phases { get; set; } = new();

    public double Confidence { get; set; } = 0.5;
    public Severity Severity { get; set; } = Severity.Medium;
    public EvidenceKind Evidence { get; set; } = EvidenceKind.InvalidProtocol;

    /// <summary>Отмена обработки допустима (не приводит к рассинхронизации). Фактическая отмена ещё зависит от профиля действий.</summary>
    public bool Cancelable { get; set; }

    public string Source { get; set; } = string.Empty;
}

public sealed class ProtocolRuleSet
{
    public int SchemaVersion { get; set; } = 1;
    public string RulesVersion { get; set; } = string.Empty;
    public string ReviewedUtc { get; set; } = string.Empty;
    public string Notice { get; set; } = string.Empty;
    public List<ProtocolRule> Rules { get; set; } = new();

    /// <summary>
    /// Встроенные правила. Наборы RPC соответствуют проверкам, которые BetterAmongUs v1.3.4 применяет на Among Us 2026.9.29
    /// (BetterAntiCheat.CheckCancelRPC). Уверенность снижена там, где атрибуция отправителя неоднозначна.
    /// </summary>
    public static ProtocolRuleSet BuiltIn() => new()
    {
        SchemaVersion = 1,
        RulesVersion = "protocol@2026.10.12-r1",
        ReviewedUtc = "2026-10-12",
        Notice = "Имена RPC сопоставляются с перечислением RpcCalls текущей версии игры; отсутствующие имена просто не срабатывают.",
        Rules = new List<ProtocolRule>
        {
            new()
            {
                Id = "host-only-rpc-from-non-host",
                Description = "Только хост отправляет эти RPC. Получен RPC на объекте игрока, который не является хостом.",
                RpcNames = new() { "SetTasks", "ExtendLobbyTimer", "CloseMeeting" },
                Condition = ProtocolCondition.SenderNotHost,
                Confidence = 0.6,
                Severity = Severity.Medium,
                Evidence = EvidenceKind.InvalidProtocol,
                Cancelable = true,
                Source = "BetterAmongUs v1.3.4 (InvalidHostRPC). Атрибуция по владельцу объекта.",
            },
            new()
            {
                Id = "cosmetics-during-match",
                Description = "Смена косметики/цвета во время матча (в обычной игре недоступна).",
                RpcNames = new() { "SetColor", "SetHatStr", "SetSkinStr", "SetVisorStr", "SetPetStr", "SetNamePlateStr" },
                Condition = ProtocolCondition.Always,
                Phases = new() { GamePhase.Tasks, GamePhase.Meeting },
                Confidence = 0.7,
                Severity = Severity.Medium,
                Evidence = EvidenceKind.ConfirmedInvalidAction,
                Cancelable = true,
                Source = "BetterAmongUs v1.3.4 (InvalidSetRPC).",
            },
            new()
            {
                Id = "match-rpc-in-lobby",
                Description = "Игровое действие матча, полученное в лобби.",
                RpcNames = new()
                {
                    "StartMeeting", "ReportDeadBody", "SendChatNote", "CloseMeeting", "Exiled", "CastVote", "ClearVote",
                    "ClimbLadder", "UsePlatform", "UseZipline", "CompleteTask", "BootFromVent", "EnterVent",
                    "ExitVent", "CloseDoorsOfType", "CheckMurder", "MurderPlayer", "CheckShapeshift", "Shapeshift",
                    "RejectShapeshift", "CheckProtect", "ProtectPlayer", "CheckAppear", "StartAppear", "CheckVanish", "StartVanish",
                },
                Condition = ProtocolCondition.Always,
                Phases = new() { GamePhase.Lobby },
                Confidence = 0.75,
                Severity = Severity.High,
                Evidence = EvidenceKind.ConfirmedInvalidAction,
                Cancelable = true,
                Source = "BetterAmongUs v1.3.4 (InvalidLobbyRPC), без SetRole: назначение ролей происходит на стыке лобби и матча.",
            },
        },
    };
}

/// <summary>Invalid Action Detector: проверка RPC против фазы игры и правил протокола; учёт неизвестных номеров RPC.</summary>
public sealed class ProtocolRules
{
    private readonly KdSettings _settings;
    private readonly IClock _clock;
    private ProtocolRuleSet _set;
    private Dictionary<string, List<ProtocolRule>> _byName = new(StringComparer.Ordinal);

    public ProtocolRules(KdSettings settings, ProtocolRuleSet set, IClock clock)
    {
        _settings = settings;
        _clock = clock;
        _set = set;
        Rebuild();
    }

    public ProtocolRuleSet RuleSet => _set;

    public static IEnumerable<RuleDescriptor> Descriptors()
    {
        yield return new RuleDescriptor
        {
            Id = RuleIds.InvalidActionProtocol,
            Name = "Недопустимое действие",
            Category = DetectionCategory.InvalidAction,
            Description = "RPC противоречит фазе игры или правам отправителя (правила из ProtocolRules.json).",
            CheckedData = "Номер/имя RPC, фаза игры, является ли владелец объекта хостом",
            Limitations = "Отправитель определяется по владельцу объекта. Вне официальных серверов и в модифицированных лобби по умолчанию приостановлено. Саботажи клиентов видит только хост.",
            DefaultMinConfidence = 0.3,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.UnknownRpc,
            Name = "RPC вне перечисления игры",
            Category = DetectionCategory.InvalidAction,
            Description = "Получен RPC с номером, которого нет в перечислении RpcCalls текущей версии (только журнал, без блокировки).",
            CheckedData = "Номер RPC",
            Limitations = "Легитимные моды используют собственные номера RPC; поэтому только журналирование.",
            DefaultMinConfidence = 0.1,
            DefaultThreshold = 3,
            DefaultWindowSeconds = 30,
        };
    }

    public void Rebuild(ProtocolRuleSet? set = null)
    {
        if (set != null) _set = set;
        var map = new Dictionary<string, List<ProtocolRule>>(StringComparer.Ordinal);
        foreach (var rule in _set.Rules.Where(r => r.Enabled))
        foreach (var name in rule.RpcNames)
        {
            if (!map.TryGetValue(name, out var list)) map[name] = list = new List<ProtocolRule>();
            list.Add(rule);
        }

        _byName = map;
    }

    /// <summary>Почему проверки сейчас приостановлены (null — активны).</summary>
    public string? SuspendedReason(GameContext ctx)
    {
        var s = _settings.InvalidActions;
        if (!s.Enabled) return "выключено в настройках";
        if (s.SuspendOnUnofficialServer && !ctx.OnOfficialServer) return "не официальный сервер";
        if (s.SuspendOnModdedProtocol && ctx.ModdedProtocol) return "модифицированный протокол лобби";
        return null;
    }

    public IEnumerable<DetectionCandidate> Evaluate(RpcObservation obs, bool isKnownSignatureCallId)
    {
        if (obs.Sender == null) yield break;
        var ctx = obs.Context;
        if (!ctx.InOnlineLobbyOrGame) yield break;
        if (SuspendedReason(ctx) != null) yield break;

        if (obs.RpcName == null)
        {
            if (!isKnownSignatureCallId && _settings.RpcShield.LogUnknownRpcs)
            {
                yield return new DetectionCandidate
                {
                    RuleId = RuleIds.UnknownRpc,
                    Player = obs.Sender,
                    Severity = Severity.Info,
                    Evidence = EvidenceKind.InvalidProtocol,
                    Confidence = 0.2,
                    Summary = $"RPC #{obs.CallId} отсутствует в перечислении игры.",
                    Hypothesis = "Пользовательский RPC мода или клиента.",
                    CorrelationKey = "unknown:" + obs.CallId,
                    Cancelable = false,
                }.AddFact("RPC", obs.RpcDisplay, "входящий RPC")
                 .AddFact("Объект", obs.ObjectKind.ToString(), "входящий RPC");
            }

            yield break;
        }

        if (!_byName.TryGetValue(obs.RpcName, out var rules)) yield break;
        var inGrace = _clock.MonotonicMs - ctx.PhaseChangedMs < _settings.InvalidActions.PhaseGraceSeconds * 1000;
        foreach (var rule in rules)
        {
            if (rule.Phases.Count > 0 && !rule.Phases.Contains(ctx.Phase)) continue;
            if (rule.Phases.Count > 0 && inGrace) continue; // фаза только что сменилась — сообщения могли прийти «на стыке»
            if (rule.Condition == ProtocolCondition.SenderNotHost && obs.SenderIsHost) continue;

            yield return new DetectionCandidate
            {
                RuleId = RuleIds.InvalidActionProtocol,
                Player = obs.Sender,
                Severity = rule.Severity,
                Evidence = rule.Evidence,
                Confidence = rule.Confidence,
                Summary = $"{obs.RpcDisplay} в фазе {ctx.Phase}: {rule.Description}",
                Hypothesis = rule.Condition == ProtocolCondition.SenderNotHost
                    ? "Отправитель определён по владельцу объекта; хост может отправлять RPC от имени других объектов."
                    : string.Empty,
                CorrelationKey = rule.Id + ":" + obs.RpcName,
                Cancelable = rule.Cancelable,
            }.AddFact("RPC", obs.RpcDisplay, "входящий RPC")
             .AddFact("Фаза", ctx.Phase.ToString(), "состояние игры")
             .AddFact("Владелец объекта — хост", obs.SenderIsHost ? "да" : "нет", "состояние лобби")
             .AddFact("Правило", rule.Id, _set.RulesVersion);
        }
    }
}
