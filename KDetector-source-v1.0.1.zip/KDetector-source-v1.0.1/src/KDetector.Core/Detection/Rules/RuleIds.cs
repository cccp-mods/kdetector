namespace KDetector.Core.Detection.Rules;

/// <summary>Идентификаторы правил. Стабильны между версиями: на них ссылаются настройки и база.</summary>
public static class RuleIds
{
    public const string LevelInvalidValue = "level.invalid-value";
    public const string LevelOutOfRange = "level.out-of-range";
    public const string LevelAnomalousChange = "level.anomalous-change";

    public const string PlatformConsoleIdMismatch = "platform.console-id-mismatch";
    public const string PlatformSessionChange = "platform.session-change";

    public const string InvalidPlatformUndefined = "invalid-platform.undefined-value";
    public const string InvalidPlatformUnknown = "invalid-platform.unknown-value";

    public const string KnownClientSignature = "known-client.signature";

    public const string InvalidActionProtocol = "invalid-action.protocol-rule";
    public const string UnknownRpc = "invalid-action.unknown-rpc";

    public const string RpcRateCategory = "rpc-shield.category-rate";
    public const string RpcRateGlobal = "rpc-shield.global-rate";
}
