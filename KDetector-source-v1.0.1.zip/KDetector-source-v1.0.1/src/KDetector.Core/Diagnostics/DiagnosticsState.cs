namespace KDetector.Core.Diagnostics;

public enum ModuleState
{
    Ok,
    Warning,
    Disabled,
    Error,
}

public sealed class ModuleStatus
{
    public string Name { get; set; } = string.Empty;
    public ModuleState State { get; set; }
    public string Detail { get; set; } = string.Empty;
}

/// <summary>Состояние модулей и обнаруженные проблемы — для страницы Diagnostics и журнала.</summary>
public sealed class DiagnosticsState
{
    private readonly object _sync = new();
    private readonly Dictionary<string, ModuleStatus> _modules = new(StringComparer.Ordinal);
    private readonly List<string> _warnings = new();

    public void SetModule(string name, ModuleState state, string detail)
    {
        lock (_sync) _modules[name] = new ModuleStatus { Name = name, State = state, Detail = detail };
    }

    public void AddWarning(string warning)
    {
        lock (_sync)
        {
            if (_warnings.Contains(warning)) return;
            _warnings.Add(warning);
            if (_warnings.Count > 200) _warnings.RemoveAt(0);
        }
    }

    public void ClearWarnings()
    {
        lock (_sync) _warnings.Clear();
    }

    public List<ModuleStatus> Modules()
    {
        lock (_sync) return _modules.Values.OrderBy(m => m.Name).Select(m => new ModuleStatus { Name = m.Name, State = m.State, Detail = m.Detail }).ToList();
    }

    public List<string> Warnings()
    {
        lock (_sync) return _warnings.ToList();
    }

    public ModuleState? StateOf(string name)
    {
        lock (_sync) return _modules.TryGetValue(name, out var m) ? m.State : null;
    }
}
