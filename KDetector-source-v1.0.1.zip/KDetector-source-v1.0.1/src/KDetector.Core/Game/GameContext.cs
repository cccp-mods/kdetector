namespace KDetector.Core.Game;

/// <summary>Фаза игры с точки зрения античита. Заполняется игровым слоем.</summary>
public enum GamePhase
{
    Unknown = 0,
    NotConnected = 1,
    Lobby = 2,
    Intro = 3,
    Tasks = 4,
    Meeting = 5,
    Ended = 6,
    FreePlay = 7,
    LocalGame = 8,
}

/// <summary>
/// Снимок состояния игры, на основании которого правила принимают решения.
/// Игровой слой обновляет его не реже нескольких раз в секунду.
/// </summary>
public sealed class GameContext
{
    public GamePhase Phase { get; set; } = GamePhase.Unknown;

    /// <summary>Локальный клиент — хост текущего лобби (проверено по состоянию игры в момент снимка).</summary>
    public bool LocalIsHost { get; set; }

    /// <summary>Подключение к одному из официальных регионов (по списку из конфигурации).</summary>
    public bool OnOfficialServer { get; set; }

    /// <summary>Лобби использует модифицированный протокол (эвристика игрового слоя).</summary>
    public bool ModdedProtocol { get; set; }

    public string GameVersion { get; set; } = string.Empty;

    /// <summary>Версия игры входит в список поддерживаемых профилем совместимости.</summary>
    public bool VersionSupported { get; set; }

    /// <summary>Идентификатор текущей сессии лобби (код комнаты/номер), если известен.</summary>
    public string SessionId { get; set; } = string.Empty;

    public string RegionName { get; set; } = string.Empty;

    /// <summary>Монотонное время (мс) последней смены фазы — заполняет ядро.</summary>
    public long PhaseChangedMs { get; set; }

    public int LocalClientId { get; set; } = -1;
    public int HostClientId { get; set; } = -1;

    public bool InOnlineLobbyOrGame =>
        Phase is GamePhase.Lobby or GamePhase.Intro or GamePhase.Tasks or GamePhase.Meeting or GamePhase.Ended;

    public bool InMatch => Phase is GamePhase.Intro or GamePhase.Tasks or GamePhase.Meeting;

    public GameContext Clone() => (GameContext)MemberwiseClone();
}
