using KDetector.Core.Actions;
using KDetector.Core.Commands;
using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Database;
using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Diagnostics;
using KDetector.Core.Game;
using KDetector.Core.Logging;
using KDetector.Core.Network;
using KDetector.Core.Players;
using KDetector.Core.Reports;
using KDetector.Core.Risk;
using KDetector.Core.RpcShield;

namespace KDetector.Core;

/// <summary>Пути к файлам плагина.</summary>
public sealed class KdPaths
{
    public KdPaths(string pluginDirectory)
    {
        PluginDirectory = pluginDirectory;
    }

    public string PluginDirectory { get; }
    public string DataDirectory => Path.Combine(PluginDirectory, "Data");
    public string ReportsDirectory => Path.Combine(PluginDirectory, "Reports");
    public string ExportsDirectory => Path.Combine(PluginDirectory, "Exports");
    public string LogsDirectory => Path.Combine(PluginDirectory, "Logs");

    public string Data(string fileName) => Path.Combine(DataDirectory, fileName);
}

/// <summary>
/// Корень композиции ядра. Не зависит от Unity/BepInEx: игровой слой передаёт сюда наблюдения
/// (контекст игры, список игроков, входящие RPC) и получает решения.
/// </summary>
public sealed class KDetectorCore : IDisposable
{
    private readonly Dictionary<int, PlatformInfo?> _lastPlatform = new();
    private readonly Dictionary<int, uint?> _lastLevel = new();
    private GameContext _context = new();
    private long _lastPruneMs;

    public KDetectorCore(KdSettings settings, KdPaths paths, IClock clock, KdLog log, bool startDatabaseWorker = true)
    {
        Settings = settings;
        Paths = paths;
        Clock = clock;
        Log = log;
        Diagnostics = new DiagnosticsState();

        foreach (var w in SettingsValidator.Validate(settings))
        {
            Diagnostics.AddWarning(w);
            log.Warn("Config", w);
        }

        Directory.CreateDirectory(paths.DataDirectory);

        // Редактируемые и версионируемые файлы правил.
        Signatures = JsonFiles.LoadOrCreate(paths.Data(settings.KnownClients.SignatureFile), SignatureCatalog.BuiltIn, log, "KnownClients", out var w1);
        ProtocolSet = JsonFiles.LoadOrCreate(paths.Data(settings.InvalidActions.RulesFile), ProtocolRuleSet.BuiltIn, log, "InvalidActions", out var w2);
        ShieldRules = JsonFiles.LoadOrCreate(paths.Data(settings.RpcShield.RulesFile), RpcShieldRuleSet.BuiltIn, log, "RpcShield", out var w3);
        var custom = JsonFiles.LoadOrCreate(paths.Data(settings.AutoActions.CustomPolicyFile), CreateDefaultCustomPolicy, log, "AutoActions", out var w4);
        foreach (var w in new[] { w1, w2, w3, w4 }.Where(w => w != null)) Diagnostics.AddWarning(w!);

        Registry = new RuleRegistry(settings);
        foreach (var d in LevelRules.Descriptors()) Registry.Register(d);
        foreach (var d in PlatformRules.Descriptors()) Registry.Register(d);
        Registry.Register(KnownClientRules.Descriptor());
        foreach (var d in ProtocolRules.Descriptors()) Registry.Register(d);
        foreach (var d in RpcShieldEngine.Descriptors()) Registry.Register(d);

        Players = new PlayerRegistry(clock);
        Risk = new RiskModel(settings, clock);
        Engine = new DetectionEngine(Registry, settings, clock, log, () => _context);
        Actions = new ActionEngine(settings, clock, log, Risk, () => _context, custom);
        Level = new LevelRules(settings);
        Platform = new PlatformRules(settings);
        KnownClients = new KnownClientRules(settings, Signatures);
        Protocol = new ProtocolRules(settings, ProtocolSet, clock);
        Shield = new RpcShieldEngine(settings, clock, ShieldRules);
        Inspector = new NetworkInspector(settings, Engine, Shield, KnownClients, Protocol, Actions, Players, log) { Clock = clock };

        var dbPath = KdDatabase.ResolvePath(
            string.IsNullOrWhiteSpace(settings.Database.Directory) ? paths.DataDirectory : settings.Database.Directory,
            settings.Database.FileName, settings.Database.Extension, out var dbNote);
        Database = new DatabaseService(dbPath, settings, log, clock, startDatabaseWorker);
        if (dbNote != null)
        {
            Diagnostics.AddWarning(dbNote);
            Database.AddWarning(dbNote);
            log.Info("Database", dbNote);
        }

        Reports = new ReportWriter(paths.ReportsDirectory, log);
        Database.Changed += Inspector.InvalidateWhitelistCache;
        Database.RiskProvider = Risk.Assess;
        Engine.Whitelist = new CompositeWhitelist(Database, settings);
        Actions.Store = Database;
        Actions.Reports = Reports;
        Actions.EventsForPlayer = key => Engine.Feed.Snapshot().Where(e => e.PlayerKey == key).ToList();

        // Порядок важен: сначала риск (учитывает текущее событие), затем действия.
        Engine.EventPublished += evt =>
        {
            Risk.Add(evt);
            Players.IncrementEvents(evt.Player.ClientId);
            Actions.Handle(evt);
        };

        Commands = new CommandProcessor(this);
    }

    public KdSettings Settings { get; }
    public KdPaths Paths { get; }
    public IClock Clock { get; }
    public KdLog Log { get; }
    public DiagnosticsState Diagnostics { get; }
    public RuleRegistry Registry { get; }
    public DetectionEngine Engine { get; }
    public RiskModel Risk { get; }
    public ActionEngine Actions { get; }
    public LevelRules Level { get; }
    public PlatformRules Platform { get; }
    public KnownClientRules KnownClients { get; }
    public ProtocolRules Protocol { get; }
    public RpcShieldEngine Shield { get; }
    public NetworkInspector Inspector { get; }
    public PlayerRegistry Players { get; }
    public DatabaseService Database { get; }
    public ReportWriter Reports { get; }
    public CommandProcessor Commands { get; }
    public SignatureCatalog Signatures { get; private set; }
    public ProtocolRuleSet ProtocolSet { get; private set; }
    public RpcShieldRuleSet ShieldRules { get; private set; }

    public GameContext Context => _context;

    /// <summary>Вызывается после изменения настроек из GUI/команд: игровой слой сохраняет их в конфигурацию BepInEx.</summary>
    public event Action? SettingsChanged;

    public void Initialize()
    {
        var report = Database.Load();
        Diagnostics.SetModule("Database", Database.IsLoaded ? (report.Corrupt > 0 ? ModuleState.Warning : ModuleState.Ok) : ModuleState.Error,
            Database.IsLoaded ? $"{report.Loaded} записей, {Path.GetFileName(Database.Path)}" : (report.Warnings.FirstOrDefault() ?? "не загружена"));
        foreach (var w in report.Warnings) Diagnostics.AddWarning(w);
    }

    /// <summary>Перестроить индексы, зависящие от перечислений игры (вызывается игровым слоем после загрузки).</summary>
    public void BindGameEnums(Func<byte, bool> isVanillaRpc)
    {
        KnownClients.Rebuild(isVanillaRpc);
        foreach (var c in KnownClients.Conflicts)
        {
            Diagnostics.AddWarning(c);
            Log.Warn("KnownClients", c);
        }
    }

    public void UpdateSetting(Action change)
    {
        change();
        Inspector.InvalidateWhitelistCache();
        foreach (var w in SettingsValidator.Validate(Settings)) Diagnostics.AddWarning(w);
        ApplyCompatibility();
        SettingsChanged?.Invoke();
    }

    /// <summary>Применение изменённой конфигурации (горячая перезагрузка без перезапуска игры).</summary>
    public void OnSettingsReloaded()
    {
        foreach (var w in SettingsValidator.Validate(Settings)) Diagnostics.AddWarning(w);
        Log.MinLevel = Settings.Logging.DiagnosticMode ? KdLogLevel.Debug : Settings.Logging.Level;
        ApplyCompatibility();
    }

    /// <summary>Перечитать JSON-файлы правил с диска (кнопка «Перезагрузить правила»).</summary>
    public List<string> ReloadRuleFiles()
    {
        var warnings = new List<string>();
        Signatures = JsonFiles.LoadOrCreate(Paths.Data(Settings.KnownClients.SignatureFile), SignatureCatalog.BuiltIn, Log, "KnownClients", out var w1);
        ProtocolSet = JsonFiles.LoadOrCreate(Paths.Data(Settings.InvalidActions.RulesFile), ProtocolRuleSet.BuiltIn, Log, "InvalidActions", out var w2);
        ShieldRules = JsonFiles.LoadOrCreate(Paths.Data(Settings.RpcShield.RulesFile), RpcShieldRuleSet.BuiltIn, Log, "RpcShield", out var w3);
        var custom = JsonFiles.LoadOrCreate(Paths.Data(Settings.AutoActions.CustomPolicyFile), CreateDefaultCustomPolicy, Log, "AutoActions", out var w4);
        KnownClients.Rebuild(_isVanillaRpc, Signatures);
        Protocol.Rebuild(ProtocolSet);
        Shield.Rebuild(ShieldRules);
        Actions.CustomPolicy = custom;
        foreach (var w in new[] { w1, w2, w3, w4 }.Where(w => w != null)) warnings.Add(w!);
        Log.Info("Core", "Файлы правил перечитаны.");
        return warnings;
    }

    private Func<byte, bool>? _isVanillaRpc;

    public void SetVanillaRpcPredicate(Func<byte, bool> predicate)
    {
        _isVanillaRpc = predicate;
        BindGameEnums(predicate);
    }

    /// <summary>Восстановить встроенные правила RPC Shield (откат пользовательских изменений) с резервной копией файла.</summary>
    public void ResetShieldRulesToDefaults()
    {
        var path = Paths.Data(Settings.RpcShield.RulesFile);
        if (File.Exists(path)) File.Copy(path, path + $".bak-{DateTime.UtcNow:yyyyMMdd-HHmmss}", true);
        ShieldRules = RpcShieldRuleSet.BuiltIn();
        JsonFiles.Save(path, ShieldRules);
        Shield.Rebuild(ShieldRules);
    }

    public void SaveShieldRules()
    {
        JsonFiles.Save(Paths.Data(Settings.RpcShield.RulesFile), ShieldRules);
        Shield.Rebuild(ShieldRules);
    }

    public void SaveCustomPolicy()
    {
        JsonFiles.Save(Paths.Data(Settings.AutoActions.CustomPolicyFile), Actions.CustomPolicy);
    }

    /// <summary>Скопировать встроенный профиль в Custom (редактирование начинается с понятной основы).</summary>
    public void CopyProfileToCustom(ActionProfileName source)
    {
        var copy = ActionProfiles.Get(source).Clone();
        copy.Name = "Custom";
        copy.Description = $"Пользовательский профиль (основа: {source}).";
        Actions.CustomPolicy = copy;
        SaveCustomPolicy();
    }

    private static ActionPolicySet CreateDefaultCustomPolicy()
    {
        var p = ActionProfiles.Balanced().Clone();
        p.Name = "Custom";
        p.Description = "Пользовательский профиль (основа: Balanced). Редактируйте на странице Auto Actions или в этом файле.";
        return p;
    }

    // ===================== наблюдения от игрового слоя =====================

    public void UpdateContext(GameContext next)
    {
        var prev = _context;
        var versions = KdSettings.SplitList(Settings.Compatibility.SupportedVersions);
        next.VersionSupported = versions.Contains(next.GameVersion, StringComparer.OrdinalIgnoreCase);

        var sessionChanged = next.SessionId != prev.SessionId ||
                             (prev.InOnlineLobbyOrGame && !next.InOnlineLobbyOrGame);
        if (sessionChanged) ResetSession();

        if (prev.InMatch && next.Phase is GamePhase.Ended or GamePhase.Lobby)
            Level.OnMatchEnded();

        next.PhaseChangedMs = next.Phase != prev.Phase || sessionChanged ? Clock.MonotonicMs : prev.PhaseChangedMs;

        _context = next;
        ApplyCompatibility();
    }

    private void ApplyCompatibility()
    {
        var ctx = _context;
        var unsupported = !ctx.VersionSupported && !string.IsNullOrEmpty(ctx.GameVersion);
        var mode = Settings.Compatibility.UnsupportedMode;
        Inspector.DisabledByCompatibility = unsupported && mode == UnsupportedVersionMode.DisableNetworkChecks;
        Actions.EnforcementBlockedByCompatibility = unsupported && mode != UnsupportedVersionMode.Ignore;
        Actions.EnforcementBlockReason = unsupported ? $"версия игры {ctx.GameVersion} не входит в список поддерживаемых" : string.Empty;
    }

    public void ResetSession()
    {
        Players.Clear();
        Shield.ResetAll();
        Level.Reset();
        Platform.Reset();
        Engine.ResetPending();
        Actions.ResetSession();
        _lastPlatform.Clear();
        _lastLevel.Clear();
    }

    /// <summary>
    /// Синхронизация списка игроков. Вызывается периодически (не каждый кадр).
    /// Здесь же — проверки уровня и платформы (по изменению и с задержкой после появления игрока).
    /// </summary>
    public void ObservePlayers(IReadOnlyList<PlayerIdentity> current)
    {
        if (!Settings.General.Enabled) return;
        var seen = new HashSet<int>();
        var nowMs = Clock.MonotonicMs;

        foreach (var identity in current)
        {
            if (identity.ClientId < 0) continue;
            seen.Add(identity.ClientId);
            Players.Upsert(identity);
            if (identity.IsLocal || !_context.InOnlineLobbyOrGame) continue;

            try
            {
                if (identity.Level.HasValue && (!_lastLevel.TryGetValue(identity.ClientId, out var last) || last != identity.Level))
                {
                    _lastLevel[identity.ClientId] = identity.Level;
                    foreach (var c in Level.Observe(identity, identity.Level.Value, "NetworkedPlayerInfo.PlayerLevel"))
                        Engine.Process(c);
                }

                var live = Players.Get(identity.ClientId);
                if (identity.Platform != null && live != null &&
                    nowMs - live.JoinedMs >= (long)(Settings.PlatformSpoof.CheckDelaySeconds * 1000))
                {
                    _lastPlatform.TryGetValue(identity.ClientId, out var lastPlatform);
                    if (!live.PlatformChecked || !identity.Platform.SameAs(lastPlatform))
                    {
                        _lastPlatform[identity.ClientId] = identity.Platform.Clone();
                        Players.SetPlatformChecked(identity.ClientId);
                        foreach (var c in Platform.Observe(identity, identity.Platform))
                            Engine.Process(c);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Players", "Ошибка проверки игрока " + identity.Display, ex);
            }
        }

        foreach (var clientId in Players.ClientIds().Where(id => !seen.Contains(id)))
            PlayerLeft(clientId);

        if (nowMs - _lastPruneMs > 60_000)
        {
            _lastPruneMs = nowMs;
            Risk.Prune();
        }
    }

    public void PlayerLeft(int clientId)
    {
        Players.Remove(clientId);
        Shield.Forget(clientId);
        Level.Forget(clientId);
        Platform.Forget(clientId);
        _lastPlatform.Remove(clientId);
        _lastLevel.Remove(clientId);
    }

    public RpcVerdict InspectRpc(RpcObservation obs)
    {
        obs.Context = _context;
        return Inspector.Inspect(obs);
    }

    // ===================== сервисные операции =====================

    public string? ExportDatabase(IReadOnlyCollection<string>? recordIds)
    {
        try
        {
            Directory.CreateDirectory(Paths.ExportsDirectory);
            var path = Path.Combine(Paths.ExportsDirectory, $"KDetector-export-{DateTime.UtcNow:yyyyMMdd-HHmmss}.jsonl");
            Database.Export(path, recordIds);
            return path;
        }
        catch (Exception ex)
        {
            Log.Error("Database", "Ошибка экспорта", ex);
            return null;
        }
    }

    /// <summary>Очистка временной статистики (лента, счётчики Shield, история правил) без удаления базы.</summary>
    public void ClearSessionStatistics()
    {
        Engine.ClearFeed();
        Shield.ClearStatistics();
        Registry.ClearStatistics();
        Actions.History.Clear();
        Interlocked.Exchange(ref Inspector.Inspected, 0);
        Interlocked.Exchange(ref Inspector.Cancelled, 0);
        Interlocked.Exchange(ref Inspector.Errors, 0);
    }

    public string? WriteReport(PlayerIdentity player)
    {
        var key = player.Key(_context.SessionId);
        return Reports.Write(player, Risk.Assess(key), Engine.Feed.Snapshot().Where(e => e.PlayerKey == key).ToList());
    }

    public void Dispose()
    {
        Database.Dispose();
    }
}

/// <summary>Whitelist = список из конфигурации (Detection.Whitelist) + записи базы со статусом Whitelisted.</summary>
internal sealed class CompositeWhitelist : IWhitelistProvider
{
    private readonly DatabaseService _db;
    private readonly KdSettings _settings;

    public CompositeWhitelist(DatabaseService db, KdSettings settings)
    {
        _db = db;
        _settings = settings;
    }

    public bool IsWhitelisted(PlayerIdentity player)
    {
        if (string.IsNullOrEmpty(player.FriendCode) && string.IsNullOrEmpty(player.HashPuid)) return false;
        if (DetectionEngine.IsException(player, _settings.Detection.Whitelist)) return true;
        return _db.IsWhitelisted(player);
    }
}
