using System.Collections.Concurrent;
using System.Text;
using KDetector.Core.Common;

namespace KDetector.Core.Logging;

public enum KdLogLevel
{
    Debug = 0,
    Info = 1,
    Warning = 2,
    Error = 3,
}

/// <summary>Приёмник журнала (консоль BepInEx, файл, память).</summary>
public interface ILogSink
{
    void Write(DateTime utc, KdLogLevel level, string source, string message);
}

/// <summary>
/// Главный журнал KDetector: фильтр по уровню, подавление повторов, рассылка по приёмникам.
/// Повторяющиеся сообщения с одинаковым ключом не чаще одного раза в окно —
/// иначе спам RPC превратился бы в спам журнала.
/// </summary>
public sealed class KdLog
{
    private readonly List<ILogSink> _sinks = new();
    private readonly object _sync = new();
    private readonly Dictionary<string, (long lastMs, int suppressed)> _throttle = new();
    private readonly IClock _clock;

    public KdLog(IClock clock)
    {
        _clock = clock;
        Recent = new KDetector.Core.Common.RingBuffer<LogLine>(500);
    }

    public KdLogLevel MinLevel { get; set; } = KdLogLevel.Info;

    /// <summary>Последние строки журнала для страницы Diagnostics.</summary>
    public KDetector.Core.Common.RingBuffer<LogLine> Recent { get; }

    public void AddSink(ILogSink sink)
    {
        lock (_sync) _sinks.Add(sink);
    }

    public void Debug(string source, string message) => Write(KdLogLevel.Debug, source, message);
    public void Info(string source, string message) => Write(KdLogLevel.Info, source, message);
    public void Warn(string source, string message) => Write(KdLogLevel.Warning, source, message);
    public void Error(string source, string message) => Write(KdLogLevel.Error, source, message);

    public void Error(string source, string message, Exception ex)
        => Write(KdLogLevel.Error, source, message + ": " + ex.GetType().Name + ": " + ex.Message + "\n" + Truncate(ex.StackTrace, 2000));

    /// <summary>Пишет сообщение не чаще одного раза за <paramref name="intervalMs"/> для данного ключа.</summary>
    public void Throttled(string key, long intervalMs, KdLogLevel level, string source, string message)
    {
        int suppressed;
        lock (_sync)
        {
            var now = _clock.MonotonicMs;
            if (_throttle.TryGetValue(key, out var entry) && now - entry.lastMs < intervalMs)
            {
                _throttle[key] = (entry.lastMs, entry.suppressed + 1);
                return;
            }

            suppressed = entry.suppressed;
            _throttle[key] = (now, 0);
            if (_throttle.Count > 4096)
                _throttle.Clear(); // защита от бесконечного роста словаря
        }

        Write(level, source, suppressed > 0 ? $"{message} (подавлено повторов: {suppressed})" : message);
    }

    public void Write(KdLogLevel level, string source, string message)
    {
        if (level < MinLevel) return;
        var utc = _clock.UtcNow;
        message = Truncate(message, 4000);
        Recent.Add(new LogLine(utc, level, source, message));

        ILogSink[] sinks;
        lock (_sync) sinks = _sinks.ToArray();
        foreach (var sink in sinks)
        {
            try
            {
                sink.Write(utc, level, source, message);
            }
            catch
            {
                // Журнал никогда не должен ронять вызывающий код.
            }
        }
    }

    private static string Truncate(string? s, int max)
    {
        if (string.IsNullOrEmpty(s)) return string.Empty;
        return s!.Length <= max ? s : s.Substring(0, max) + "…";
    }
}

public readonly struct LogLine
{
    public LogLine(DateTime utc, KdLogLevel level, string source, string message)
    {
        Utc = utc;
        Level = level;
        Source = source;
        Message = message;
    }

    public DateTime Utc { get; }
    public KdLogLevel Level { get; }
    public string Source { get; }
    public string Message { get; }
}

/// <summary>
/// Файловый журнал с ротацией: запись идёт в фоновом потоке через ограниченную очередь,
/// при превышении размера файл переименовывается в .1, .2 … и старейший удаляется.
/// </summary>
public sealed class RotatingFileSink : ILogSink, IDisposable
{
    private readonly string _path;
    private readonly long _maxBytes;
    private readonly int _maxFiles;
    private readonly BlockingCollection<string> _queue = new(new ConcurrentQueue<string>(), 5000);
    private readonly Thread _thread;
    private volatile bool _disposed;
    private int _dropped;

    public RotatingFileSink(string path, long maxBytes, int maxFiles)
    {
        _path = path;
        _maxBytes = Math.Max(64 * 1024, maxBytes);
        _maxFiles = Math.Max(1, maxFiles);
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        _thread = new Thread(Run) { IsBackground = true, Name = "KDetector.Log" };
        _thread.Start();
    }

    public void Write(DateTime utc, KdLogLevel level, string source, string message)
    {
        if (_disposed) return;
        var line = $"{utc:yyyy-MM-dd HH:mm:ss.fff}Z [{level}] [{source}] {message}";
        if (!_queue.TryAdd(line))
            Interlocked.Increment(ref _dropped); // очередь переполнена — не блокируем игровой поток
    }

    private void Run()
    {
        try
        {
            foreach (var line in _queue.GetConsumingEnumerable())
            {
                try
                {
                    RotateIfNeeded();
                    var dropped = Interlocked.Exchange(ref _dropped, 0);
                    var text = dropped > 0 ? $"[Log] пропущено строк из-за переполнения очереди: {dropped}{Environment.NewLine}{line}" : line;
                    File.AppendAllText(_path, text + Environment.NewLine, Encoding.UTF8);
                }
                catch
                {
                    // Диск недоступен — пропускаем строку, но не падаем.
                }
            }
        }
        catch (ObjectDisposedException)
        {
        }
    }

    private void RotateIfNeeded()
    {
        var info = new FileInfo(_path);
        if (!info.Exists || info.Length < _maxBytes) return;

        // _maxFiles — число архивных файлов (.1 … .N). Старейший удаляется, остальные сдвигаются.
        var oldest = $"{_path}.{_maxFiles}";
        if (File.Exists(oldest)) File.Delete(oldest);

        for (var i = _maxFiles - 1; i >= 1; i--)
        {
            var src = $"{_path}.{i}";
            if (File.Exists(src)) File.Move(src, $"{_path}.{i + 1}", true);
        }

        File.Move(_path, _path + ".1", true);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _queue.CompleteAdding();
        _thread.Join(2000);
    }
}
