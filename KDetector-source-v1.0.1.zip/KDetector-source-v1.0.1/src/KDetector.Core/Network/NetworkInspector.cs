using KDetector.Core.Actions;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Logging;
using KDetector.Core.Players;
using KDetector.Core.RpcShield;

namespace KDetector.Core.Network;

/// <summary>Решение по входящему RPC.</summary>
public readonly struct RpcVerdict
{
    public static readonly RpcVerdict Allow = new(false, string.Empty);

    public RpcVerdict(bool cancel, string reason)
    {
        Cancel = cancel;
        Reason = reason;
    }

    public bool Cancel { get; }
    public string Reason { get; }
}

/// <summary>
/// Конвейер проверки входящего RPC: RPC Shield → сигнатуры известных клиентов → правила протокола.
/// Решение об отмене принимается синхронно; регистрация событий проходит через DetectionEngine (пороги, исключения).
/// Любая ошибка внутри приводит к пропуску RPC без изменений — античит не должен ломать игру.
/// </summary>
public sealed class NetworkInspector
{
    private readonly KdSettings _settings;
    private readonly DetectionEngine _engine;
    private readonly RpcShieldEngine _shield;
    private readonly KnownClientRules _known;
    private readonly ProtocolRules _protocol;
    private readonly ActionEngine _actions;
    private readonly PlayerRegistry _players;
    private readonly KdLog _log;

    public NetworkInspector(KdSettings settings, DetectionEngine engine, RpcShieldEngine shield, KnownClientRules known,
        ProtocolRules protocol, ActionEngine actions, PlayerRegistry players, KdLog log)
    {
        _settings = settings;
        _engine = engine;
        _shield = shield;
        _known = known;
        _protocol = protocol;
        _actions = actions;
        _players = players;
        _log = log;
    }

    // Кэш whitelist на 5 секунд: при флуде решение об отмене принимается для сотен RPC подряд,
    // и поиск по базе на каждый из них был бы заметен на игровом потоке.
    private readonly Dictionary<string, (bool value, long untilMs)> _whitelistCache = new();
    private readonly Common.IClock _clock = Common.SystemClock.Instance;

    public Common.IClock? Clock { get; set; }

    public long Inspected;
    public long Cancelled;
    public long Errors;

    /// <summary>Сетевые проверки отключены режимом совместимости.</summary>
    public bool DisabledByCompatibility { get; set; }

    public RpcVerdict Inspect(RpcObservation obs)
    {
        if (!_settings.General.Enabled || DisabledByCompatibility) return RpcVerdict.Allow;
        if (obs.Sender == null || obs.Sender.IsLocal) return RpcVerdict.Allow;
        if (!obs.Context.InOnlineLobbyOrGame) return RpcVerdict.Allow;

        try
        {
            Interlocked.Increment(ref Inspected);
            _players.Touch(obs.Sender.ClientId);

            var cancel = false;
            var reason = string.Empty;

            var shieldCandidates = _shield.Inspect(obs);
            if (shieldCandidates != null)
            {
                foreach (var c in shieldCandidates)
                {
                    var suppressed = c.CorrelationKey.StartsWith(RpcShieldEngine.SuppressedMarker, StringComparison.Ordinal);
                    if (suppressed) c.CorrelationKey = c.CorrelationKey.Substring(RpcShieldEngine.SuppressedMarker.Length);
                    var cancelledThis = Decide(c, ref cancel, ref reason);
                    _shield.RecordOutcome(obs, c, cancelledThis, reason, firstInWindow: !suppressed);
                    if (!suppressed) Submit(c);
                }
            }

            var isSignature = _known.IsCandidateCallId(obs.CallId);
            if (isSignature)
            {
                var c = _known.Evaluate(obs);
                if (c != null) Submit(c);
            }

            foreach (var c in _protocol.Evaluate(obs, isSignature))
            {
                Decide(c, ref cancel, ref reason);
                Submit(c);
            }

            if (cancel) Interlocked.Increment(ref Cancelled);
            return cancel ? new RpcVerdict(true, reason) : RpcVerdict.Allow;
        }
        catch (Exception ex)
        {
            Interlocked.Increment(ref Errors);
            _log.Throttled("inspect-error", 30000, KdLogLevel.Error, "Network", "Ошибка проверки RPC (RPC пропущен без изменений): " + ex.Message);
            return RpcVerdict.Allow;
        }
    }

    private bool Decide(DetectionCandidate c, ref bool cancel, ref string reason)
    {
        if (!c.Cancelable) return false;
        if (!_engine.WouldAccept(c, out var category)) return false;

        var whitelisted = IsWhitelistedCached(c.Player);
        if (_actions.ShouldCancel(c, category, whitelisted, out var why))
        {
            cancel = true;
            reason = $"{c.RuleId}: {c.Summary}";
            return true;
        }

        if (reason.Length == 0) reason = why;
        return false;
    }

    private bool IsWhitelistedCached(PlayerIdentity player)
    {
        var now = (Clock ?? _clock).MonotonicMs;
        var key = player.ClientId + "|" + player.FriendCode + "|" + player.HashPuid;
        lock (_whitelistCache)
        {
            if (_whitelistCache.TryGetValue(key, out var cached) && cached.untilMs > now) return cached.value;
        }

        var value = _engine.Whitelist.IsWhitelisted(player);
        lock (_whitelistCache)
        {
            if (_whitelistCache.Count > 512) _whitelistCache.Clear();
            _whitelistCache[key] = (value, now + 5000);
        }

        return value;
    }

    /// <summary>Сброс кэша (после изменения whitelist в интерфейсе или базе).</summary>
    public void InvalidateWhitelistCache()
    {
        lock (_whitelistCache) _whitelistCache.Clear();
    }

    private void Submit(DetectionCandidate c)
    {
        _engine.Process(c);
    }
}
