using KDetector.Core.Game;
using KDetector.Core.Players;

namespace KDetector.Core.Network;

/// <summary>Тип сетевого объекта, на котором получен RPC.</summary>
public enum NetObjectKind
{
    PlayerControl,
    PlayerPhysics,
    NetworkTransform,
    ShipStatus,
    Other,
}

/// <summary>
/// Наблюдение входящего RPC. Создаётся игровым слоем внутри Harmony-префикса.
/// Ограничение: «отправитель» здесь — владелец объекта, на котором вызван RPC.
/// Хост вправе отправлять RPC от имени объектов других игроков, поэтому атрибуция
/// у не-хоста не всегда точна (это учитывается в правилах).
/// </summary>
public sealed class RpcObservation
{
    public byte CallId { get; set; }

    /// <summary>Имя значения перечисления RpcCalls; null — номер не определён в текущей версии.</summary>
    public string? RpcName { get; set; }

    public NetObjectKind ObjectKind { get; set; }

    /// <summary>Игрок-владелец объекта. null — определить не удалось (такие RPC не проверяются).</summary>
    public PlayerIdentity? Sender { get; set; }

    /// <summary>Владелец объекта — хост лобби.</summary>
    public bool SenderIsHost { get; set; }

    /// <summary>Для UpdateSystem — имя системы (SystemTypes).</summary>
    public string? SystemName { get; set; }

    /// <summary>
    /// Ленивое получение ограниченной копии полезной нагрузки (не более maxBytes).
    /// Вызывается только если правилу действительно нужны байты, и только синхронно внутри префикса.
    /// </summary>
    public Func<int, byte[]>? PayloadProvider { get; set; }

    public GameContext Context { get; set; } = new();

    private byte[]? _payload;

    public byte[] GetPayload(int maxBytes)
    {
        if (_payload != null) return _payload;
        try
        {
            _payload = PayloadProvider?.Invoke(maxBytes) ?? Array.Empty<byte>();
        }
        catch
        {
            _payload = Array.Empty<byte>();
        }

        return _payload;
    }

    public string RpcDisplay => RpcName != null ? $"{RpcName} ({CallId})" : $"#{CallId} (не в перечислении)";
}
