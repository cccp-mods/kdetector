namespace KDetector.Core.Players;

/// <summary>
/// Сведения о платформе, как их сообщил клиент. Это заявленные данные, а не доказательство устройства.
/// </summary>
public sealed class PlatformInfo
{
    /// <summary>Числовое значение платформы из сетевых данных.</summary>
    public int PlatformId { get; set; }

    /// <summary>Имя значения в перечислении игры; null, если значение не определено в текущей версии.</summary>
    public string? EnumName { get; set; }

    public string PlatformName { get; set; } = string.Empty;
    public ulong XboxPlatformId { get; set; }
    public ulong PsnPlatformId { get; set; }

    /// <summary>Откуда получены данные (для карточки игрока).</summary>
    public string Source { get; set; } = "ClientData.PlatformData";

    public string Display => EnumName != null ? $"{EnumName} ({PlatformId})" : $"неизвестно ({PlatformId})";

    public bool SameAs(PlatformInfo? other) =>
        other != null && other.PlatformId == PlatformId && other.XboxPlatformId == XboxPlatformId && other.PsnPlatformId == PsnPlatformId;

    public PlatformInfo Clone() => (PlatformInfo)MemberwiseClone();
}

/// <summary>
/// Идентичность игрока в рамках текущего подключения. Неизвестные поля остаются пустыми — ничего не выдумываем.
/// </summary>
public sealed class PlayerIdentity
{
    public int ClientId { get; set; } = -1;
    public byte PlayerId { get; set; } = 255;
    public string Name { get; set; } = string.Empty;
    public string FriendCode { get; set; } = string.Empty;

    /// <summary>Усечённый SHA-256 от PUID (см. Hashing). Сырой PUID не хранится.</summary>
    public string HashPuid { get; set; } = string.Empty;

    public PlatformInfo? Platform { get; set; }

    /// <summary>Внутреннее значение NetworkedPlayerInfo.PlayerLevel (начинается с 0); null — ещё не получено.</summary>
    public uint? Level { get; set; }

    /// <summary>Уровень так, как его показывает игра (внутреннее значение + 1).</summary>
    public string LevelDisplay => Level.HasValue ? (Level.Value == uint.MaxValue ? "переполнение" : (Level.Value + 1UL).ToString()) : "—";

    public bool IsHost { get; set; }
    public bool IsLocal { get; set; }

    /// <summary>
    /// Ключ игрока для накопления риска и связи с базой. Приоритет: HashPuid → FriendCode → сессия+клиент.
    /// По одному имени разные аккаунты никогда не объединяются.
    /// </summary>
    public string Key(string sessionId)
    {
        if (!string.IsNullOrEmpty(HashPuid)) return "puid:" + HashPuid;
        if (!string.IsNullOrEmpty(FriendCode)) return "fc:" + FriendCode.ToLowerInvariant();
        return $"session:{sessionId}:{ClientId}";
    }

    public string Display => string.IsNullOrEmpty(Name) ? $"Клиент #{ClientId}" : Name;

    public PlayerIdentity Clone()
    {
        var copy = (PlayerIdentity)MemberwiseClone();
        copy.Platform = Platform?.Clone();
        return copy;
    }
}
