using KDetector.Core.Common;

namespace KDetector.Core.Players;

/// <summary>Игрок текущего лобби.</summary>
public sealed class LivePlayer
{
    public PlayerIdentity Identity { get; set; } = new();
    public DateTime JoinedUtc { get; set; }
    public DateTime LastActivityUtc { get; set; }
    public long JoinedMs { get; set; }
    public int EventCount { get; set; }

    /// <summary>Проверка платформы выполнена (с задержкой после появления).</summary>
    public bool PlatformChecked { get; set; }

    public LivePlayer Clone()
    {
        var c = (LivePlayer)MemberwiseClone();
        c.Identity = Identity.Clone();
        return c;
    }
}

/// <summary>Потокобезопасный список игроков текущего лобби (по ClientId).</summary>
public sealed class PlayerRegistry
{
    private readonly object _sync = new();
    private readonly Dictionary<int, LivePlayer> _players = new();
    private readonly IClock _clock;

    public PlayerRegistry(IClock clock)
    {
        _clock = clock;
    }

    public long Version { get; private set; }

    /// <summary>Добавляет или обновляет игрока. Возвращает true, если игрок новый.</summary>
    public bool Upsert(PlayerIdentity identity)
    {
        lock (_sync)
        {
            if (_players.TryGetValue(identity.ClientId, out var existing))
            {
                var changed = existing.Identity.Name != identity.Name || existing.Identity.Level != identity.Level ||
                              existing.Identity.IsHost != identity.IsHost || existing.Identity.FriendCode != identity.FriendCode ||
                              !SamePlatform(existing.Identity.Platform, identity.Platform) || existing.Identity.PlayerId != identity.PlayerId;
                existing.Identity = identity;
                if (changed) Version++;
                return false;
            }

            _players[identity.ClientId] = new LivePlayer
            {
                Identity = identity,
                JoinedUtc = _clock.UtcNow,
                LastActivityUtc = _clock.UtcNow,
                JoinedMs = _clock.MonotonicMs,
            };
            Version++;
            return true;
        }
    }

    private static bool SamePlatform(PlatformInfo? a, PlatformInfo? b) => a == null ? b == null : a.SameAs(b);

    public LivePlayer? Remove(int clientId)
    {
        lock (_sync)
        {
            if (!_players.TryGetValue(clientId, out var p)) return null;
            _players.Remove(clientId);
            Version++;
            return p;
        }
    }

    public LivePlayer? Get(int clientId)
    {
        lock (_sync) return _players.TryGetValue(clientId, out var p) ? p : null;
    }

    public PlayerIdentity? FindIdentity(int clientId)
    {
        lock (_sync) return _players.TryGetValue(clientId, out var p) ? p.Identity : null;
    }

    public LivePlayer? FindByPlayerId(byte playerId)
    {
        lock (_sync) return _players.Values.FirstOrDefault(p => p.Identity.PlayerId == playerId);
    }

    public List<int> ClientIds()
    {
        lock (_sync) return _players.Keys.ToList();
    }

    public void Touch(int clientId)
    {
        lock (_sync)
        {
            if (_players.TryGetValue(clientId, out var p)) p.LastActivityUtc = _clock.UtcNow;
        }
    }

    public void IncrementEvents(int clientId)
    {
        lock (_sync)
        {
            if (_players.TryGetValue(clientId, out var p))
            {
                p.EventCount++;
                Version++;
            }
        }
    }

    public void SetPlatformChecked(int clientId)
    {
        lock (_sync)
        {
            if (_players.TryGetValue(clientId, out var p)) p.PlatformChecked = true;
        }
    }

    public List<LivePlayer> Snapshot()
    {
        lock (_sync) return _players.Values.Select(p => p.Clone()).OrderBy(p => p.Identity.PlayerId).ToList();
    }

    public int Count
    {
        get { lock (_sync) return _players.Count; }
    }

    public void Clear()
    {
        lock (_sync)
        {
            _players.Clear();
            Version++;
        }
    }
}
