using System.Text;
using KDetector.Core.Actions;
using KDetector.Core.Common;
using KDetector.Core.Detection;
using KDetector.Core.Logging;
using KDetector.Core.Players;
using KDetector.Core.Risk;

namespace KDetector.Core.Reports;

/// <summary>Текстовые отчёты по игроку в папке Reports (только локально).</summary>
public sealed class ReportWriter : IReportWriter
{
    private readonly string _directory;
    private readonly KdLog _log;

    public ReportWriter(string directory, KdLog log)
    {
        _directory = directory;
        _log = log;
    }

    public string? Write(PlayerIdentity player, RiskAssessment risk, IReadOnlyList<DetectionEvent> events)
    {
        try
        {
            Directory.CreateDirectory(_directory);
            var safeName = new string(player.Display.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c).ToArray());
            if (safeName.Length > 32) safeName = safeName.Substring(0, 32);
            var path = Path.Combine(_directory, $"report-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{safeName}.txt");
            File.WriteAllText(path, Build(player, risk, events), new UTF8Encoding(false));
            _log.Info("Reports", "Отчёт сохранён: " + path);
            return path;
        }
        catch (Exception ex)
        {
            _log.Error("Reports", "Не удалось сохранить отчёт", ex);
            return null;
        }
    }

    public static string Build(PlayerIdentity player, RiskAssessment risk, IReadOnlyList<DetectionEvent> events)
    {
        var sb = new StringBuilder();
        sb.AppendLine(ProductIdentity.DisplayName + " — отчёт по игроку");
        sb.AppendLine($"Создан (UTC): {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("Отчёт содержит только данные, наблюдаемые клиентом. Признаки ≠ доказательства.");
        sb.AppendLine();
        sb.AppendLine($"Имя: {player.Display}");
        sb.AppendLine($"ClientId: {player.ClientId}   PlayerId: {(player.PlayerId == 255 ? "—" : player.PlayerId.ToString())}");
        sb.AppendLine($"Friend Code: {(string.IsNullOrEmpty(player.FriendCode) ? "—" : player.FriendCode)}");
        sb.AppendLine($"HashPuid: {(string.IsNullOrEmpty(player.HashPuid) ? "—" : player.HashPuid)}");
        sb.AppendLine($"Платформа (заявленная): {player.Platform?.Display ?? "—"}");
        sb.AppendLine($"Уровень: {player.LevelDisplay}");
        sb.AppendLine();
        foreach (var line in risk.Explanation) sb.AppendLine(line);
        sb.AppendLine();
        sb.AppendLine("События:");
        foreach (var e in events.OrderBy(e => e.TimestampUtc))
        {
            sb.AppendLine($"- {e.TimestampUtc:yyyy-MM-dd HH:mm:ss} [{e.RuleId} v{e.RuleVersion}] {DetectionText.Evidence(e.Evidence)}, {DetectionText.Severity(e.Severity)}, уверенность {e.Confidence:0.00}");
            sb.AppendLine($"  {e.Summary}");
            foreach (var f in e.Facts) sb.AppendLine($"    факт: {f}");
            if (!string.IsNullOrEmpty(e.Hypothesis)) sb.AppendLine($"    гипотеза: {e.Hypothesis}");
        }

        return sb.ToString();
    }
}
