using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;

namespace KDetector.Core.Risk;

public enum RiskLevel
{
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4,
}

/// <summary>Вклад одной группы доказательств (правило + ключ корреляции) в итоговую оценку.</summary>
public sealed class RiskContribution
{
    public string RuleId { get; set; } = string.Empty;
    public string RuleName { get; set; } = string.Empty;
    public string CorrelationKey { get; set; } = string.Empty;
    public EvidenceKind Evidence { get; set; }
    public Severity MaxSeverity { get; set; }
    public double MaxConfidence { get; set; }
    public int Count { get; set; }
    public DateTime FirstUtc { get; set; }
    public DateTime LastUtc { get; set; }

    /// <summary>Итоговый вклад 0..0.95 с учётом повторов и давности.</summary>
    public double Weight { get; set; }

    public double DecayFactor { get; set; }
}

/// <summary>Объяснимая оценка риска игрока.</summary>
public sealed class RiskAssessment
{
    public static readonly RiskAssessment Empty = new();

    public string PlayerKey { get; set; } = string.Empty;
    public int Score { get; set; }
    public RiskLevel Level { get; set; }
    public int ConfirmedViolations { get; set; }
    public int SuspiciousEvents { get; set; }
    public int TotalEvents { get; set; }

    /// <summary>Число независимых групп доказательств (разные правила или разные ключи корреляции).</summary>
    public int IndependentEvidence { get; set; }

    public bool Whitelisted { get; set; }
    public List<RiskContribution> Contributions { get; set; } = new();

    /// <summary>Пояснение итоговой оценки по строкам.</summary>
    public List<string> Explanation { get; set; } = new();
}

/// <summary>
/// Модель риска.
/// 1) События группируются по (правило, ключ корреляции): повторы одного наблюдения — НЕ независимые доказательства,
///    их вклад растёт логарифмически и ограничен 1.5× от максимального веса группы.
/// 2) Вес = серьёзность × уверенность × множитель вида доказательства.
/// 3) Давность: вклад затухает с периодом полураспада (Detection.RiskHalfLifeMinutes).
/// 4) Итог = 100 × (1 − Π(1 − вклад_i)): несколько независимых групп усиливают друг друга, но оценка ограничена 100.
/// Ключ игрока — HashPuid / Friend Code / сессия: разные аккаунты с одинаковым именем не объединяются.
/// </summary>
public sealed class RiskModel
{
    private readonly KdSettings _settings;
    private readonly IClock _clock;
    private readonly object _sync = new();
    private readonly Dictionary<string, Dictionary<string, RiskContribution>> _groups = new();
    private readonly Dictionary<string, bool> _whitelisted = new();

    public RiskModel(KdSettings settings, IClock clock)
    {
        _settings = settings;
        _clock = clock;
    }

    public void Add(DetectionEvent evt)
    {
        lock (_sync)
        {
            if (!_groups.TryGetValue(evt.PlayerKey, out var groups))
                _groups[evt.PlayerKey] = groups = new Dictionary<string, RiskContribution>();

            var gkey = evt.RuleId + "|" + evt.CorrelationKey;
            if (!groups.TryGetValue(gkey, out var c))
            {
                groups[gkey] = c = new RiskContribution
                {
                    RuleId = evt.RuleId,
                    RuleName = evt.RuleName,
                    CorrelationKey = evt.CorrelationKey,
                    Evidence = evt.Evidence,
                    FirstUtc = evt.TimestampUtc,
                };
            }

            c.Count += Math.Max(1, evt.ObservationCount);
            c.LastUtc = evt.TimestampUtc;
            if (evt.Severity > c.MaxSeverity) c.MaxSeverity = evt.Severity;
            if (evt.Confidence > c.MaxConfidence) c.MaxConfidence = evt.Confidence;
            if (Rank(evt.Evidence) > Rank(c.Evidence)) c.Evidence = evt.Evidence;
            _whitelisted[evt.PlayerKey] = evt.Whitelisted;
        }
    }

    public RiskAssessment Assess(string playerKey)
    {
        lock (_sync)
        {
            if (!_groups.TryGetValue(playerKey, out var groups) || groups.Count == 0)
                return new RiskAssessment { PlayerKey = playerKey };

            var now = _clock.UtcNow;
            var halfLife = Math.Max(1, _settings.Detection.RiskHalfLifeMinutes);
            var result = new RiskAssessment { PlayerKey = playerKey, Whitelisted = _whitelisted.TryGetValue(playerKey, out var w) && w };
            var product = 1.0;

            foreach (var c in groups.Values.OrderByDescending(g => g.LastUtc))
            {
                var ageMin = Math.Max(0, (now - c.LastUtc).TotalMinutes);
                c.DecayFactor = Math.Pow(0.5, ageMin / halfLife);
                var baseWeight = SeverityWeight(c.MaxSeverity) * c.MaxConfidence * EvidenceMultiplier(c.Evidence);
                var repeatFactor = Math.Min(1.5, 1 + 0.25 * Math.Log(Math.Max(1, c.Count)));
                c.Weight = Math.Min(0.95, baseWeight * repeatFactor * c.DecayFactor);
                product *= 1 - c.Weight;

                result.TotalEvents += c.Count;
                if (c.Evidence == EvidenceKind.ConfirmedInvalidAction) result.ConfirmedViolations += c.Count;
                else result.SuspiciousEvents += c.Count;
                if (c.Weight >= 0.05 && c.MaxConfidence >= 0.3) result.IndependentEvidence++;

                result.Contributions.Add(new RiskContribution
                {
                    RuleId = c.RuleId, RuleName = c.RuleName, CorrelationKey = c.CorrelationKey, Evidence = c.Evidence,
                    MaxSeverity = c.MaxSeverity, MaxConfidence = c.MaxConfidence, Count = c.Count, FirstUtc = c.FirstUtc,
                    LastUtc = c.LastUtc, Weight = c.Weight, DecayFactor = c.DecayFactor,
                });

                result.Explanation.Add(
                    $"{c.RuleName}: {DetectionText.Evidence(c.Evidence)}, серьёзность {DetectionText.Severity(c.MaxSeverity)}, " +
                    $"уверенность {c.MaxConfidence:0.00}, повторов {c.Count}, давность {ageMin:0} мин → вклад {c.Weight * 100:0}%");
            }

            result.Score = (int)Math.Round(100 * (1 - product));
            result.Level = LevelFor(result.Score);
            result.Explanation.Insert(0,
                $"Итог {result.Score}/100 ({LevelText(result.Level)}). Независимых групп доказательств: {result.IndependentEvidence}. " +
                "Повторы одного наблюдения не считаются независимыми; вклад затухает со временем.");
            if (result.Whitelisted)
                result.Explanation.Insert(1, "Игрок в whitelist: автоматические меры не применяются.");
            return result;
        }
    }

    /// <summary>Удаляет полностью затухшие группы (вызывается периодически).</summary>
    public void Prune()
    {
        lock (_sync)
        {
            var now = _clock.UtcNow;
            var maxAge = TimeSpan.FromMinutes(Math.Max(1, _settings.Detection.RiskHalfLifeMinutes) * 10);
            foreach (var pk in _groups.Keys.ToList())
            {
                var groups = _groups[pk];
                foreach (var gk in groups.Where(g => now - g.Value.LastUtc > maxAge).Select(g => g.Key).ToList())
                    groups.Remove(gk);
                if (groups.Count == 0)
                {
                    _groups.Remove(pk);
                    _whitelisted.Remove(pk);
                }
            }
        }
    }

    public void Forget(string playerKey)
    {
        lock (_sync)
        {
            _groups.Remove(playerKey);
            _whitelisted.Remove(playerKey);
        }
    }

    public void Clear()
    {
        lock (_sync)
        {
            _groups.Clear();
            _whitelisted.Clear();
        }
    }

    public static RiskLevel LevelFor(int score) =>
        score >= 80 ? RiskLevel.Critical : score >= 55 ? RiskLevel.High : score >= 30 ? RiskLevel.Medium : score >= 10 ? RiskLevel.Low : RiskLevel.None;

    public static string LevelText(RiskLevel l) => l switch
    {
        RiskLevel.None => "нет",
        RiskLevel.Low => "низкий",
        RiskLevel.Medium => "средний",
        RiskLevel.High => "высокий",
        RiskLevel.Critical => "критический",
        _ => l.ToString(),
    };

    private static double SeverityWeight(Severity s) => s switch
    {
        Severity.Info => 0.05,
        Severity.Low => 0.2,
        Severity.Medium => 0.4,
        Severity.High => 0.65,
        Severity.Critical => 0.85,
        _ => 0.2,
    };

    private static double EvidenceMultiplier(EvidenceKind e) => e switch
    {
        EvidenceKind.ConfirmedInvalidAction => 1.0,
        EvidenceKind.KnownClientIndicator => 0.9,
        EvidenceKind.InvalidProtocol => 0.8,
        EvidenceKind.SuspiciousBehavior => 0.6,
        _ => 0.5,
    };

    private static int Rank(EvidenceKind e) => e switch
    {
        EvidenceKind.ConfirmedInvalidAction => 3,
        EvidenceKind.KnownClientIndicator => 2,
        EvidenceKind.InvalidProtocol => 1,
        _ => 0,
    };
}
