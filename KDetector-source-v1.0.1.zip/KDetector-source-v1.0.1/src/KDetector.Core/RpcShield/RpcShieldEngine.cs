using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Network;

namespace KDetector.Core.RpcShield;

/// <summary>Запись о превышении лимита (для страницы RPC Shield).</summary>
public sealed class ShieldIncident
{
    public DateTime Utc { get; set; }
    public string PlayerName { get; set; } = string.Empty;
    public int ClientId { get; set; }
    public string Category { get; set; } = string.Empty;
    public string Rpc { get; set; } = string.Empty;
    public int Limit { get; set; }
    public int WindowMs { get; set; }
    public bool Cancelled { get; set; }
    public string Note { get; set; } = string.Empty;
}

public sealed class CategoryStats
{
    public long Total;
    public long Exceeded;
    public long Cancelled;
}

/// <summary>
/// RPC Shield: независимые скользящие окна на (игрок, категория), (игрок, RPC-override) и общий лимит на игрока.
/// Вызывается на игровом потоке, поэтому работает без аллокаций в обычном случае (только словари с переиспользуемыми счётчиками).
/// </summary>
public sealed class RpcShieldEngine
{
    private readonly KdSettings _settings;
    private readonly IClock _clock;
    private readonly object _sync = new();
    private readonly Dictionary<int, PlayerCounters> _players = new();
    private RpcShieldRuleSet _rules;
    private Dictionary<string, RpcCategory> _categoryByRpc = new(StringComparer.Ordinal);
    private Dictionary<string, RpcOverride> _overrideByRpc = new(StringComparer.Ordinal);
    private RpcCategory _unknown = new() { Name = RpcShieldRuleSet.UnknownCategory, MaxEvents = 30, WindowMs = 1000 };
    private RpcCategory _other = new() { Name = RpcShieldRuleSet.OtherCategory, MaxEvents = 40, WindowMs = 1000 };

    public RpcShieldEngine(KdSettings settings, IClock clock, RpcShieldRuleSet rules)
    {
        _settings = settings;
        _clock = clock;
        _rules = rules;
        Rebuild(rules);
    }

    public RpcShieldRuleSet Rules => _rules;
    public Dictionary<string, CategoryStats> Stats { get; } = new(StringComparer.Ordinal);
    public KDetector.Core.Common.RingBuffer<ShieldIncident> Recent { get; } = new(200);
    public long TotalInspected;

    public static IEnumerable<RuleDescriptor> Descriptors()
    {
        yield return new RuleDescriptor
        {
            Id = RuleIds.RpcRateCategory,
            Name = "Превышение частоты RPC (категория)",
            Category = DetectionCategory.RpcSpam,
            Description = "Игрок отправляет RPC одной категории чаще лимита из RpcShield.json.",
            CheckedData = "Номер/имя RPC, владелец объекта, время получения",
            Limitations = "Лимиты считаются по клиенту в текущем подключении; при переподключении счётчики начинаются заново. Отменяются только безопасные категории.",
            DefaultMinConfidence = 0.3,
        };
        yield return new RuleDescriptor
        {
            Id = RuleIds.RpcRateGlobal,
            Name = "Превышение общей частоты RPC",
            Category = DetectionCategory.RpcSpam,
            Description = "Общее число RPC от игрока за окно превышает лимит RpcShield.GlobalLimit.",
            CheckedData = "Все входящие RPC игрока",
            Limitations = "Только наблюдение: общий поток смешивает безопасные и критичные RPC, поэтому не отменяется.",
            DefaultMinConfidence = 0.3,
        };
    }

    public void Rebuild(RpcShieldRuleSet rules)
    {
        lock (_sync)
        {
            _rules = rules;
            var byRpc = new Dictionary<string, RpcCategory>(StringComparer.Ordinal);
            foreach (var cat in rules.Categories)
            {
                if (cat.Name == RpcShieldRuleSet.UnknownCategory) _unknown = cat;
                else if (cat.Name == RpcShieldRuleSet.OtherCategory) _other = cat;
                foreach (var name in cat.RpcNames)
                    byRpc[name] = cat; // при дубликатах побеждает последняя категория
            }

            _categoryByRpc = byRpc;
            _overrideByRpc = rules.Overrides.Where(o => o.Enabled && !string.IsNullOrEmpty(o.RpcName))
                .GroupBy(o => o.RpcName).ToDictionary(g => g.Key, g => g.Last(), StringComparer.Ordinal);
            _players.Clear();
        }
    }

    public RpcCategory CategoryFor(string? rpcName)
    {
        if (rpcName == null) return _unknown;
        return _categoryByRpc.TryGetValue(rpcName, out var c) ? c : _other;
    }

    /// <summary>Сброс счётчиков игрока (выход/переподключение).</summary>
    public void Forget(int clientId)
    {
        lock (_sync) _players.Remove(clientId);
    }

    public void ResetAll()
    {
        lock (_sync) _players.Clear();
    }

    public void ClearStatistics()
    {
        lock (_sync)
        {
            Stats.Clear();
            Recent.Clear();
            TotalInspected = 0;
        }
    }

    /// <summary>
    /// Проверяет RPC. Возвращает кандидатов (0..2): превышение категории и/или общего лимита.
    /// Кандидат категории помечен Cancelable, если категория безопасна для отмены.
    /// </summary>
    public List<DetectionCandidate>? Inspect(RpcObservation obs)
    {
        if (!_settings.RpcShield.Enabled || obs.Sender == null) return null;
        var clientId = obs.Sender.ClientId;
        var nowMs = _clock.MonotonicMs;
        List<DetectionCandidate>? result = null;

        lock (_sync)
        {
            TotalInspected++;
            if (!_players.TryGetValue(clientId, out var pc))
            {
                if (_players.Count > 256) PurgeStale(nowMs);
                pc = new PlayerCounters();
                _players[clientId] = pc;
            }

            var cat = CategoryFor(obs.RpcName);
            var stats = GetStats(cat.Name);
            stats.Total++;
            if (cat.ExemptHost && obs.SenderIsHost) return null; // см. RpcCategory.ExemptHost

            // Общий лимит игрока.
            var g = _settings.RpcShield;
            if (pc.Global == null) pc.Global = new SlidingWindowCounter(g.GlobalLimit, g.GlobalWindowMs);
            else pc.Global.Reconfigure(g.GlobalLimit, g.GlobalWindowMs);
            if (!pc.Global.Hit(nowMs))
            {
                var observedGlobal = pc.Global.EstimatedInWindow(nowMs);
                if (ShouldEmit(pc, "global", nowMs, SeverityFor(observedGlobal, g.GlobalLimit)))
                {
                    result ??= new List<DetectionCandidate>();
                    result.Add(MakeCandidate(RuleIds.RpcRateGlobal, obs, "Общий лимит", g.GlobalLimit, g.GlobalWindowMs, observedGlobal, false));
                }
            }

            // Индивидуальный лимит RPC или лимит категории.
            SlidingWindowCounter? counter = null;
            int limit = 0, window = 0;
            var key = cat.Name;
            if (obs.RpcName != null && _overrideByRpc.TryGetValue(obs.RpcName, out var ov))
            {
                key = "rpc:" + ov.RpcName;
                limit = ov.MaxEvents;
                window = ov.WindowMs;
            }
            else if (cat.Enabled)
            {
                limit = cat.MaxEvents;
                window = cat.WindowMs;
            }

            if (limit > 0)
            {
                if (!pc.Counters.TryGetValue(key, out counter))
                {
                    counter = new SlidingWindowCounter(Math.Max(1, limit), Math.Max(1, window));
                    pc.Counters[key] = counter;
                }
                else
                {
                    counter.Reconfigure(limit, window);
                }

                if (!counter.Hit(nowMs))
                {
                    stats.Exceeded++;
                    var cancelable = cat.SafeToCancel;
                    var observed = counter.EstimatedInWindow(nowMs);
                    var emit = ShouldEmit(pc, key, nowMs, SeverityFor(observed, limit));
                    var candidate = MakeCandidate(RuleIds.RpcRateCategory, obs, cat.Name, limit, window, observed, cancelable);
                    candidate.Facts.Add(new Fact("Событие уже зарегистрировано в окне cooldown", emit ? "нет" : "да", "RPC Shield"));
                    result ??= new List<DetectionCandidate>();
                    // Кандидат возвращается всегда (для решения об отмене), но помечается, нужно ли создавать событие.
                    candidate.CorrelationKey = emit ? candidate.CorrelationKey : SuppressedMarker + candidate.CorrelationKey;
                    result.Add(candidate);
                }
            }
        }

        return result;
    }

    /// <summary>Префикс ключа корреляции, означающий «только решение об отмене, событие не регистрировать» (cooldown).</summary>
    public const string SuppressedMarker = "~cooldown~";

    public void RecordOutcome(RpcObservation obs, DetectionCandidate candidate, bool cancelled, string note, bool firstInWindow)
    {
        var cat = candidate.Facts.FirstOrDefault(f => f.Name == "Категория")?.Value ?? string.Empty;
        lock (_sync)
        {
            if (cancelled) GetStats(cat).Cancelled++;
        }

        // В ленту попадают только «первые» превышения окна cooldown, иначе лента забьётся при флуде.
        if (!firstInWindow) return;
        Recent.Add(new ShieldIncident
        {
            Utc = _clock.UtcNow,
            PlayerName = obs.Sender?.Display ?? "?",
            ClientId = obs.Sender?.ClientId ?? -1,
            Category = cat,
            Rpc = obs.RpcDisplay,
            Limit = int.TryParse(candidate.Facts.FirstOrDefault(f => f.Name == "Лимит")?.Value, out var l) ? l : 0,
            WindowMs = int.TryParse(candidate.Facts.FirstOrDefault(f => f.Name == "Окно, мс")?.Value, out var w) ? w : 0,
            Cancelled = cancelled,
            Note = note,
        });
    }

    private CategoryStats GetStats(string name)
    {
        if (!Stats.TryGetValue(name, out var s)) Stats[name] = s = new CategoryStats();
        return s;
    }

    /// <summary>
    /// Событие создаётся не чаще раза в cooldown на (игрок, ключ), но если вспышка усиливается
    /// (растёт серьёзность), регистрируется новое событие с более высокой оценкой.
    /// </summary>
    private bool ShouldEmit(PlayerCounters pc, string key, long nowMs, Severity severity)
    {
        var cooldown = Math.Max(1, _settings.RpcShield.EventCooldownSeconds) * 1000L;
        if (pc.LastEventMs.TryGetValue(key, out var last) && nowMs - last < cooldown)
        {
            if (!pc.LastSeverity.TryGetValue(key, out var lastSeverity) || severity <= lastSeverity) return false;
        }

        pc.LastEventMs[key] = nowMs;
        pc.LastSeverity[key] = severity;
        return true;
    }

    public static Severity SeverityFor(int observed, int limit)
    {
        var ratio = limit > 0 ? (double)observed / limit : 1;
        return ratio >= 5 ? Severity.High : ratio >= 2 ? Severity.Medium : Severity.Low;
    }

    private static DetectionCandidate MakeCandidate(string ruleId, RpcObservation obs, string category, int limit, int windowMs, int observed, bool cancelable)
    {
        var ratio = limit > 0 ? (double)observed / limit : 1;
        var confidence = Math.Max(0.4, Math.Min(0.95, 0.4 + 0.25 * Math.Log(Math.Max(1, ratio), 2) + 0.05));
        var severity = SeverityFor(observed, limit);
        return new DetectionCandidate
        {
            RuleId = ruleId,
            Player = obs.Sender!,
            Severity = severity,
            Evidence = EvidenceKind.SuspiciousBehavior,
            Confidence = confidence,
            Summary = $"{category}: {obs.RpcDisplay} — больше {limit} за {windowMs} мс.",
            Hypothesis = ratio >= 3 ? "Частота значительно выше обычной игры; характерно для флуда." : string.Empty,
            CorrelationKey = "rate:" + category,
            Cancelable = cancelable,
        }.AddFact("Категория", category, "RpcShield.json")
         .AddFact("RPC", obs.RpcDisplay, "входящий RPC")
         .AddFact("Лимит", limit.ToString(), "RpcShield.json")
         .AddFact("Окно, мс", windowMs.ToString(), "RpcShield.json")
         .AddFact("Оценка числа RPC в окне", observed.ToString(), "RPC Shield");
    }

    private void PurgeStale(long nowMs)
    {
        foreach (var id in _players.Where(p => nowMs - p.Value.LastSeenMs() > 600_000).Select(p => p.Key).ToList())
            _players.Remove(id);
    }

    private sealed class PlayerCounters
    {
        public SlidingWindowCounter? Global;
        public readonly Dictionary<string, SlidingWindowCounter> Counters = new(StringComparer.Ordinal);
        public readonly Dictionary<string, long> LastEventMs = new(StringComparer.Ordinal);
        public readonly Dictionary<string, Severity> LastSeverity = new(StringComparer.Ordinal);

        public long LastSeenMs() => Global?.LastHitMs ?? 0;
    }
}
