namespace KDetector.Core.RpcShield;

/// <summary>Категория RPC с лимитом частоты.</summary>
public sealed class RpcCategory
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public int MaxEvents { get; set; } = 20;
    public int WindowMs { get; set; } = 1000;

    /// <summary>
    /// Отмена обработки лишних событий безопасна (не влияет на исход матча и не вызывает рассинхронизацию).
    /// Для небезопасных категорий превышение только фиксируется.
    /// </summary>
    public bool SafeToCancel { get; set; }

    /// <summary>
    /// Не ограничивать RPC на объекте хоста лобби: хост-моды на официальных серверах легитимно рассылают
    /// много системных сообщений чата и изменений косметики/имён.
    /// </summary>
    public bool ExemptHost { get; set; }

    public List<string> RpcNames { get; set; } = new();
}

/// <summary>Индивидуальный лимит для одного RPC (перекрывает лимит категории).</summary>
public sealed class RpcOverride
{
    public string RpcName { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public int MaxEvents { get; set; } = 10;
    public int WindowMs { get; set; } = 1000;
}

public sealed class RpcShieldRuleSet
{
    public const string UnknownCategory = "Unknown";
    public const string OtherCategory = "Other";

    public int SchemaVersion { get; set; } = 1;
    public string RulesVersion { get; set; } = string.Empty;
    public string ReviewedUtc { get; set; } = string.Empty;
    public string Notice { get; set; } = string.Empty;
    public List<RpcCategory> Categories { get; set; } = new();
    public List<RpcOverride> Overrides { get; set; } = new();

    /// <summary>
    /// Консервативные значения по умолчанию. Обычное перемещение передаётся сериализацией объектов, а не RPC,
    /// поэтому нормальная частота RPC от игрока низкая. Лимиты взяты с большим запасом над обычной игрой;
    /// отменять разрешено только категории, отмена которых не меняет исход матча.
    /// </summary>
    public static RpcShieldRuleSet BuiltIn() => new()
    {
        SchemaVersion = 1,
        RulesVersion = "rpc-shield@2026.10.12-r1",
        ReviewedUtc = "2026-10-12",
        Notice = "Имена RPC сопоставляются с перечислением RpcCalls текущей версии. Unknown — номера вне перечисления, Other — остальные штатные RPC.",
        Categories = new List<RpcCategory>
        {
            new()
            {
                Name = "Animation", Description = "Поглаживание питомца и анимации заданий (визуальные эффекты). Используется для флуд-атак «Overload».",
                MaxEvents = 10, WindowMs = 1000, SafeToCancel = true,
                RpcNames = new() { "Pet", "CancelPet", "PlayAnimation" },
            },
            new()
            {
                Name = "Cosmetics", ExemptHost = true, Description = "Цвет и косметика.",
                MaxEvents = 20, WindowMs = 2000, SafeToCancel = true,
                RpcNames = new() { "SetColor", "CheckColor", "SetHatStr", "SetSkinStr", "SetVisorStr", "SetPetStr", "SetNamePlateStr" },
            },
            new()
            {
                Name = "Chat", ExemptHost = true, Description = "Сообщения чата. У обычного клиента есть пауза ~3 секунды между сообщениями.",
                MaxEvents = 4, WindowMs = 5000, SafeToCancel = true,
                RpcNames = new() { "SendChat", "SendQuickChat" },
            },
            new()
            {
                Name = "Identity", ExemptHost = true, Description = "Имя и уровень.",
                MaxEvents = 6, WindowMs = 5000, SafeToCancel = false,
                RpcNames = new() { "SetName", "CheckName", "SetLevel" },
            },
            new()
            {
                Name = "Movement", Description = "Телепорт, вентиляции, лестницы, платформы.",
                MaxEvents = 20, WindowMs = 1000, SafeToCancel = false,
                RpcNames = new() { "SnapTo", "EnterVent", "ExitVent", "BootFromVent", "ClimbLadder", "UsePlatform", "UseZipline" },
            },
            new()
            {
                Name = "Systems", Description = "Системы корабля и саботажи (видны хосту).",
                MaxEvents = 30, WindowMs = 1000, SafeToCancel = false,
                RpcNames = new() { "UpdateSystem", "CloseDoorsOfType" },
            },
            new()
            {
                Name = "Meeting", Description = "Собрания и голосование.",
                MaxEvents = 10, WindowMs = 3000, SafeToCancel = false,
                RpcNames = new() { "StartMeeting", "ReportDeadBody", "CastVote", "ClearVote", "AddVote", "SendChatNote", "VotingComplete", "CloseMeeting" },
            },
            new()
            {
                Name = "Combat", Description = "Убийства, роли, способности, задания.",
                MaxEvents = 15, WindowMs = 1000, SafeToCancel = false,
                RpcNames = new()
                {
                    "CheckMurder", "MurderPlayer", "CheckShapeshift", "Shapeshift", "RejectShapeshift", "CheckProtect", "ProtectPlayer",
                    "CheckAppear", "StartAppear", "CheckVanish", "StartVanish", "CompleteTask", "SetRole", "Exiled", "SetScanner",
                    "CheckSporeTrigger", "TriggerSpores",
                },
            },
            new()
            {
                Name = UnknownCategory, Description = "Номера RPC вне перечисления игры (моды, сторонние клиенты).",
                MaxEvents = 30, WindowMs = 1000, SafeToCancel = false,
            },
            new()
            {
                Name = OtherCategory, Description = "Прочие штатные RPC.",
                MaxEvents = 40, WindowMs = 1000, SafeToCancel = false,
            },
        },
    };
}
