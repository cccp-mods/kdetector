namespace KDetector.Core.RpcShield;

/// <summary>
/// Точный ограничитель «не более N событий за W мс» на кольцевом буфере из N меток времени.
/// O(1) на событие, память O(N). Событие на границе окна (ровно через W мс) уже не учитывается.
/// Превышающие события тоже записываются: при непрерывном спаме лимит не «отпускает» каждые W мс.
/// </summary>
public sealed class SlidingWindowCounter
{
    private long[] _stamps;
    private int _head;
    private int _count;

    public SlidingWindowCounter(int maxEvents, long windowMs)
    {
        if (maxEvents < 1) throw new ArgumentOutOfRangeException(nameof(maxEvents));
        if (windowMs < 1) throw new ArgumentOutOfRangeException(nameof(windowMs));
        MaxEvents = maxEvents;
        WindowMs = windowMs;
        _stamps = new long[maxEvents];
    }

    public int MaxEvents { get; private set; }
    public long WindowMs { get; private set; }
    public long LastHitMs { get; private set; }

    /// <summary>Регистрирует событие. Возвращает true, если лимит не превышен.</summary>
    public bool Hit(long nowMs)
    {
        LastHitMs = nowMs;
        bool allowed;
        if (_count < MaxEvents)
        {
            allowed = true;
        }
        else
        {
            // _head указывает на самую старую из N последних меток.
            var oldest = _stamps[_head];
            allowed = nowMs - oldest >= WindowMs;
        }

        if (!allowed)
        {
            // Счётчик превышений в текущей «вспышке»: даёт реальную интенсивность, а не только факт превышения.
            if (_excess == 0 || nowMs - _burstStartMs >= WindowMs)
            {
                _burstStartMs = nowMs;
                _excess = 0;
            }

            _excess++;
        }
        else if (_excess > 0 && nowMs - _burstStartMs >= WindowMs)
        {
            _excess = 0;
        }

        _stamps[_head] = nowMs;
        _head = (_head + 1) % MaxEvents;
        if (_count < MaxEvents) _count++;
        return allowed;
    }

    private int _excess;
    private long _burstStartMs;

    /// <summary>Оценка числа событий в текущем окне: лимит + число превышений во вспышке.</summary>
    public int EstimatedInWindow(long nowMs) => _excess > 0 && nowMs - _burstStartMs < WindowMs ? MaxEvents + _excess : CountInWindow(nowMs);

    /// <summary>Сколько событий из последних N попадает в окно (для статистики).</summary>
    public int CountInWindow(long nowMs)
    {
        var n = 0;
        for (var i = 0; i < _count; i++)
            if (nowMs - _stamps[i] < WindowMs) n++;
        return n;
    }

    /// <summary>Изменение лимитов на лету (горячее применение настроек) — состояние сбрасывается.</summary>
    public void Reconfigure(int maxEvents, long windowMs)
    {
        if (maxEvents == MaxEvents && windowMs == WindowMs) return;
        MaxEvents = Math.Max(1, maxEvents);
        WindowMs = Math.Max(1, windowMs);
        _stamps = new long[MaxEvents];
        _head = 0;
        _count = 0;
        _excess = 0;
    }
}
