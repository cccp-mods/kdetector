using KDetector.Core.Common;
using KDetector.Core.Detection;
using KDetector.Core.Players;
using KDetector.Core.Risk;

namespace KDetector.Core.UiModel;

/// <summary>Сортировка таблицы: повторный выбор той же колонки меняет направление.</summary>
public sealed class SortState
{
    public SortState(string column, bool descending)
    {
        Column = column;
        Descending = descending;
    }

    public string Column { get; private set; }
    public bool Descending { get; private set; }

    public void Toggle(string column)
    {
        if (Column == column) Descending = !Descending;
        else
        {
            Column = column;
            Descending = false;
        }
    }

    public string Arrow(string column) => Column == column ? (Descending ? " ▼" : " ▲") : string.Empty;
}

/// <summary>Строка таблицы Live Players.</summary>
public sealed class PlayerRow
{
    public LivePlayer Player { get; set; } = new();
    public RiskAssessment Risk { get; set; } = RiskAssessment.Empty;
    public bool Marked { get; set; }
}

public static class PlayerTable
{
    public static readonly string[] Columns = { "Имя", "ID", "Уровень", "Платформа", "Риск", "События", "Активность" };

    public static List<PlayerRow> Build(IEnumerable<LivePlayer> players, Func<PlayerIdentity, RiskAssessment> risk,
        Func<PlayerIdentity, bool> marked, string filter, SortState sort)
    {
        var rows = players.Select(p => new PlayerRow { Player = p, Risk = risk(p.Identity), Marked = marked(p.Identity) });
        if (!string.IsNullOrWhiteSpace(filter))
        {
            var f = filter.Trim();
            rows = rows.Where(r => r.Player.Identity.Name.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   r.Player.Identity.FriendCode.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   r.Player.Identity.PlayerId.ToString() == f);
        }

        Func<PlayerRow, IComparable> key = sort.Column switch
        {
            "ID" => r => r.Player.Identity.PlayerId,
            "Уровень" => r => r.Player.Identity.Level ?? 0u,
            "Платформа" => r => r.Player.Identity.Platform?.Display ?? string.Empty,
            "Риск" => r => r.Risk.Score,
            "События" => r => r.Player.EventCount,
            "Активность" => r => r.Player.LastActivityUtc,
            _ => r => r.Player.Identity.Name.ToLowerInvariant(),
        };
        return (sort.Descending ? rows.OrderByDescending(key) : rows.OrderBy(key)).ToList();
    }
}

/// <summary>Фильтр ленты событий.</summary>
public sealed class DetectionFilter
{
    public string Text { get; set; } = string.Empty;
    public DetectionCategory? Category { get; set; }
    public Severity MinSeverity { get; set; } = Severity.Info;
    public bool HideWhitelisted { get; set; }

    public List<DetectionEvent> Apply(IEnumerable<DetectionEvent> events)
    {
        var e = events.Where(x => x.Severity >= MinSeverity);
        if (Category.HasValue) e = e.Where(x => x.Category == Category.Value);
        if (HideWhitelisted) e = e.Where(x => !x.Whitelisted);
        if (!string.IsNullOrWhiteSpace(Text))
        {
            var t = Text.Trim();
            e = e.Where(x => x.Player.Name.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                             x.Summary.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                             x.RuleId.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                             x.Player.FriendCode.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        return e.OrderByDescending(x => x.TimestampUtc).ToList();
    }
}

/// <summary>
/// Подтверждение опасного действия в несколько шагов (например, «удалить всё» — два подтверждения).
/// Подтверждение «протухает» через timeout, чтобы случайный клик позже не выполнил действие.
/// </summary>
public sealed class ConfirmGate
{
    private readonly IClock _clock;
    private string? _actionId;
    private int _step;
    private long _startedMs;

    public ConfirmGate(IClock clock)
    {
        _clock = clock;
    }

    public long TimeoutMs { get; set; } = 15000;
    public string? PendingAction => IsExpired() ? null : _actionId;
    public int Step => IsExpired() ? 0 : _step;
    public string Description { get; private set; } = string.Empty;
    public int RequiredSteps { get; private set; }

    public void Begin(string actionId, string description, int requiredSteps)
    {
        _actionId = actionId;
        Description = description;
        RequiredSteps = Math.Max(1, requiredSteps);
        _step = 0;
        _startedMs = _clock.MonotonicMs;
    }

    /// <summary>Очередное подтверждение. Возвращает true, когда пройдены все шаги (действие можно выполнять ровно один раз).</summary>
    public bool Confirm(string actionId)
    {
        if (_actionId != actionId || IsExpired()) return false;
        _step++;
        _startedMs = _clock.MonotonicMs;
        if (_step < RequiredSteps) return false;
        Cancel();
        return true;
    }

    public void Cancel()
    {
        _actionId = null;
        _step = 0;
        Description = string.Empty;
    }

    private bool IsExpired() => _actionId != null && _clock.MonotonicMs - _startedMs > TimeoutMs;
}

/// <summary>Защита от многократного запуска одного действия (двойной клик, залипшая кнопка).</summary>
public sealed class ActionGuard
{
    private readonly IClock _clock;
    private readonly Dictionary<string, long> _last = new();

    public ActionGuard(IClock clock, long intervalMs = 750)
    {
        _clock = clock;
        IntervalMs = intervalMs;
    }

    public long IntervalMs { get; }

    public bool TryEnter(string key)
    {
        var now = _clock.MonotonicMs;
        if (_last.TryGetValue(key, out var t) && now - t < IntervalMs) return false;
        _last[key] = now;
        if (_last.Count > 512) _last.Clear();
        return true;
    }
}

/// <summary>Постраничный вывод больших таблиц (IMGUI медленно рисует тысячи строк).</summary>
public static class Paging
{
    public static List<T> Page<T>(IReadOnlyList<T> items, int page, int pageSize, out int pageCount)
    {
        pageSize = Math.Max(1, pageSize);
        pageCount = Math.Max(1, (items.Count + pageSize - 1) / pageSize);
        page = Math.Max(0, Math.Min(page, pageCount - 1));
        return items.Skip(page * pageSize).Take(pageSize).ToList();
    }
}
