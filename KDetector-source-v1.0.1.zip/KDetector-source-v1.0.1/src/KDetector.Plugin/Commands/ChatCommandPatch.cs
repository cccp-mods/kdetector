using KDetector.Core;

namespace KDetector.Plugin.Commands;

/// <summary>
/// Перехват отправки сообщения чата: если текст начинается с префикса KDetector (по умолчанию «/kd»),
/// команда выполняется локально, поле ввода очищается и сообщение НЕ отправляется в лобби.
/// Любой другой текст проходит без изменений. Применяется через PatchManager с высоким приоритетом.
/// </summary>
public static class ChatCommandPatch
{
    internal static KDetectorCore? Core;

    public static bool SendChatPrefix(ChatController __instance)
    {
        var core = Core;
        if (core == null || __instance == null) return true;

        string text;
        try
        {
            text = __instance.freeChatField.textArea.text ?? string.Empty;
        }
        catch
        {
            return true;
        }

        if (!core.Commands.IsCommand(text)) return true;

        try
        {
            var result = core.Commands.Execute(text);
            foreach (var line in result.Lines) LocalChat.Show(line);
        }
        catch (Exception ex)
        {
            core.Log.Error("Commands", "Ошибка выполнения команды", ex);
            LocalChat.Show("Ошибка команды — подробности в журнале.");
        }

        try
        {
            __instance.freeChatField.Clear();
        }
        catch
        {
            // поле могло быть уничтожено — не критично
        }

        return false; // команда не уходит в чат лобби
    }
}

/// <summary>Сообщения, видимые только локальному игроку (добавляются в окно чата без отправки по сети).</summary>
public static class LocalChat
{
    public static bool Show(string text)
    {
        try
        {
            if (!HudManager.InstanceExists || HudManager.Instance.Chat == null) return false;
            var local = PlayerControl.LocalPlayer;
            if (local == null) return false;
            HudManager.Instance.Chat.AddChat(local, "<color=#E5484D>[" + global::KDetector.Plugin.PluginMetadata.Name + "]</color> " + text, false);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
