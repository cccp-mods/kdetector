using System.Reflection;
using HarmonyLib;
using Hazel;
using KDetector.Core;
using KDetector.Core.Detection;
using KDetector.Core.Diagnostics;
using KDetector.Plugin.Commands;
using KDetector.Plugin.Network;
using KDetector.Plugin.UI;

namespace KDetector.Plugin.Compatibility;

/// <summary>
/// Применение Harmony-патчей с проверкой совместимости.
/// Каждый патч применяется отдельно: если метод не найден в текущей версии игры, соответствующий модуль
/// отключается с понятной причиной (страница Diagnostics), остальные продолжают работать.
/// Патчи накладываются только на методы, объявленные в самом типе (без подмены базового метода для всех объектов).
/// </summary>
public sealed class PatchManager
{
    private static bool _applied;
    private readonly Harmony _harmony;
    private readonly KDetectorCore _core;

    public PatchManager(string harmonyId, KDetectorCore core)
    {
        _harmony = new Harmony(harmonyId);
        _core = core;
    }

    public Dictionary<string, bool> Results { get; } = new();

    public void ApplyAll()
    {
        if (_applied)
        {
            _core.Log.Warn("Patches", "Повторное применение патчей пропущено (защита от двойной инициализации).");
            return;
        }

        _applied = true;
        RpcPatches.Core = _core;
        ChatCommandPatch.Core = _core;

        var rpcArgs = new[] { typeof(byte), typeof(MessageReader) };
        var pc = Patch("RPC: PlayerControl", typeof(PlayerControl), "HandleRpc", rpcArgs, nameof(RpcPatches.PlayerControlPrefix), typeof(RpcPatches));
        var physics = Patch("RPC: PlayerPhysics", typeof(PlayerPhysics), "HandleRpc", rpcArgs, nameof(RpcPatches.PlayerPhysicsPrefix), typeof(RpcPatches));
        var cnt = Patch("RPC: CustomNetworkTransform", typeof(CustomNetworkTransform), "HandleRpc", rpcArgs, nameof(RpcPatches.NetworkTransformPrefix), typeof(RpcPatches));
        var systems = Patch("RPC: ShipStatus.UpdateSystem", typeof(ShipStatus), "UpdateSystem",
            new[] { typeof(SystemTypes), typeof(PlayerControl), typeof(MessageReader) }, nameof(RpcPatches.UpdateSystemPrefix), typeof(RpcPatches));

        if (!pc)
        {
            const string reason = "Не найден PlayerControl.HandleRpc в текущей версии игры — сетевые проверки отключены.";
            _core.Registry.SetAvailabilityForCategory(DetectionCategory.RpcSpam, RuleAvailability.Unavailable, reason);
            _core.Registry.SetAvailabilityForCategory(DetectionCategory.KnownClient, RuleAvailability.Unavailable, reason);
            _core.Registry.SetAvailabilityForCategory(DetectionCategory.InvalidAction, RuleAvailability.Unavailable, reason);
            _core.Diagnostics.AddWarning(reason);
        }
        else if (!physics || !cnt || !systems)
        {
            const string reason = "Часть обработчиков RPC не найдена: проверки работают только для доступных объектов (см. Diagnostics).";
            _core.Registry.SetAvailabilityForCategory(DetectionCategory.RpcSpam, RuleAvailability.Limited, reason);
            _core.Diagnostics.AddWarning(reason);
        }

        if (!systems)
            _core.Diagnostics.AddWarning("ShipStatus.UpdateSystem не перехвачен: частота саботажей не контролируется.");

        Patch("Команды чата", typeof(ChatController), "SendChat", null, nameof(ChatCommandPatch.SendChatPrefix), typeof(ChatCommandPatch), Priority.First);

        // Блокировка кликов сквозь окно (необязательно).
        var blocked = 0;
        foreach (var name in new[] { "ReceiveClickDown", "ReceiveClickUp", "ReceiveMouseOver" })
            if (Patch("UI: PassiveButton." + name, typeof(PassiveButton), name, null, nameof(InputBlockPatch.Prefix), typeof(InputBlockPatch), optional: true))
                blocked++;
        _core.Diagnostics.SetModule("Блокировка кликов под окном", blocked == 3 ? ModuleState.Ok : ModuleState.Warning,
            blocked == 3 ? "клики по окну не проходят в игру" : $"перехвачено {blocked} из 3 методов");
    }

    private bool Patch(string module, Type type, string methodName, Type[]? args, string prefixName, Type patchClass, int priority = Priority.Normal, bool optional = false)
    {
        try
        {
            var original = args == null
                ? AccessTools.DeclaredMethod(type, methodName)
                : AccessTools.DeclaredMethod(type, methodName, args);
            if (original == null)
            {
                Report(module, false, $"метод {type.Name}.{methodName} не найден", optional);
                return false;
            }

            var prefix = AccessTools.Method(patchClass, prefixName);
            if (prefix == null) throw new MissingMethodException(patchClass.Name, prefixName);

            if (Harmony.GetPatchInfo(original)?.Prefixes.Any(p => p.owner == _harmony.Id && p.PatchMethod == prefix) == true)
            {
                Report(module, true, "уже применён", optional);
                return true;
            }

            _harmony.Patch(original, prefix: new HarmonyMethod(prefix) { priority = priority });
            Report(module, true, $"{type.Name}.{methodName}", optional);
            return true;
        }
        catch (Exception ex)
        {
            Report(module, false, "ошибка применения: " + ex.Message, optional);
            _core.Log.Error("Patches", $"Не удалось применить патч {module}", ex);
            return false;
        }
    }

    private void Report(string module, bool ok, string detail, bool optional)
    {
        Results[module] = ok;
        _core.Diagnostics.SetModule("Патч: " + module, ok ? ModuleState.Ok : optional ? ModuleState.Warning : ModuleState.Error, detail);
        if (ok) _core.Log.Debug("Patches", $"{module}: {detail}");
        else _core.Log.Warn("Patches", $"{module}: {detail}");
    }

    public void UnpatchAll()
    {
        try
        {
            _harmony.UnpatchSelf();
        }
        catch (Exception ex)
        {
            _core.Log.Error("Patches", "Ошибка снятия патчей", ex);
        }

        RpcPatches.Core = null;
        ChatCommandPatch.Core = null;
        _applied = false;
    }

    public static MethodBase? Find(Type type, string method) => AccessTools.DeclaredMethod(type, method);
}
