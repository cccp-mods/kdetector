using System.Globalization;
using System.Reflection;
using BepInEx.Configuration;
using KDetector.Core;
using KDetector.Core.Configuration;
using KDetector.Core.Logging;

namespace KDetector.Plugin.Configuration;

/// <summary>
/// Двусторонняя привязка настроек ядра (KdSettings) к BepInEx ConfigFile (BepInEx/config/dev.kdetector.amongus.cfg).
/// Каждое свойство с [Setting] становится записью в секции, описание берётся из атрибута.
/// Изменение файла или значения применяется на лету (кроме параметров, помеченных RequiresRestart).
/// </summary>
public sealed class ConfigBinder
{
    private readonly ConfigFile _config;
    private readonly KdSettings _settings;
    private readonly KdLog _log;
    private readonly List<Binding> _bindings = new();
    private bool _suppress;

    public ConfigBinder(ConfigFile config, KdSettings settings, KdLog log)
    {
        _config = config;
        _settings = settings;
        _log = log;
    }

    public event Action? Changed;

    public void BindAll(IEnumerable<string> ruleIds)
    {
        _config.SaveOnConfigSet = false;
        foreach (var section in _settings.Sections())
            BindObject(section, SettingsValidator.SectionName(section.GetType()));

        foreach (var id in ruleIds)
            BindObject(_settings.Rule(id), "Rule." + id);

        _config.Save();
        _config.SaveOnConfigSet = true;
        _config.SettingChanged += OnSettingChanged;
        _config.ConfigReloaded += OnReloaded;
    }

    private void BindObject(object target, string section)
    {
        foreach (var prop in SettingsValidator.SettingProperties(target.GetType()))
        {
            var attr = prop.GetCustomAttribute<SettingAttribute>()!;
            var description = attr.Description + (attr.RequiresRestart ? " (вступает в силу после перезапуска игры)" : string.Empty);
            if (!double.IsNaN(attr.Min) || !double.IsNaN(attr.Max))
                description += $" Диапазон: {Fmt(attr.Min)}…{Fmt(attr.Max)}.";
            if (!string.IsNullOrEmpty(attr.Allowed)) description += $" Допустимо: {attr.Allowed}.";

            // Значение по умолчанию = текущее значение в момент привязки: для секций это значения класса,
            // для правил — значения по умолчанию из дескриптора правила (порог, окно).
            var defaultValue = prop.GetValue(target);
            ConfigEntryBase entry = prop.PropertyType switch
            {
                var t when t == typeof(bool) => _config.Bind(section, prop.Name, (bool)defaultValue!, description),
                var t when t == typeof(int) => _config.Bind(section, prop.Name, (int)defaultValue!, description),
                var t when t == typeof(double) => _config.Bind(section, prop.Name, (double)defaultValue!, description),
                var t when t == typeof(string) => _config.Bind(section, prop.Name, (string)defaultValue! ?? string.Empty, description),
                var t when t.IsEnum => BindEnum(section, prop.Name, defaultValue!, description),
                _ => throw new NotSupportedException($"Тип настройки {prop.PropertyType.Name} не поддерживается"),
            };

            // Значение из файла → в настройки ядра.
            if (entry.BoxedValue != null) prop.SetValue(target, entry.BoxedValue);

            _bindings.Add(new Binding(target, prop, entry, attr.RequiresRestart));
        }
    }

    private ConfigEntryBase BindEnum(string section, string key, object defaultValue, string description)
    {
        var names = string.Join(", ", Enum.GetNames(defaultValue.GetType()));
        var method = typeof(ConfigFile).GetMethods()
            .First(m => m.Name == nameof(ConfigFile.Bind) && m.IsGenericMethodDefinition &&
                        m.GetParameters().Length == 4 && m.GetParameters()[0].ParameterType == typeof(string) &&
                        m.GetParameters()[3].ParameterType == typeof(string))
            .MakeGenericMethod(defaultValue.GetType());
        return (ConfigEntryBase)method.Invoke(_config, new[] { section, key, defaultValue, description + $" Значения: {names}." })!;
    }

    private static string Fmt(double v) => double.IsNaN(v) ? "" : v.ToString(CultureInfo.InvariantCulture);

    private void OnSettingChanged(object? sender, SettingChangedEventArgs e)
    {
        if (_suppress) return;
        var b = _bindings.FirstOrDefault(x => ReferenceEquals(x.Entry, e.ChangedSetting));
        if (b == null) return;
        try
        {
            b.Property.SetValue(b.Target, b.Entry.BoxedValue);
            if (b.RequiresRestart) _log.Info("Config", $"{b.Entry.Definition.Section}.{b.Entry.Definition.Key} изменён — вступит в силу после перезапуска игры.");
            ValidateAndPush();
            Changed?.Invoke();
        }
        catch (Exception ex)
        {
            _log.Error("Config", "Не удалось применить настройку " + b.Entry.Definition.Key, ex);
        }
    }

    private void OnReloaded(object? sender, EventArgs e)
    {
        foreach (var b in _bindings)
        {
            try
            {
                b.Property.SetValue(b.Target, b.Entry.BoxedValue);
            }
            catch (Exception ex)
            {
                _log.Error("Config", "Ошибка перечитывания " + b.Entry.Definition.Key, ex);
            }
        }

        ValidateAndPush();
        Changed?.Invoke();
        _log.Info("Config", "Конфигурация перечитана с диска.");
    }

    /// <summary>Проверка значений; исправленные значения записываются обратно в файл.</summary>
    private void ValidateAndPush()
    {
        foreach (var w in SettingsValidator.Validate(_settings))
            _log.Warn("Config", w);
        PushToConfig();
    }

    /// <summary>Записать текущие значения ядра в ConfigFile (после изменений из GUI/команд).</summary>
    public void PushToConfig()
    {
        _suppress = true;
        try
        {
            _config.SaveOnConfigSet = false;
            foreach (var b in _bindings)
            {
                var value = b.Property.GetValue(b.Target);
                if (!Equals(b.Entry.BoxedValue, value)) b.Entry.BoxedValue = value;
            }

            _config.Save();
        }
        catch (Exception ex)
        {
            _log.Error("Config", "Не удалось сохранить конфигурацию", ex);
        }
        finally
        {
            _config.SaveOnConfigSet = true;
            _suppress = false;
        }
    }

    public string ConfigFilePath => _config.ConfigFilePath;

    private sealed class Binding
    {
        public Binding(object target, PropertyInfo property, ConfigEntryBase entry, bool requiresRestart)
        {
            Target = target;
            Property = property;
            Entry = entry;
            RequiresRestart = requiresRestart;
        }

        public object Target { get; }
        public PropertyInfo Property { get; }
        public ConfigEntryBase Entry { get; }
        public bool RequiresRestart { get; }
    }
}
