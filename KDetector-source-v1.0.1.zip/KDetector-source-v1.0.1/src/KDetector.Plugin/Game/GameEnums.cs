namespace KDetector.Plugin.Game;

/// <summary>
/// Таблицы перечислений игры, построенные один раз при запуске (без выделений памяти в сетевых обработчиках).
/// Значения берутся из interop-сборок установленной версии игры, а не из захардкоженных номеров.
/// </summary>
public static class GameEnums
{
    private static readonly string?[] RpcNames = new string?[256];
    private static readonly Dictionary<int, string> PlatformNames = new();

    public static int RpcCount { get; private set; }
    public static int PlatformCount { get; private set; }

    /// <summary>Номер RPC UpdateSystem в текущей версии (для отображения), -1 если не найден.</summary>
    public static int UpdateSystemCallId { get; private set; } = -1;

    public static void Initialize()
    {
        Array.Clear(RpcNames, 0, RpcNames.Length);
        RpcCount = 0;
        foreach (var value in Enum.GetValues(typeof(RpcCalls)))
        {
            var number = Convert.ToInt32(value);
            if (number < 0 || number > 255) continue;
            RpcNames[number] = Enum.GetName(typeof(RpcCalls), value);
            RpcCount++;
            if (RpcNames[number] == "UpdateSystem") UpdateSystemCallId = number;
        }

        PlatformNames.Clear();
        foreach (var value in Enum.GetValues(typeof(Platforms)))
            PlatformNames[Convert.ToInt32(value)] = Enum.GetName(typeof(Platforms), value) ?? value.ToString()!;
        PlatformCount = PlatformNames.Count;
    }

    public static string? RpcName(byte callId) => RpcNames[callId];

    public static bool IsVanillaRpc(byte callId) => RpcNames[callId] != null;

    public static string? PlatformName(int id) => PlatformNames.TryGetValue(id, out var n) ? n : null;
}
