using InnerNet;
using KDetector.Core.Configuration;
using KDetector.Core.Game;
using UnityEngine;

namespace KDetector.Plugin.Game;

/// <summary>Чтение состояния игры в GameContext. Любая ошибка → безопасное состояние Unknown.</summary>
public static class GameStateReader
{
    public static GameContext Read(KdSettings settings)
    {
        var ctx = new GameContext { GameVersion = SafeVersion() };
        try
        {
            var client = AmongUsClient.Instance;
            if (client == null)
            {
                ctx.Phase = GamePhase.NotConnected;
                return ctx;
            }

            if (client.NetworkMode == NetworkModes.FreePlay)
            {
                ctx.Phase = GamePhase.FreePlay;
                return ctx;
            }

            var state = client.GameState;
            if (state == InnerNetClient.GameStates.NotJoined)
            {
                ctx.Phase = GamePhase.NotConnected;
                return ctx;
            }

            if (client.NetworkMode == NetworkModes.LocalGame)
            {
                // Локальная игра по сети: проверки работают, но сервер не официальный.
                ctx.RegionName = "Local";
            }

            ctx.LocalIsHost = client.AmHost;
            ctx.LocalClientId = client.ClientId;
            ctx.HostClientId = client.HostId;
            ctx.SessionId = SafeGameCode(client.GameId);

            if (state == InnerNetClient.GameStates.Ended) ctx.Phase = GamePhase.Ended;
            else if (state == InnerNetClient.GameStates.Joined) ctx.Phase = GamePhase.Lobby;
            else if (MeetingHud.Instance != null) ctx.Phase = GamePhase.Meeting;
            else if (IntroCutscene.Instance != null) ctx.Phase = GamePhase.Intro;
            else if (state == InnerNetClient.GameStates.Started) ctx.Phase = GamePhase.Tasks;
            else ctx.Phase = GamePhase.Unknown;

            if (client.NetworkMode == NetworkModes.OnlineGame)
            {
                var region = ServerManager.Instance != null && ServerManager.Instance.CurrentRegion != null
                    ? ServerManager.Instance.CurrentRegion.Name
                    : string.Empty;
                ctx.RegionName = region ?? string.Empty;
                ctx.OnOfficialServer = KdSettings.SplitList(settings.Compatibility.OfficialRegions)
                    .Contains(ctx.RegionName, StringComparer.OrdinalIgnoreCase);
            }

            // Эвристика модифицированного протокола: OwnerId = -2 у данных локального игрока.
            var local = PlayerControl.LocalPlayer;
            ctx.ModdedProtocol = local != null && local.Data != null && local.Data.OwnerId == -2;
        }
        catch (Exception)
        {
            ctx.Phase = GamePhase.Unknown;
        }

        return ctx;
    }

    private static string SafeVersion()
    {
        try
        {
            return Application.version ?? string.Empty;
        }
        catch
        {
            return string.Empty;
        }
    }

    private static string SafeGameCode(int gameId)
    {
        try
        {
            return GameCode.IntToGameName(gameId) ?? gameId.ToString();
        }
        catch
        {
            return gameId.ToString();
        }
    }
}
