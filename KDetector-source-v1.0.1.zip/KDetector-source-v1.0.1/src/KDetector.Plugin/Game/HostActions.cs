using HarmonyLib;
using InnerNet;
using KDetector.Core.Actions;

namespace KDetector.Plugin.Game;

/// <summary>
/// Kick/Ban через штатный API игры. Полномочия проверяются в момент вызова.
/// «Бан» — бан в текущем лобби средствами игры; глобального бана или бана на сервере у клиента нет.
/// </summary>
public sealed class HostActions : IHostActions
{
    public HostActions()
    {
        KickAvailable = AccessTools.Method(typeof(InnerNetClient), nameof(InnerNetClient.KickPlayer)) != null;
    }

    public bool KickAvailable { get; }

    public bool LocalIsHostNow()
    {
        try
        {
            var c = AmongUsClient.Instance;
            return c != null && c.AmHost && c.GameState != InnerNetClient.GameStates.NotJoined;
        }
        catch
        {
            return false;
        }
    }

    public bool TryKick(int clientId, bool ban, out string error)
    {
        error = string.Empty;
        try
        {
            if (!LocalIsHostNow())
            {
                error = "вы не хост этого лобби";
                return false;
            }

            if (clientId == AmongUsClient.Instance.ClientId)
            {
                error = "нельзя применить к себе";
                return false;
            }

            AmongUsClient.Instance.KickPlayer(clientId, ban);
            return true;
        }
        catch (Exception ex)
        {
            error = "ошибка вызова игры: " + ex.Message;
            return false;
        }
    }
}
