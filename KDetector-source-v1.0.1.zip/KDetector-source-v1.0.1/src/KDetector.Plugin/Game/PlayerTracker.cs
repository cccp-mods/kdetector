using InnerNet;
using KDetector.Core.Common;
using KDetector.Core.Players;

namespace KDetector.Plugin.Game;

/// <summary>
/// Снимок игроков лобби. Вызывается из Update с интервалом (не каждый кадр).
/// Игроки с неполными данными пропускаются: уровень и платформа появляются у клиента с задержкой.
/// </summary>
public static class PlayerTracker
{
    private static readonly Dictionary<int, ClientData> ClientsById = new();
    private static readonly Dictionary<string, string> PuidHashCache = new();

    public static List<PlayerIdentity> Snapshot()
    {
        var result = new List<PlayerIdentity>();
        var client = AmongUsClient.Instance;
        if (client == null) return result;

        IndexClients(client);
        var hostId = client.HostId;
        var localId = client.ClientId;

        foreach (var pc in PlayerControl.AllPlayerControls)
        {
            try
            {
                if (pc == null || pc.isDummy) continue;
                var data = pc.Data;
                if (data == null || data.IsIncomplete) continue;

                var clientId = data.ClientId;
                var identity = new PlayerIdentity
                {
                    ClientId = clientId,
                    PlayerId = pc.PlayerId,
                    Name = data.PlayerName ?? string.Empty,
                    FriendCode = data.FriendCode ?? string.Empty,
                    HashPuid = HashPuid(data.Puid),
                    Level = unchecked((uint)data.PlayerLevel),
                    IsHost = clientId == hostId,
                    IsLocal = clientId == localId,
                };

                if (ClientsById.TryGetValue(clientId, out var cd) && cd != null)
                    identity.Platform = ReadPlatform(cd);

                result.Add(identity);
            }
            catch
            {
                // Объект игрока мог уничтожиться между кадрами — пропускаем его в этом снимке.
            }
        }

        return result;
    }

    /// <summary>Быстрая сборка идентичности для RPC от игрока, которого трекер ещё не успел учесть.</summary>
    public static PlayerIdentity? Quick(PlayerControl? pc)
    {
        try
        {
            if (pc == null) return null;
            var data = pc.Data;
            if (data == null) return null;
            var client = AmongUsClient.Instance;
            return new PlayerIdentity
            {
                ClientId = data.ClientId,
                PlayerId = pc.PlayerId,
                Name = data.PlayerName ?? string.Empty,
                FriendCode = data.FriendCode ?? string.Empty,
                HashPuid = HashPuid(data.Puid),
                IsHost = client != null && data.ClientId == client.HostId,
                IsLocal = client != null && data.ClientId == client.ClientId,
            };
        }
        catch
        {
            return null;
        }
    }

    private static void IndexClients(AmongUsClient client)
    {
        ClientsById.Clear();
        try
        {
            foreach (var cd in client.allClients)
                if (cd != null) ClientsById[cd.Id] = cd;
        }
        catch (InvalidOperationException)
        {
            // Список изменился во время перебора — используем копию.
            ClientsById.Clear();
            foreach (var cd in client.allClients.ToArray())
                if (cd != null) ClientsById[cd.Id] = cd;
        }
    }

    private static PlatformInfo? ReadPlatform(ClientData cd)
    {
        var pd = cd.PlatformData;
        if (pd == null) return null;
        var id = Convert.ToInt32(pd.Platform);
        return new PlatformInfo
        {
            PlatformId = id,
            EnumName = GameEnums.PlatformName(id),
            PlatformName = pd.PlatformName ?? string.Empty,
            XboxPlatformId = unchecked((ulong)pd.XboxPlatformId),
            PsnPlatformId = unchecked((ulong)pd.PsnPlatformId),
            Source = "ClientData.PlatformData",
        };
    }

    private static string HashPuid(string? puid)
    {
        if (string.IsNullOrEmpty(puid)) return string.Empty;
        if (PuidHashCache.TryGetValue(puid!, out var h)) return h;
        h = Hashing.HashPuid(puid);
        if (PuidHashCache.Count > 1000) PuidHashCache.Clear();
        PuidHashCache[puid!] = h;
        return h;
    }
}
