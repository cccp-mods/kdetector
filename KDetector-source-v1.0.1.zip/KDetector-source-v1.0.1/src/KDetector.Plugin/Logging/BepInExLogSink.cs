using BepInEx.Logging;
using KDetector.Core.Logging;

namespace KDetector.Plugin.Logging;

/// <summary>Вывод журнала KDetector в консоль/лог BepInEx (BepInEx/LogOutput.*).</summary>
public sealed class BepInExLogSink : ILogSink
{
    private readonly ManualLogSource _source;

    public BepInExLogSink(ManualLogSource source)
    {
        _source = source;
    }

    public void Write(DateTime utc, KdLogLevel level, string source, string message)
    {
        var text = $"[{source}] {message}";
        switch (level)
        {
            case KdLogLevel.Debug:
                _source.LogDebug(text);
                break;
            case KdLogLevel.Warning:
                _source.LogWarning(text);
                break;
            case KdLogLevel.Error:
                _source.LogError(text);
                break;
            default:
                _source.LogInfo(text);
                break;
        }
    }
}
