using HarmonyLib;
using Hazel;
using InnerNet;
using KDetector.Core;
using KDetector.Core.Logging;
using KDetector.Core.Network;
using KDetector.Core.Players;
using KDetector.Plugin.Game;

namespace KDetector.Plugin.Network;

/// <summary>
/// Префиксы обработчиков входящих RPC. Применяются вручную через PatchManager (с проверкой наличия метода),
/// поэтому здесь нет атрибутов [HarmonyPatch]. Возврат false отменяет обработку ОДНОГО RPC — только если
/// ядро решило, что отмена безопасна и разрешена профилем. Любая ошибка → RPC обрабатывается игрой как обычно.
/// </summary>
public static class RpcPatches
{
    internal static KDetectorCore? Core;

    /// <summary>Максимум байт полезной нагрузки, копируемых для проверки сигнатур.</summary>
    private const int MaxPayloadCopy = 256;

    public static bool PlayerControlPrefix(PlayerControl __instance, [HarmonyArgument(0)] byte callId, [HarmonyArgument(1)] MessageReader reader)
        => Handle(__instance, callId, reader, NetObjectKind.PlayerControl, null);

    public static bool PlayerPhysicsPrefix(PlayerPhysics __instance, [HarmonyArgument(0)] byte callId, [HarmonyArgument(1)] MessageReader reader)
        => Handle(__instance == null ? null : __instance.myPlayer, callId, reader, NetObjectKind.PlayerPhysics, null);

    public static bool NetworkTransformPrefix(CustomNetworkTransform __instance, [HarmonyArgument(0)] byte callId, [HarmonyArgument(1)] MessageReader reader)
        => Handle(__instance == null ? null : __instance.myPlayer, callId, reader, NetObjectKind.NetworkTransform, null);

    public static bool UpdateSystemPrefix([HarmonyArgument(0)] SystemTypes systemType, [HarmonyArgument(1)] PlayerControl player, [HarmonyArgument(2)] MessageReader msgReader)
    {
        var id = GameEnums.UpdateSystemCallId;
        return Handle(player, id >= 0 ? (byte)id : (byte)0, msgReader, NetObjectKind.ShipStatus, systemType.ToString(), forceName: "UpdateSystem");
    }

    private static bool Handle(PlayerControl? player, byte callId, MessageReader reader, NetObjectKind kind, string? systemName, string? forceName = null)
    {
        var core = Core;
        if (core == null) return true;

        try
        {
            if (player == null) return true;
            var data = player.Data;
            if (data == null) return true;

            var client = AmongUsClient.Instance;
            if (client == null) return true;

            var clientId = data.ClientId;
            if (clientId == client.ClientId) return true; // собственные RPC не проверяются

            var sender = core.Players.FindIdentity(clientId) ?? PlayerTracker.Quick(player);
            if (sender == null) return true;

            var obs = new RpcObservation
            {
                CallId = callId,
                RpcName = forceName ?? GameEnums.RpcName(callId),
                ObjectKind = kind,
                Sender = sender,
                SenderIsHost = clientId == client.HostId,
                SystemName = systemName,
            };

            // Копия полезной нагрузки нужна только для сигнатур известных клиентов; для остальных RPC — без копирования.
            if (core.KnownClients.IsCandidateCallId(callId))
            {
                var r = reader;
                obs.PayloadProvider = max => CopyPayload(r, Math.Min(max, MaxPayloadCopy));
            }

            var verdict = core.InspectRpc(obs);
            return !verdict.Cancel;
        }
        catch (Exception ex)
        {
            core.Log.Throttled("rpc-prefix", 30000, KdLogLevel.Error, "Network", "Ошибка в обработчике RPC (пропущено без изменений): " + ex.Message);
            return true;
        }
    }

    /// <summary>Читает ограниченную копию оставшихся байтов, не изменяя позицию исходного читателя.</summary>
    private static byte[] CopyPayload(MessageReader source, int max)
    {
        if (source == null) return Array.Empty<byte>();
        MessageReader? copy = null;
        try
        {
            copy = MessageReader.Get(source);
            var n = Math.Max(0, Math.Min(max, copy.BytesRemaining));
            var bytes = new byte[n];
            for (var i = 0; i < n; i++) bytes[i] = copy.ReadByte();
            return bytes;
        }
        catch
        {
            return Array.Empty<byte>();
        }
        finally
        {
            try
            {
                copy?.Recycle();
            }
            catch
            {
                // переиспользование пула Hazel — не критично
            }
        }
    }
}
