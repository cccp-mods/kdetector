using BepInEx;
using BepInEx.Unity.IL2CPP;
using Il2CppInterop.Runtime.Injection;
using KDetector.Core;
using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Diagnostics;
using KDetector.Core.Logging;
using KDetector.Core.RpcShield;
using KDetector.Plugin.Compatibility;
using KDetector.Plugin.Configuration;
using KDetector.Plugin.Game;
using KDetector.Plugin.Logging;
using KDetector.Plugin.UI;

namespace KDetector.Plugin;

/// <summary>
/// Точка входа BepInEx. Инициализация разбита на этапы: ошибка любого необязательного этапа журналируется
/// и отключает только соответствующую функцию; ошибка ядра отключает KDetector, но не роняет игру.
/// </summary>
[BepInPlugin(PluginMetadata.Guid, PluginMetadata.Name, PluginMetadata.Version)]
[BepInProcess(PluginMetadata.ProcessName)]
public sealed class KDetectorPlugin : BasePlugin
{
    private static bool _loaded;
    private static bool _shutDown;
    private RotatingFileSink? _fileSink;

    public static KDetectorPlugin? Instance { get; private set; }
    public static KDetectorCore? CoreInstance { get; private set; }
    public static ConfigBinder? Binder { get; private set; }
    public static PatchManager? Patches { get; private set; }
    public static KdLog? KdLogger { get; private set; }

    /// <summary>Настройки изменены из GUI/команд — сохранить в .cfg (с задержкой, не каждый кадр).</summary>
    public static bool ConfigDirty;

    public override void Load()
    {
        if (_loaded)
        {
            Log.LogWarning(PluginMetadata.Name + " уже загружен — повторная инициализация пропущена.");
            return;
        }

        _loaded = true;
        Instance = this;

        var log = new KdLog(SystemClock.Instance);
        KdLogger = log;
        log.AddSink(new BepInExLogSink(Log));
        log.Info("Core", $"{PluginMetadata.Name} v{PluginMetadata.Version} загружается. {PluginMetadata.Disclaimer}");

        var paths = new KdPaths(Path.Combine(Paths.PluginPath, PluginMetadata.FolderName));
        var settings = new KdSettings();

        // 1. Конфигурация BepInEx (до создания ядра: ядро сразу использует пути и параметры).
        try
        {
            foreach (var d in AllDescriptors())
                if (!settings.Rules.ContainsKey(d.Id)) settings.Rules[d.Id] = d.CreateDefaultSettings();
            Binder = new ConfigBinder(Config, settings, log);
            Binder.BindAll(settings.Rules.Keys.ToList());
        }
        catch (Exception ex)
        {
            log.Error("Config", "Ошибка загрузки конфигурации — используются значения по умолчанию", ex);
        }

        log.MinLevel = settings.Logging.DiagnosticMode ? KdLogLevel.Debug : settings.Logging.Level;

        // 2. Файловый журнал с ротацией.
        if (settings.Logging.FileLogging)
        {
            try
            {
                _fileSink = new RotatingFileSink(Path.Combine(paths.LogsDirectory, "KDetector.log"), settings.Logging.MaxFileSizeKb * 1024L, settings.Logging.MaxFiles);
                log.AddSink(_fileSink);
            }
            catch (Exception ex)
            {
                log.Error("Logging", "Файловый журнал недоступен", ex);
            }
        }

        // 3. Ядро (обязательно).
        KDetectorCore core;
        try
        {
            core = new KDetectorCore(settings, paths, SystemClock.Instance, log);
            core.Initialize();
            CoreInstance = core;
            core.Diagnostics.SetModule("Ядро", ModuleState.Ok, $"правил: {core.Registry.All().Count}");
            core.Diagnostics.SetModule("Конфигурация", Binder != null ? ModuleState.Ok : ModuleState.Error, Binder?.ConfigFilePath ?? "не загружена");
        }
        catch (Exception ex)
        {
            log.Error("Core", "Ядро " + PluginMetadata.Name + " не запущено — плагин отключён, игра продолжит работу без него", ex);
            return;
        }

        // 4. Перечисления игры (RpcCalls, Platforms) из interop-сборок.
        try
        {
            GameEnums.Initialize();
            core.SetVanillaRpcPredicate(GameEnums.IsVanillaRpc);
            core.Diagnostics.SetModule("Перечисления игры", ModuleState.Ok, $"RpcCalls: {GameEnums.RpcCount}, Platforms: {GameEnums.PlatformCount}");
        }
        catch (Exception ex)
        {
            core.Diagnostics.SetModule("Перечисления игры", ModuleState.Error, ex.Message);
            core.Registry.SetAvailabilityForCategory(DetectionCategory.InvalidPlatform, RuleAvailability.Unavailable, "перечисление Platforms недоступно");
            log.Error("Compatibility", "Не удалось прочитать перечисления игры", ex);
        }

        // 5. Действия хоста и уведомления.
        try
        {
            var host = new HostActions();
            core.Actions.Host = host;
            core.Diagnostics.SetModule("Kick/Ban (хост)", host.KickAvailable ? ModuleState.Ok : ModuleState.Disabled,
                host.KickAvailable ? "InnerNetClient.KickPlayer найден; выполняется только когда вы хост" : "InnerNetClient.KickPlayer не найден");
        }
        catch (Exception ex)
        {
            log.Error("Actions", "Действия хоста недоступны", ex);
        }

        core.Actions.Notifier = new Toasts(settings);

        // 6. Harmony-патчи.
        try
        {
            Patches = new PatchManager(PluginMetadata.Guid, core);
            Patches.ApplyAll();
        }
        catch (Exception ex)
        {
            log.Error("Patches", "Ошибка применения патчей", ex);
        }

        // 7. Связь настроек: изменения из GUI/команд → .cfg; изменения .cfg → ядро.
        core.SettingsChanged += () => ConfigDirty = true;
        if (Binder != null) Binder.Changed += core.OnSettingsReloaded;

        // 8. Интерфейс.
        try
        {
            UiState.Core = core;
            UiState.Window = new UnityEngine.Rect(settings.Gui.WindowX, settings.Gui.WindowY, settings.Gui.WindowWidth, settings.Gui.WindowHeight);
            // Явная регистрация типа в IL2CPP (не полагаемся на неявную регистрацию внутри AddComponent).
            if (!ClassInjector.IsTypeRegisteredInIl2Cpp<KDetectorBehaviour>())
                ClassInjector.RegisterTypeInIl2Cpp<KDetectorBehaviour>();
            AddComponent<KDetectorBehaviour>();
            core.Diagnostics.SetModule("Интерфейс", ModuleState.Ok, $"клавиша {settings.Gui.Hotkey}");
        }
        catch (Exception ex)
        {
            core.Diagnostics.SetModule("Интерфейс", ModuleState.Error, ex.Message);
            log.Error("UI", "Интерфейс не создан (команды /kd продолжают работать)", ex);
        }

        log.Info("Core", $"{PluginMetadata.Name} готов. Открыть окно: {settings.Gui.Hotkey}. Команды: {settings.Commands.Prefix} help.");
    }

    public override bool Unload()
    {
        Shutdown();
        return true;
    }

    /// <summary>Снятие патчей и сохранение данных (выход из игры или выгрузка плагина).</summary>
    public static void Shutdown()
    {
        if (_shutDown) return;
        _shutDown = true;
        try
        {
            UiState.Core = null; // интерфейс и тики перестают обращаться к ядру
            Patches?.UnpatchAll();
            Binder?.PushToConfig();
            CoreInstance?.Dispose();
        }
        catch (Exception ex)
        {
            KdLogger?.Error("Core", "Ошибка при завершении", ex);
        }
        finally
        {
            Instance?._fileSink?.Dispose();
        }
    }

    private static IEnumerable<RuleDescriptor> AllDescriptors() =>
        LevelRules.Descriptors()
            .Concat(PlatformRules.Descriptors())
            .Concat(new[] { KnownClientRules.Descriptor() })
            .Concat(ProtocolRules.Descriptors())
            .Concat(RpcShieldEngine.Descriptors());
}
