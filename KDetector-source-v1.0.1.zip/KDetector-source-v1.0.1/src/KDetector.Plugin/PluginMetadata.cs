using KDetector.Core.Common;

namespace KDetector.Plugin;

public static class PluginMetadata
{
    public const string Guid = "dev.kdetector.amongus";
    public const string Name = ProductIdentity.DisplayName;
    public const string FolderName = "KDetector";
    public const string Version = "1.0.1";
    public const string ProcessName = "Among Us.exe";

    /// <summary>Версия игры, против которой проверены точки интеграции (Application.version).</summary>
    public const string VerifiedGameVersion = "2026.9.29";

    public const string Disclaimer =
        ProductIdentity.DisplayName + " — независимый фанатский проект. Не связан с InnerSloth LLC, разработчиками Among Us или BetterAmongUs.";
}
