namespace KDetector.Plugin.UI;

/// <summary>
/// Опасные действия интерфейса выполняются только после подтверждения в баннере (ConfirmGate).
/// Действие выполняется ровно один раз; подтверждение «протухает» через 15 секунд.
/// </summary>
public static class ConfirmActions
{
    private static Func<string>? _action;

    public static void Request(string actionId, string description, int steps, Func<string> action)
    {
        _action = action;
        UiState.Confirm.Begin(actionId, description, steps);
    }

    public static void Confirm(string actionId)
    {
        if (!UiState.Confirm.Confirm(actionId)) return; // нужен следующий шаг или подтверждение устарело
        var action = _action;
        _action = null;
        if (action == null) return;
        try
        {
            UiState.SetStatus(action(), 8f);
        }
        catch (Exception ex)
        {
            UiState.SetStatus("Ошибка: " + ex.Message, 8f);
            UiState.Core?.Log.Error("UI", "Ошибка подтверждённого действия " + actionId, ex);
        }
    }
}
