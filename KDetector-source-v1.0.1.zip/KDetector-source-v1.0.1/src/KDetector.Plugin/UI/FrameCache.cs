using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>
/// Кэш данных для отрисовки. IMGUI вызывает OnGUI несколько раз за кадр (Layout, Repaint, события мыши),
/// и набор элементов между этими вызовами обязан совпадать. Поэтому данные обновляются не чаще одного раза
/// за кадр и не чаще заданного интервала — тяжёлые запросы (фильтры, сортировка, база) не выполняются в каждом OnGUI.
/// </summary>
public sealed class FrameCache<T>
{
    private readonly float _interval;
    private T _value = default!;
    private int _frame = -1;
    private float _next;
    private bool _has;

    public FrameCache(float intervalSeconds)
    {
        _interval = intervalSeconds;
    }

    public void Invalidate() => _next = 0;

    public T Get(Func<T> factory)
    {
        // Решение об обновлении принимается только при ПЕРВОМ обращении в кадре,
        // иначе Layout и Repaint одного кадра могли бы увидеть разные данные.
        var frame = Time.frameCount;
        if (frame == _frame) return _value;
        _frame = frame;
        if (!_has || Time.realtimeSinceStartup >= _next)
        {
            _value = factory();
            _has = true;
            _next = Time.realtimeSinceStartup + _interval;
        }

        return _value;
    }
}
