using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>
/// Единая точка вызовов IMGUI. Используются только перегрузки GUILayout, подтверждённые в IL2CPP-модах
/// для этой версии игры (Label/Button/Box со стилем, Begin/EndVertical/Horizontal, ScrollView, Space, слайдер).
/// Если в будущей версии игры что-то изменится, правка нужна только здесь.
/// </summary>
public static class Gui
{
    private static readonly Color DefaultBg = new(0.16f, 0.16f, 0.19f, 1f);
    private static readonly Color AccentBg = new(0.90f, 0.28f, 0.30f, 1f);
    private static readonly Color SelectedBg = new(0.35f, 0.12f, 0.14f, 1f);
    private static readonly Color DisabledBg = new(0.10f, 0.10f, 0.12f, 1f);

    public static GUILayoutOption W(float px) => GUILayout.Width(Theme.Px(px));
    public static GUILayoutOption H(float px) => GUILayout.Height(Theme.Px(px));
    public static GUILayoutOption ExpandW => GUILayout.ExpandWidth(true);

    public static void Label(string text, GUIStyle? style = null) => GUILayout.Label(text, style ?? Theme.Label);
    public static void Label(string text, GUIStyle style, float width) => GUILayout.Label(text, style, W(width));
    public static void Muted(string text) => GUILayout.Label(Theme.M(text), Theme.Small);
    public static void Title(string text) => GUILayout.Label(Theme.B(text), Theme.Title);
    public static void H2(string text) => GUILayout.Label(text, Theme.H2);

    /// <summary>Кнопка. Недоступная кнопка видна, но не нажимается, а причина показывается в строке статуса.</summary>
    public static bool Button(string text, float width = 0, bool accent = false, bool enabled = true, string? disabledReason = null, bool selected = false)
    {
        var prev = GUI.backgroundColor;
        GUI.backgroundColor = !enabled ? DisabledBg : accent ? AccentBg : selected ? SelectedBg : DefaultBg;
        var label = enabled ? text : Theme.M(text);
        var pressed = width > 0 ? GUILayout.Button(label, Theme.Button, W(width)) : GUILayout.Button(label, Theme.Button);
        GUI.backgroundColor = prev;
        if (!pressed) return false;
        TextInput.Unfocus();
        if (!enabled)
        {
            if (!string.IsNullOrEmpty(disabledReason)) UiState.SetStatus("Недоступно: " + disabledReason);
            return false;
        }

        return true;
    }

    /// <summary>Кнопка с защитой от повторного срабатывания (двойной клик).</summary>
    public static bool GuardedButton(string guardKey, string text, float width = 0, bool accent = false, bool enabled = true, string? disabledReason = null)
        => Button(text, width, accent, enabled, disabledReason) && UiState.Guard.TryEnter(guardKey);

    public static bool Nav(string text, bool selected)
    {
        var prev = GUI.backgroundColor;
        GUI.backgroundColor = selected ? SelectedBg : new Color(0.09f, 0.09f, 0.11f, 1f);
        var pressed = GUILayout.Button(selected ? Theme.C("▍", Theme.Accent) + Theme.B(text) : "  " + text, Theme.NavButton);
        GUI.backgroundColor = prev;
        if (pressed) TextInput.Unfocus();
        return pressed;
    }

    public static bool Cell(string text, float width, bool selected = false)
    {
        var prev = GUI.backgroundColor;
        GUI.backgroundColor = selected ? SelectedBg : new Color(0.10f, 0.10f, 0.12f, 1f);
        var pressed = GUILayout.Button(text, Theme.CellButton, W(width));
        GUI.backgroundColor = prev;
        if (pressed) TextInput.Unfocus();
        return pressed;
    }

    public static void TextCell(string text, float width) => GUILayout.Label(text, Theme.Cell, W(width));

    /// <summary>Переключатель в стиле интерфейса (вместо GUILayout.Toggle со стандартной графикой).</summary>
    public static bool Toggle(bool value, string label, bool enabled = true, string? disabledReason = null, float width = 0)
    {
        var mark = value ? Theme.C("■", Theme.Accent) : Theme.M("□");
        var text = string.IsNullOrEmpty(label) ? mark : $"{mark}  {label}";
        return Button(text, width, false, enabled, disabledReason) ? !value : value;
    }

    public static float Slider(float value, float min, float max, float width)
        => GUILayout.HorizontalSlider(value, min, max, W(width));

    public static void Space(float px) => GUILayout.Space(Theme.Px(px));
    public static void Flex() => GUILayout.FlexibleSpace();

    public static void Separator() => GUILayout.Box(string.Empty, Theme.Separator, GUILayout.Height(1f), GUILayout.ExpandWidth(true));

    public static void BeginRow() => GUILayout.BeginHorizontal();
    public static void EndRow() => GUILayout.EndHorizontal();
    public static void BeginCol() => GUILayout.BeginVertical();
    public static void BeginCol(float width) => GUILayout.BeginVertical(W(width));
    public static void EndCol() => GUILayout.EndVertical();
    public static void BeginPanel() => GUILayout.BeginVertical(Theme.Panel);
    public static void BeginPanel(float width) => GUILayout.BeginVertical(Theme.Panel, W(width));
    public static void BeginPanel2() => GUILayout.BeginVertical(Theme.Panel2);
    public static void EndPanel() => GUILayout.EndVertical();

    public static Vector2 BeginScroll(Vector2 pos) => GUILayout.BeginScrollView(pos, false, true);
    public static void EndScroll() => GUILayout.EndScrollView();

    /// <summary>Пара «подпись: значение» в одну строку.</summary>
    public static void KeyValue(string key, string value, float keyWidth = 190)
    {
        BeginRow();
        GUILayout.Label(Theme.M(key), Theme.Label, W(keyWidth));
        GUILayout.Label(value, Theme.Label);
        EndRow();
    }

    /// <summary>Небольшая плашка-метрика для Dashboard.</summary>
    public static void Metric(string title, string value, float width)
    {
        GUILayout.BeginVertical(Theme.Panel2, W(width));
        GUILayout.Label(Theme.M(title), Theme.Small);
        GUILayout.Label(Theme.B(value), Theme.Title);
        GUILayout.EndVertical();
    }

    /// <summary>Пустое состояние таблицы.</summary>
    public static void Empty(string text)
    {
        Space(16);
        GUILayout.Label(Theme.M(text), Theme.Label);
        Space(16);
    }

    /// <summary>Выбор одного значения из списка кнопками.</summary>
    public static int Choice(int current, string[] options, float width = 0)
    {
        var result = current;
        BeginRow();
        for (var i = 0; i < options.Length; i++)
            if (Button(options[i], width, selected: i == current)) result = i;
        EndRow();
        return result;
    }
}
