namespace KDetector.Plugin.UI;

/// <summary>
/// Префиксы для кнопок интерфейса игры: пока курсор над окном KDetector, клики не проходят «сквозь» окно в игру.
/// Применяются через PatchManager; если методы не найдены — окно работает, но клики могут проходить в игру.
/// </summary>
public static class InputBlockPatch
{
    public static bool Prefix() => !UiState.PointerOverKDetector();
}
