using KDetector.Core.Game;
using KDetector.Core.Logging;
using KDetector.Plugin.Game;
using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>
/// Компонент Unity: горячая клавиша, ввод, периодические тики (контекст игры, игроки), отрисовка IMGUI.
/// Состояние хранится в статических классах (UiState, TextInput), поэтому компонент не держит управляемых полей.
/// Тяжёлая работа не выполняется в OnGUI: таблицы пересчитываются по таймеру внутри страниц.
/// </summary>
public class KDetectorBehaviour : MonoBehaviour
{
    private const float ContextInterval = 0.25f;
    private const float PlayersInterval = 0.5f;

    private static float _nextContext;
    private static float _nextPlayers;
    private static float _nextConfigSave;
    private static KeyCode _hotkey = KeyCode.F8;
    private static string _hotkeyName = string.Empty;

    public void Update()
    {
        var core = UiState.Core;
        if (core == null) return;
        var settings = core.Settings;

        try
        {
            ResolveHotkey(settings.Gui.Hotkey);
            if (!TextInput.HasFocus && !ChatOpen() && Input.GetKeyDown(_hotkey))
            {
                UiState.Visible = !UiState.Visible;
                if (!UiState.Visible) TextInput.Unfocus();
            }

            if (UiState.Visible)
            {
                TextInput.Update();
                UiState.UpdateWindowInteraction((float)settings.Gui.Scale);
            }
        }
        catch (Exception ex)
        {
            core.Log.Throttled("ui-update", 30000, KdLogLevel.Error, "UI", "Ошибка обработки ввода: " + ex.Message);
        }

        var now = Time.realtimeSinceStartup;
        if (now >= _nextContext)
        {
            _nextContext = now + ContextInterval;
            try
            {
                core.UpdateContext(GameStateReader.Read(settings));
            }
            catch (Exception ex)
            {
                core.Log.Throttled("ctx", 30000, KdLogLevel.Error, "Game", "Ошибка чтения состояния игры: " + ex.Message);
            }
        }

        if (now >= _nextPlayers)
        {
            _nextPlayers = now + PlayersInterval;
            try
            {
                if (core.Context.InOnlineLobbyOrGame) core.ObservePlayers(PlayerTracker.Snapshot());
            }
            catch (Exception ex)
            {
                core.Log.Throttled("players", 30000, KdLogLevel.Error, "Players", "Ошибка чтения игроков: " + ex.Message);
            }
        }

        // Сохранение настроек и положения окна — не чаще раза в секунду.
        if (now >= _nextConfigSave)
        {
            _nextConfigSave = now + 1f;
            try
            {
                if (UiState.WindowChanged && settings.Gui.RememberWindow)
                {
                    UiState.WindowChanged = false;
                    settings.Gui.WindowX = Mathf.RoundToInt(UiState.Window.x);
                    settings.Gui.WindowY = Mathf.RoundToInt(UiState.Window.y);
                    settings.Gui.WindowWidth = Mathf.RoundToInt(UiState.Window.width);
                    settings.Gui.WindowHeight = Mathf.RoundToInt(UiState.Window.height);
                    KDetectorPlugin.ConfigDirty = true;
                }

                if (KDetectorPlugin.ConfigDirty)
                {
                    KDetectorPlugin.ConfigDirty = false;
                    KDetectorPlugin.Binder?.PushToConfig();
                }
            }
            catch (Exception ex)
            {
                core.Log.Throttled("cfg-save", 30000, KdLogLevel.Error, "Config", "Ошибка сохранения настроек: " + ex.Message);
            }
        }
    }

    public void OnGUI()
    {
        var core = UiState.Core;
        if (core == null) return;
        try
        {
            MainWindow.OnGUI(core);
        }
        catch (Exception ex)
        {
            core.Log.Throttled("ui-draw", 30000, KdLogLevel.Error, "UI", "Ошибка отрисовки: " + ex.Message);
        }
    }

    public void OnApplicationQuit()
    {
        KDetectorPlugin.Shutdown();
    }

    private static bool ChatOpen()
    {
        try
        {
            return HudManager.InstanceExists && HudManager.Instance.Chat != null && HudManager.Instance.Chat.IsOpenOrOpening;
        }
        catch
        {
            return false;
        }
    }

    private static void ResolveHotkey(string name)
    {
        if (name == _hotkeyName) return;
        _hotkeyName = name;
        if (Enum.TryParse<KeyCode>(name, true, out var key) && key != KeyCode.None)
        {
            _hotkey = key;
            if (Array.IndexOf(GameKeys, key) >= 0)
                UiState.Core?.Diagnostics.AddWarning($"Клавиша {key} используется игрой; выберите другую (например, F8).");
        }
        else
        {
            _hotkey = KeyCode.F8;
            UiState.Core?.Diagnostics.AddWarning($"Клавиша '{name}' не распознана — используется F8.");
        }
    }

    /// <summary>Клавиши стандартного управления Among Us (неполный список, для предупреждения о конфликте).</summary>
    private static readonly KeyCode[] GameKeys =
    {
        KeyCode.W, KeyCode.A, KeyCode.S, KeyCode.D, KeyCode.E, KeyCode.Q, KeyCode.R, KeyCode.Tab, KeyCode.Escape,
        KeyCode.Space, KeyCode.Return, KeyCode.UpArrow, KeyCode.DownArrow, KeyCode.LeftArrow, KeyCode.RightArrow,
        KeyCode.Mouse0, KeyCode.Mouse1,
    };
}
