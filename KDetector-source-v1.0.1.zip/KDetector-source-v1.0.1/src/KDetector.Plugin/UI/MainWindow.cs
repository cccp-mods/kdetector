using KDetector.Core;
using KDetector.Plugin.UI.Pages;
using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>Главное окно: верхняя панель с индикаторами, навигация слева, рабочая область, строка состояния.</summary>
public static class MainWindow
{
    public const int WindowId = 0x4B44;

    private static readonly (Page page, string title)[] NavItems =
    {
        (Page.Dashboard, "Dashboard"),
        (Page.Players, "Live Players"),
        (Page.Detections, "Detections"),
        (Page.Database, "Database"),
        (Page.AutoActions, "Auto Actions"),
        (Page.RpcShield, "RPC Shield"),
        (Page.Rules, "Detection Rules"),
        (Page.Settings, "Settings"),
        (Page.Diagnostics, "Diagnostics"),
        (Page.About, "About"),
    };

    private static KDetectorCore _core = null!;

    public static void OnGUI(KDetectorCore core)
    {
        _core = core;
        var settings = core.Settings;
        Theme.Ensure((float)settings.Gui.Scale);

        if (UiState.Visible)
        {
            UiState.ClampToScreen();
            var prev = GUI.backgroundColor;
            GUI.backgroundColor = new Color(0.04f, 0.04f, 0.05f, 1f);
            GUI.Window(WindowId, UiState.Window, (GUI.WindowFunction)DrawWindow, string.Empty);
            GUI.backgroundColor = prev;
        }

        Toasts.Draw(UiState.Visible, settings.Gui.ToastsWhenClosed);
    }

    private static void DrawWindow(int id)
    {
        try
        {
            GUILayout.BeginVertical(Theme.WindowBg, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            TopBar();
            Gui.Separator();
            GUILayout.BeginHorizontal();
            Navigation();
            GUILayout.BeginVertical(GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            ConfirmBanner();
            DrawPage();
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
            Footer();
            GUILayout.EndVertical();
        }
        catch (Exception ex)
        {
            // Ошибка одной страницы не должна ломать окно: показываем её и даём перейти на другую страницу.
            _core.Log.Throttled("page:" + UiState.Page, 30000, Core.Logging.KdLogLevel.Error, "UI", $"Ошибка страницы {UiState.Page}: {ex.Message}");
            UiState.SetStatus("Ошибка отрисовки страницы — подробности в журнале. Страница сброшена на Dashboard.");
            UiState.Page = Page.Dashboard;
        }
    }

    private static void TopBar()
    {
        var s = _core.Settings;
        var ctx = _core.Context;
        GUILayout.BeginHorizontal(GUILayout.Height(Theme.Px(UiState.TitleBarHeight)));
        Gui.Space(10);
        GUILayout.Label(Theme.B(PluginMetadata.Name), Theme.Small, Gui.W(315));

        var state = !s.General.Enabled ? Theme.M("● выключен")
            : s.General.DryRun ? Theme.C("● Dry Run", Theme.Warn)
            : Theme.C("● активен", Theme.Ok);
        GUILayout.Label(state, Theme.Small, Gui.W(90));

        var session = ctx.InOnlineLobbyOrGame
            ? $"сессия {Theme.B(Theme.Esc(ctx.SessionId))} · {PhaseText(ctx.Phase)}"
            : Theme.M("не в лобби");
        GUILayout.Label(session, Theme.Small, Gui.W(180));

        var host = ctx.LocalIsHost ? Theme.C("хост", Theme.Ok) : Theme.M("не хост");
        GUILayout.Label("полномочия: " + host, Theme.Small, Gui.W(100));
        GUILayout.Label(Theme.M("профиль ") + s.General.Profile, Theme.Small, Gui.W(100));
        Gui.Flex();
        if (Gui.Button("✕", 34)) UiState.Visible = false;
        Gui.Space(6);
        GUILayout.EndHorizontal();
    }

    private static void Navigation()
    {
        GUILayout.BeginVertical(Gui.W(170), GUILayout.ExpandHeight(true));
        Gui.Space(6);
        foreach (var (page, title) in NavItems)
        {
            var label = title;
            if (page == Page.Diagnostics)
            {
                var warnings = _core.Diagnostics.Warnings().Count;
                if (warnings > 0) label += " " + Theme.C($"({warnings})", Theme.Warn);
            }
            else if (page == Page.Dashboard)
            {
                var pending = _core.Actions.ReviewQueue.Count(r => !r.Resolved);
                if (pending > 0) label += " " + Theme.A($"({pending})");
            }

            if (Gui.Nav(label, UiState.Page == page))
            {
                UiState.Page = page;
                UiState.Confirm.Cancel();
            }
        }

        Gui.Flex();
        GUILayout.Label(Theme.M($"  {_core.Settings.Gui.Hotkey} — окно"), Theme.Small);
        GUILayout.Label(Theme.M($"  {_core.Settings.Commands.Prefix} help — команды"), Theme.Small);
        Gui.Space(6);
        GUILayout.EndVertical();
    }

    /// <summary>Баннер подтверждения опасного действия (поверх текущей страницы).</summary>
    private static void ConfirmBanner()
    {
        var pending = UiState.Confirm.PendingAction;
        if (pending == null) return;
        GUILayout.BeginVertical(Theme.Panel);
        var step = UiState.Confirm.Step;
        var total = UiState.Confirm.RequiredSteps;
        GUILayout.Label(Theme.A(Theme.B("Подтвердите действие")) + (total > 1 ? Theme.M($"  (шаг {step + 1} из {total})") : string.Empty), Theme.Label);
        GUILayout.Label(UiState.Confirm.Description, Theme.Label);
        GUILayout.BeginHorizontal();
        if (Gui.Button(total > 1 && step + 1 < total ? "Да, продолжить" : "Да, выполнить", 170, accent: true))
            ConfirmActions.Confirm(pending);
        if (Gui.Button("Отмена", 110)) UiState.Confirm.Cancel();
        GUILayout.EndHorizontal();
        GUILayout.EndVertical();
    }

    private static void DrawPage()
    {
        switch (UiState.Page)
        {
            case Page.Dashboard: DashboardPage.Draw(_core); break;
            case Page.Players: PlayersPage.Draw(_core); break;
            case Page.Detections: DetectionsPage.Draw(_core); break;
            case Page.Database: DatabasePage.Draw(_core); break;
            case Page.AutoActions: AutoActionsPage.Draw(_core); break;
            case Page.RpcShield: RpcShieldPage.Draw(_core); break;
            case Page.Rules: RulesPage.Draw(_core); break;
            case Page.Settings: SettingsPage.Draw(_core); break;
            case Page.Diagnostics: DiagnosticsPage.Draw(_core); break;
            case Page.About: AboutPage.Draw(_core); break;
        }
    }

    private static void Footer()
    {
        Gui.Separator();
        GUILayout.BeginHorizontal(GUILayout.Height(Theme.Px(22)));
        Gui.Space(10);
        var status = Time.realtimeSinceStartup < UiState.StatusUntil ? UiState.Status : string.Empty;
        GUILayout.Label(string.IsNullOrEmpty(status) ? Theme.M($"{PluginMetadata.Name} v{PluginMetadata.Version}") : status, Theme.Small);
        Gui.Flex();
        GUILayout.Label(Theme.M("◢"), Theme.Small, Gui.W(UiState.ResizeGrip));
        GUILayout.EndHorizontal();
    }

    public static string PhaseText(Core.Game.GamePhase p) => p switch
    {
        Core.Game.GamePhase.Lobby => "лобби",
        Core.Game.GamePhase.Intro => "начало матча",
        Core.Game.GamePhase.Tasks => "матч",
        Core.Game.GamePhase.Meeting => "собрание",
        Core.Game.GamePhase.Ended => "конец матча",
        Core.Game.GamePhase.FreePlay => "тренировка",
        Core.Game.GamePhase.NotConnected => "не подключено",
        _ => "—",
    };
}
