using KDetector.Core;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class AboutPage
{
    private static Vector2 _scroll;

    public static void Draw(KDetectorCore core)
    {
        _scroll = Gui.BeginScroll(_scroll);
        Gui.BeginPanel();
        GUILayout.Label(Theme.B(PluginMetadata.Name) + Theme.M("  v" + PluginMetadata.Version), Theme.Title);
        Gui.Label("Клиентский античит-плагин для Among Us на BepInEx 6 (IL2CPP).");
        Gui.Muted(PluginMetadata.Disclaimer);
        Gui.EndPanel();

        Gui.BeginPanel();
        Gui.H2("Что " + PluginMetadata.Name + " может и чего не может");
        Gui.Label("• Наблюдает за сетевыми событиями, которые получает ваш клиент: RPC, данные игроков, платформа, уровень.");
        Gui.Label("• Отменяет обработку недопустимых RPC только на вашем клиенте и только там, где это безопасно.");
        Gui.Label("• Kick/Ban — только когда вы хост; бан действует в текущем лобби. Глобального бана у клиента нет.");
        Gui.Label("• Не видит файлы и память чужих устройств и не «сканирует» игроков: только сетевые признаки.");
        Gui.Label("• Не защищает чужие лобби целиком: другие участники без защиты по-прежнему уязвимы.");
        Gui.Label("• Не проверяет настоящий уровень аккаунта и реальное устройство игрока.");
        Gui.EndPanel();

        Gui.BeginPanel();
        Gui.H2("Лицензии и зависимости");
        Gui.Label(PluginMetadata.Name + " — лицензия MIT (файл LICENSE).");
        Gui.Label("Во время работы используются компоненты, установленные вместе с BepInEx (в плагин не включены):");
        Gui.Muted("BepInEx — LGPL-2.1 · HarmonyX — MIT · Il2CppInterop — LGPL-3.0 · .NET Runtime — MIT.");
        Gui.Label("Исследование: публичное описание возможностей BetterAmongUs (GPL-3.0) и MalumMenu (GPL-3.0).");
        Gui.Muted("Код и графика этих проектов не копировались. Номера RPC в каталоге сигнатур — факты протокола с указанием источника.");
        Gui.Label("Графических ресурсов нет: интерфейс рисуется кодом.");
        Gui.EndPanel();

        Gui.BeginPanel();
        Gui.H2("Данные");
        Gui.Label("Все данные хранятся только локально. Сырой PUID не сохраняется — только усечённый SHA-256. Внешних сетевых запросов нет.");
        Gui.Muted("База: " + Theme.Esc(core.Database.Path));
        Gui.EndPanel();
        Gui.EndScroll();
    }
}
