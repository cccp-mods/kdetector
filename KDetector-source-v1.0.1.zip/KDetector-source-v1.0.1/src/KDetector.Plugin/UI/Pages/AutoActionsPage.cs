using KDetector.Core;
using KDetector.Core.Actions;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class AutoActionsPage
{
    private static Vector2 _scroll;
    private static Vector2 _historyScroll;
    private static bool _dirty;
    private static readonly FrameCache<List<ActionRecord>> HistoryCache = new(0.5f);

    private static readonly string[] ProfileNames = Enum.GetNames(typeof(ActionProfileName));

    public static void Draw(KDetectorCore core)
    {
        var s = core.Settings;
        Gui.BeginPanel();
        Gui.BeginRow();
        Gui.Label(Theme.B("Профиль"), Theme.Label, 90);
        var cur = (int)s.General.Profile;
        var chosen = Gui.Choice(cur, ProfileNames, 110);
        if (chosen != cur) core.UpdateSetting(() => s.General.Profile = (ActionProfileName)chosen);
        Gui.EndRow();
        Gui.Muted(core.Actions.ActivePolicy.Description);

        Gui.BeginRow();
        var dry = Gui.Toggle(s.General.DryRun, "Dry Run — ничего не отменять и не удалять, только журнал");
        if (dry != s.General.DryRun) core.UpdateSetting(() => s.General.DryRun = dry);
        Gui.EndRow();

        Gui.BeginRow();
        var kick = Gui.Toggle(s.AutoActions.AllowAutoKick, "Разрешить автоматический Kick (только когда вы хост)");
        if (kick != s.AutoActions.AllowAutoKick)
        {
            if (kick)
                ConfirmActions.Request("allow-autokick", "Разрешить автоматический Kick? Он сработает только в профиле, где Kick включён (Strict/Custom), только когда вы хост и только при нескольких независимых доказательствах.", 1, () =>
                {
                    core.UpdateSetting(() => s.AutoActions.AllowAutoKick = true);
                    return "Автоматический Kick разрешён.";
                });
            else core.UpdateSetting(() => s.AutoActions.AllowAutoKick = false);
        }

        var ban = Gui.Toggle(s.AutoActions.AllowAutoBan, "Разрешить автоматический Ban");
        if (ban != s.AutoActions.AllowAutoBan)
        {
            if (ban)
                ConfirmActions.Request("allow-autoban", "Разрешить автоматический Ban в лобби? Рекомендуется оставить выключенным: ошибочный бан нельзя отменить из " + global::KDetector.Plugin.PluginMetadata.Name + ".", 2, () =>
                {
                    core.UpdateSetting(() => s.AutoActions.AllowAutoBan = true);
                    return "Автоматический Ban разрешён.";
                });
            else core.UpdateSetting(() => s.AutoActions.AllowAutoBan = false);
        }

        Gui.EndRow();
        if (core.Actions.EnforcementBlockedByCompatibility)
            Gui.Label(Theme.C("Сейчас действует режим «только наблюдение»: " + core.Actions.EnforcementBlockReason, Theme.Warn), Theme.Small);
        Gui.EndPanel();

        var policy = core.Actions.ActivePolicy;
        var editable = s.General.Profile == ActionProfileName.Custom;

        Gui.BeginRow();
        Gui.H2(editable ? "Профиль Custom (редактируемый)" : $"Профиль {policy.Name} (только просмотр)");
        Gui.Flex();
        if (!editable)
        {
            if (Gui.Button($"Скопировать {policy.Name} в Custom и редактировать", 330))
            {
                core.CopyProfileToCustom(s.General.Profile);
                core.UpdateSetting(() => s.General.Profile = ActionProfileName.Custom);
                UiState.SetStatus("Профиль скопирован в Custom");
            }
        }
        else
        {
            if (Gui.Button("Сохранить", 120, accent: _dirty, enabled: _dirty, disabledReason: "изменений нет"))
            {
                core.SaveCustomPolicy();
                _dirty = false;
                UiState.SetStatus("Профиль Custom сохранён в " + s.AutoActions.CustomPolicyFile);
            }

            if (Gui.Button("Сбросить Custom к Balanced…", 230))
                ConfirmActions.Request("reset-custom", "Заменить профиль Custom копией Balanced?", 1, () =>
                {
                    core.CopyProfileToCustom(ActionProfileName.Balanced);
                    _dirty = false;
                    return "Custom сброшен к Balanced.";
                });
        }

        Gui.EndRow();
        Gui.Muted("Условия: мин. уверенность события · мин. число независимых доказательств · мин. риск 0–100 · пауза между повторами (с). Kick/Ban дополнительно требуют разрешения выше и полномочий хоста в момент выполнения.");

        _scroll = GUILayout.BeginScrollView(_scroll, false, true, GUILayout.Height(Theme.Px(270)));
        foreach (var cat in policy.Categories)
        {
            Gui.BeginPanel2();
            Gui.Label(Theme.B(DetectionText.Category(cat.Category)), Theme.Label);
            if (cat.Actions.Count == 0) Gui.Muted("действий нет");
            foreach (var a in cat.Actions) ActionRow(cat.Category, a, editable);
            if (editable)
            {
                Gui.BeginRow();
                foreach (ActionKind kind in Enum.GetValues(typeof(ActionKind)))
                {
                    if (cat.Actions.Any(x => x.Kind == kind)) continue;
                    if (Gui.Button("+ " + kind, 0))
                    {
                        cat.Actions.Add(new ActionRule { Kind = kind, Enabled = false, MinConfidence = 0.5 });
                        _dirty = true;
                    }
                }

                Gui.EndRow();
            }

            Gui.EndPanel();
        }

        GUILayout.EndScrollView();

        Gui.H2("История действий");
        var history = HistoryCache.Get(() => core.Actions.History.Latest(40));
        _historyScroll = GUILayout.BeginScrollView(_historyScroll, false, true, GUILayout.Height(Theme.Px(120)));
        if (history.Count == 0) Gui.Muted("Действий пока не было.");
        foreach (var h in history)
        {
            var color = h.Outcome switch
            {
                ActionOutcome.Executed => Theme.Ok,
                ActionOutcome.DryRun => Theme.Warn,
                ActionOutcome.Failed => Theme.Accent,
                _ => Theme.Muted,
            };
            Gui.Label($"{Theme.M(h.Utc.ToLocalTime().ToString("HH:mm:ss"))} {Theme.C(h.Outcome.ToString(), color)} {h.Kind} {Theme.B(Theme.Esc(h.PlayerName))} {Theme.M((h.Automatic ? "авто" : "вручную") + " · " + Theme.Esc(h.Reason))}", Theme.Small);
        }

        GUILayout.EndScrollView();
    }

    private static void ActionRow(DetectionCategory category, ActionRule a, bool editable)
    {
        Gui.BeginRow();
        var en = a.Enabled ? Theme.C("■", Theme.Accent) : Theme.M("□");
        if (editable)
        {
            if (Gui.Button($"{en} {a.Kind}", 200))
            {
                a.Enabled = !a.Enabled;
                _dirty = true;
            }

            a.MinConfidence = Step("уверн.", a.MinConfidence, 0.05, 0, 1, v => a.MinConfidence = v);
            a.MinIndependentEvidence = (int)Step("незав.", a.MinIndependentEvidence, 1, 1, 10, v => a.MinIndependentEvidence = (int)v);
            a.MinRiskScore = (int)Step("риск", a.MinRiskScore, 5, 0, 100, v => a.MinRiskScore = (int)v);
            a.CooldownSeconds = (int)Step("пауза", a.CooldownSeconds, 10, 0, 3600, v => a.CooldownSeconds = (int)v);
            var conf = Gui.Toggle(a.RequireConfirmedViolation, "нужно подтв. нарушение");
            if (conf != a.RequireConfirmedViolation)
            {
                a.RequireConfirmedViolation = conf;
                _dirty = true;
            }
        }
        else
        {
            Gui.Label($"{en} {Theme.B(a.Kind.ToString())}", Theme.Label, 200);
            Gui.Label(Theme.M($"уверенность ≥ {a.MinConfidence:0.00} · независимых ≥ {a.MinIndependentEvidence} · риск ≥ {a.MinRiskScore} · пауза {a.CooldownSeconds} с"
                              + (a.RequireConfirmedViolation ? " · только при подтверждённом нарушении" : "")
                              + (a.EvidenceKinds.Count > 0 ? " · виды: " + string.Join(", ", a.EvidenceKinds) : "")), Theme.Small);
        }

        Gui.EndRow();
    }

    private static double Step(string label, double value, double step, double min, double max, Action<double> set)
    {
        Gui.Label(Theme.M(label), Theme.Small, 46);
        if (Gui.Button("−", 26))
        {
            value = Math.Max(min, Math.Round(value - step, 2));
            set(value);
            _dirty = true;
        }

        Gui.Label(step < 1 ? value.ToString("0.00") : value.ToString("0"), Theme.Label, 40);
        if (Gui.Button("+", 26))
        {
            value = Math.Min(max, Math.Round(value + step, 2));
            set(value);
            _dirty = true;
        }

        return value;
    }
}
