using KDetector.Core;
using KDetector.Core.Actions;
using KDetector.Core.Detection;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class DashboardPage
{
    private static Vector2 _scroll;
    private static readonly FrameCache<List<DetectionEvent>> Recent = new(0.5f);
    private static readonly FrameCache<List<ReviewItem>> Reviews = new(0.5f);

    public static void Draw(KDetectorCore core)
    {
        var s = core.Settings;
        var ctx = core.Context;
        _scroll = Gui.BeginScroll(_scroll);

        Gui.BeginRow();
        Gui.Metric("Состояние", !s.General.Enabled ? "выключен" : s.General.DryRun ? "Dry Run" : "активен", 140);
        Gui.Metric("Игроков", core.Players.Count.ToString(), 110);
        Gui.Metric("Событий за сессию", core.Engine.SessionEventCount.ToString(), 150);
        Gui.Metric("RPC проверено / отменено", $"{core.Inspector.Inspected} / {core.Inspector.Cancelled}", 200);
        Gui.Metric("Записей в базе", core.Database.Count.ToString(), 130);
        Gui.EndRow();

        Gui.BeginRow();
        Gui.BeginPanel(360);
        Gui.H2("Сессия");
        Gui.KeyValue("Фаза", MainWindow.PhaseText(ctx.Phase), 150);
        Gui.KeyValue("Код комнаты", string.IsNullOrEmpty(ctx.SessionId) ? "—" : Theme.Esc(ctx.SessionId), 150);
        Gui.KeyValue("Сервер", ctx.OnOfficialServer ? "официальный" : Theme.C(string.IsNullOrEmpty(ctx.RegionName) ? "—" : Theme.Esc(ctx.RegionName) + " (не официальный)", Theme.Warn), 150);
        Gui.KeyValue("Протокол", ctx.ModdedProtocol ? Theme.C("модифицированный", Theme.Warn) : "обычный", 150);
        Gui.KeyValue("Версия игры", string.IsNullOrEmpty(ctx.GameVersion) ? "—" : ctx.GameVersion + (ctx.VersionSupported ? "" : Theme.C("  не поддерживается", Theme.Warn)), 150);
        Gui.KeyValue("Полномочия хоста", ctx.LocalIsHost ? Theme.C("есть", Theme.Ok) : Theme.M("нет — Kick/Ban недоступны"), 150);
        Gui.EndPanel();

        Gui.BeginPanel();
        Gui.H2("Защита");
        Gui.KeyValue("Профиль", $"{s.General.Profile} — {Theme.M(core.Actions.ActivePolicy.Description)}", 150);
        Gui.KeyValue("RPC Shield", !s.RpcShield.Enabled ? Theme.M("выключен") : s.RpcShield.DryRun ? Theme.C("Dry Run", Theme.Warn) : Theme.C("активен", Theme.Ok), 150);
        Gui.KeyValue("Автокик / автобан", $"{(s.AutoActions.AllowAutoKick ? Theme.A("разрешён") : "выкл")} / {(s.AutoActions.AllowAutoBan ? Theme.A("разрешён") : "выкл")}", 150);
        var blocked = core.Actions.EnforcementBlockedByCompatibility ? Theme.C("только наблюдение: " + core.Actions.EnforcementBlockReason, Theme.Warn) : "нет";
        Gui.KeyValue("Ограничение совместимости", blocked, 150);
        var protoSuspended = core.Protocol.SuspendedReason(ctx);
        Gui.KeyValue("Проверка действий", protoSuspended == null ? "активна" : Theme.M("приостановлена: " + protoSuspended), 150);
        var warnings = core.Diagnostics.Warnings().Count;
        if (warnings > 0)
        {
            Gui.KeyValue("Предупреждения", Theme.C(warnings.ToString(), Theme.Warn), 150);
            if (Gui.Button("Открыть Diagnostics", 180)) UiState.Page = Page.Diagnostics;
        }

        Gui.EndPanel();
        Gui.EndRow();

        // Очередь ручного рассмотрения.
        var reviews = Reviews.Get(() => core.Actions.ReviewQueue.Where(r => !r.Resolved).OrderByDescending(r => r.RiskScore).Take(6).ToList());
        if (reviews.Count > 0)
        {
            Gui.BeginPanel();
            Gui.H2(Theme.A("Требует рассмотрения"));
            foreach (var r in reviews)
            {
                Gui.BeginRow();
                Gui.Label($"{Theme.B(Theme.Esc(r.Player.Display))}  {Theme.C($"риск {r.RiskScore}", Theme.Accent)}  {Theme.M(Theme.Esc(r.Reason))}", Theme.Label, 520);
                Gui.Flex();
                if (Gui.Button("Карточка", 100))
                {
                    UiState.SelectedClientId = r.Player.ClientId;
                    UiState.Page = Page.Players;
                }

                var canKick = ctx.LocalIsHost && core.Players.Get(r.Player.ClientId) != null;
                if (Gui.GuardedButton("kick:" + r.Player.ClientId, "Kick", 70, accent: true, enabled: canKick,
                        disabledReason: ctx.LocalIsHost ? "игрок уже покинул лобби" : "вы не хост"))
                {
                    var ok = core.Actions.TryHostAction(r.Player, false, false, "review", "ручное рассмотрение", out var err);
                    UiState.SetStatus(ok ? $"Kick: {r.Player.Display}" : "Kick не выполнен: " + err);
                    if (ok) core.Actions.ResolveReview(r.Id);
                }

                if (Gui.Button("Решено", 90))
                {
                    core.Actions.ResolveReview(r.Id);
                    Reviews.Invalidate();
                }

                Gui.EndRow();
            }

            Gui.EndPanel();
        }

        Gui.BeginPanel();
        Gui.BeginRow();
        Gui.H2("Последние события");
        Gui.Flex();
        if (Gui.Button("Все события", 130)) UiState.Page = Page.Detections;
        Gui.EndRow();
        var recent = Recent.Get(() => core.Engine.Feed.Latest(8));
        if (recent.Count == 0) Gui.Empty("Событий пока нет. Это нормально: " + global::KDetector.Plugin.PluginMetadata.Name + " не помечает игроков без оснований.");
        foreach (var e in recent) DetectionsPage.Row(e, compact: true);
        Gui.EndPanel();

        Gui.EndScroll();
    }
}
