using KDetector.Core;
using KDetector.Core.Database;
using KDetector.Core.Detection;
using KDetector.Core.UiModel;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class DatabasePage
{
    private enum View
    {
        Records,
        Backups,
        Import,
    }

    private static View _view = View.Records;
    private static Vector2 _scroll;
    private static Vector2 _detailScroll;
    private static int _page;
    private const int PageSize = 25;
    private static readonly RecordQuery Query = new();
    private static readonly FrameCache<List<DetectionRecord>> Results = new(0.5f);
    private static readonly FrameCache<DatabaseHealth> Health = new(2f);
    private static long _seenVersion = -1;
    private static string _lastText = string.Empty;

    private static readonly string[] CategoryNames =
        new[] { "Все" }.Concat(Enum.GetValues(typeof(DetectionCategory)).Cast<DetectionCategory>().Select(DetectionText.Category)).ToArray();

    private static readonly string[] RiskNames = { "Любой", "None", "Low", "Medium", "High", "Critical" };
    private static readonly string[] StatusNames = { "Любой", "New", "UnderReview", "Confirmed", "Cleared", "Ignored" };

    private static readonly (RecordSort sort, string title)[] Sorts =
    {
        (RecordSort.LastSeenDesc, "Новые"), (RecordSort.LastSeenAsc, "Старые"), (RecordSort.EventCountDesc, "Больше событий"),
        (RecordSort.EventCountAsc, "Меньше событий"), (RecordSort.RiskDesc, "Риск"), (RecordSort.NameAsc, "Имя"),
    };

    public static void Draw(KDetectorCore core)
    {
        var db = core.Database;
        if (db.Version != _seenVersion)
        {
            _seenVersion = db.Version;
            Results.Invalidate();
            Health.Invalidate();
        }

        Gui.BeginRow();
        if (Gui.Button("Записи", 110, selected: _view == View.Records)) _view = View.Records;
        if (Gui.Button("Резервные копии", 160, selected: _view == View.Backups)) _view = View.Backups;
        if (Gui.Button("Импорт", 110, selected: _view == View.Import)) _view = View.Import;
        Gui.Flex();
        if (Gui.GuardedButton("db-export-all", "Экспорт всего", 140))
        {
            var path = core.ExportDatabase(null);
            UiState.SetStatus(path != null ? "Экспорт: " + path : "Экспорт не удался — см. журнал", 10f);
        }

        if (Gui.GuardedButton("db-backup", "Резервная копия", 150))
        {
            var path = db.Backup();
            Health.Invalidate();
            UiState.SetStatus(path != null ? "Копия: " + Path.GetFileName(path) : "Копия не создана (база ещё не записана на диск или ошибка)", 8f);
        }

        Gui.EndRow();

        HealthPanel(core);

        switch (_view)
        {
            case View.Backups:
                Backups(core);
                return;
            case View.Import:
                Import(core);
                return;
        }

        Filters();
        var results = Results.Get(() => db.Query(Query));
        var pageItems = Paging.Page(results, _page, PageSize, out var pages);
        _page = Math.Min(_page, pages - 1);

        // Массовые действия.
        Gui.BeginRow();
        Gui.Label(Theme.M($"Найдено: {results.Count}. Выбрано: {UiState.CheckedRecords.Count}"), Theme.Small, 240);
        if (Gui.Button("Выбрать страницу", 160))
            foreach (var r in pageItems) UiState.CheckedRecords.Add(r.RecordId);
        if (Gui.Button("Снять выбор", 130)) UiState.CheckedRecords.Clear();
        var selected = UiState.CheckedRecords.ToList();
        if (Gui.Button("Экспорт выбранных", 170, enabled: selected.Count > 0, disabledReason: "ничего не выбрано"))
        {
            var path = core.ExportDatabase(selected);
            UiState.SetStatus(path != null ? "Экспорт: " + path : "Экспорт не удался", 10f);
        }

        if (Gui.Button($"Удалить выбранные ({selected.Count})…", 210, accent: true, enabled: selected.Count > 0, disabledReason: "ничего не выбрано"))
            ConfirmActions.Request("delete-selected", $"Удалить выбранные записи: {selected.Count}? Перед удалением будет создана резервная копия.", 1, () =>
            {
                var n = db.Delete(selected);
                UiState.CheckedRecords.Clear();
                UiState.SelectedRecordId = null;
                return $"Удалено записей: {n}.";
            });

        Gui.Flex();
        if (Gui.Button("Удалить всё…", 140, accent: true, enabled: db.Count > 0, disabledReason: "база пуста"))
        {
            var count = db.Count;
            ConfirmActions.Request("delete-all", $"Удалить ВСЕ записи базы ({count})? Это действие требует двух подтверждений. Перед удалением будет создана резервная копия, из которой базу можно восстановить.", 2, () =>
            {
                var n = db.DeleteAll();
                UiState.CheckedRecords.Clear();
                UiState.SelectedRecordId = null;
                return $"Удалено записей: {n}. Восстановление — вкладка «Резервные копии».";
            });
        }

        Gui.EndRow();

        var hasDetail = UiState.SelectedRecordId != null && db.Get(UiState.SelectedRecordId) != null;
        _scroll = GUILayout.BeginScrollView(_scroll, false, true, GUILayout.Height(Theme.Px(hasDetail ? 170 : 300)));
        if (results.Count == 0) Gui.Empty(db.Count == 0 ? "База пуста. Записи появляются, когда правило регистрирует событие у игрока с Friend Code или PUID." : "Нет записей, подходящих под фильтр.");
        foreach (var r in pageItems)
        {
            Gui.BeginRow();
            var check = UiState.CheckedRecords.Contains(r.RecordId);
            if (Gui.Cell(check ? Theme.A("■") : Theme.M("□"), 34))
            {
                if (check) UiState.CheckedRecords.Remove(r.RecordId);
                else UiState.CheckedRecords.Add(r.RecordId);
            }

            var isSel = UiState.SelectedRecordId == r.RecordId;
            var flags = (r.WhitelistStatus == WhitelistStatus.Whitelisted ? Theme.C(" WL", Theme.Ok) : "") + (r.Watchlist ? Theme.A(" watch") : "");
            if (Gui.Cell(Theme.B(Theme.Esc(r.PlayerName)) + flags, 220, isSel) |
                Gui.Cell(Theme.Esc(string.IsNullOrEmpty(r.FriendCode) ? "—" : r.FriendCode), 150, isSel) |
                Gui.Cell(r.EventCount.ToString(), 60, isSel) |
                Gui.Cell(string.IsNullOrEmpty(r.RiskLevel) ? "—" : $"{r.RiskScore} {r.RiskLevel}", 110, isSel) |
                Gui.Cell(r.ReviewStatus.ToString(), 100, isSel) |
                Gui.Cell(r.LastSeenUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm"), 130, isSel))
            {
                UiState.SelectedRecordId = isSel ? null : r.RecordId;
            }

            Gui.EndRow();
        }

        GUILayout.EndScrollView();

        Gui.BeginRow();
        if (Gui.Button("‹", 34, enabled: _page > 0)) _page--;
        Gui.Label(Theme.M($"стр. {_page + 1} из {pages}"), Theme.Small, 110);
        if (Gui.Button("›", 34, enabled: _page < pages - 1)) _page++;
        Gui.EndRow();

        if (hasDetail) Detail(core, db.Get(UiState.SelectedRecordId!)!);
    }

    private static void Filters()
    {
        Gui.BeginRow();
        var text = TextInput.Field("db.search", "Поиск: имя, Friend Code, HashPuid, RecordId", 340, 80);
        if (text != _lastText)
        {
            _lastText = text;
            Query.Text = text;
            _page = 0;
            Results.Invalidate();
        }

        var sortIndex = Array.FindIndex(Sorts, s => s.sort == Query.Sort);
        var chosenSort = Gui.Choice(sortIndex, Sorts.Select(s => s.title).ToArray());
        if (chosenSort != sortIndex)
        {
            Query.Sort = Sorts[chosenSort].sort;
            Results.Invalidate();
        }

        Gui.EndRow();

        var cat = Query.Category.HasValue ? (int)Query.Category.Value + 1 : 0;
        var c = Gui.Choice(cat, CategoryNames);
        if (c != cat)
        {
            Query.Category = c == 0 ? null : (DetectionCategory)(c - 1);
            _page = 0;
            Results.Invalidate();
        }

        Gui.BeginRow();
        Gui.Label(Theme.M("Риск:"), Theme.Small, 50);
        var risk = Query.RiskLevel == null ? 0 : Array.IndexOf(RiskNames, Query.RiskLevel);
        var nr = Gui.Choice(risk, RiskNames);
        if (nr != risk)
        {
            Query.RiskLevel = nr == 0 ? null : RiskNames[nr];
            _page = 0;
            Results.Invalidate();
        }

        Gui.Label(Theme.M("Статус:"), Theme.Small, 60);
        var st = Query.Status.HasValue ? (int)Query.Status.Value + 1 : 0;
        var ns = Gui.Choice(st, StatusNames);
        if (ns != st)
        {
            Query.Status = ns == 0 ? null : (ReviewStatus)(ns - 1);
            _page = 0;
            Results.Invalidate();
        }

        Gui.EndRow();
    }

    private static void HealthPanel(KDetectorCore core)
    {
        var h = Health.Get(() => core.Database.Health());
        Gui.BeginPanel2();
        Gui.BeginRow();
        Gui.Label($"{Theme.M("Файл:")} {Theme.Esc(h.Path)}", Theme.Small);
        Gui.Flex();
        if (Gui.Button("Копировать путь", 140))
        {
            GUIUtility.systemCopyBuffer = h.Path;
            UiState.SetStatus("Путь скопирован");
        }

        Gui.EndRow();
        var saved = h.LastSavedUtc?.ToLocalTime().ToString("HH:mm:ss") ?? "—";
        var backup = h.LastBackupUtc?.ToLocalTime().ToString("yyyy-MM-dd HH:mm") ?? "нет";
        var state = !h.Loaded ? Theme.A("НЕ ЗАГРУЖЕНА — запись отключена, чтобы не повредить файл") : h.Dirty ? Theme.C("есть несохранённые изменения", Theme.Warn) : Theme.C("сохранено", Theme.Ok);
        Gui.Label($"{Theme.M("Записей:")} {h.Records}   {Theme.M("Размер:")} {h.FileSizeBytes / 1024.0:0.0} КБ   {Theme.M("Сохранено:")} {saved}   {Theme.M("Последняя копия:")} {backup} ({h.BackupCount})   {state}", Theme.Small);
        if (h.LastError != null) Gui.Label(Theme.A(Theme.Esc(h.LastError)), Theme.Small);
        foreach (var w in h.Warnings.Take(3)) Gui.Label(Theme.C(Theme.Esc(w), Theme.Warn), Theme.Small);
        Gui.EndPanel();
    }

    private static void Detail(KDetectorCore core, DetectionRecord r)
    {
        Gui.BeginPanel();
        Gui.BeginRow();
        Gui.Title(Theme.Esc(r.PlayerName));
        Gui.Label(Theme.M("  RecordId " + r.RecordId), Theme.Small, 330);
        Gui.Flex();
        if (Gui.Button("Закрыть", 90)) UiState.SelectedRecordId = null;
        Gui.EndRow();

        _detailScroll = GUILayout.BeginScrollView(_detailScroll, false, true, GUILayout.Height(Theme.Px(170)));
        Gui.BeginRow();
        Gui.BeginCol(380);
        Gui.KeyValue("Friend Code", string.IsNullOrEmpty(r.FriendCode) ? "—" : Theme.Esc(r.FriendCode), 140);
        Gui.KeyValue("HashPuid", string.IsNullOrEmpty(r.HashPuid) ? "—" : r.HashPuid, 140);
        Gui.KeyValue("Прежние имена", r.PreviousNames.Count == 0 ? "—" : Theme.Esc(string.Join(", ", r.PreviousNames)), 140);
        Gui.KeyValue("Платформа / уровень", $"{Theme.Esc(r.Platform)} / {r.Level}", 140);
        Gui.KeyValue("Впервые / последний раз", $"{r.FirstSeenUtc.ToLocalTime():yyyy-MM-dd HH:mm} / {r.LastSeenUtc.ToLocalTime():yyyy-MM-dd HH:mm}", 140);
        Gui.KeyValue("Правила", string.Join(", ", r.RuleIds), 140);
        Gui.KeyValue("Макс. уверенность / риск", $"{r.Confidence:0.00} / {r.RiskScore} {r.RiskLevel}", 140);
        Gui.EndCol();
        Gui.BeginCol();
        Gui.H2("Действия по игроку");
        if (r.ActionHistory.Count == 0) Gui.Muted("нет");
        foreach (var a in r.ActionHistory.AsEnumerable().Reverse().Take(6))
            Gui.Muted($"{a.Utc.ToLocalTime():MM-dd HH:mm} {a.Action}: {a.Outcome} — {Theme.Esc(a.Reason)}");
        Gui.EndCol();
        Gui.EndRow();

        Gui.H2($"История обнаружений ({r.DetectionEvents.Count})");
        foreach (var e in r.DetectionEvents.AsEnumerable().Reverse().Take(30))
            Gui.Label($"{Theme.C("▍", Theme.SeverityHex(e.Severity))} {Theme.M(e.Utc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss"))}  {Theme.Esc(e.Summary)} {Theme.M($"[{e.RuleId}, {e.Confidence:0.00}]")}", Theme.Small);
        GUILayout.EndScrollView();

        // Заметка
        Gui.BeginRow();
        TextInput.Bind("db.note." + r.RecordId, r.Notes);
        var note = TextInput.Field("db.note." + r.RecordId, "Заметка", 520, 2000);
        if (Gui.Button("Сохранить заметку", 170, enabled: note != r.Notes, disabledReason: "заметка не изменена"))
        {
            core.Database.SetNote(r.RecordId, note);
            UiState.SetStatus("Заметка сохранена");
        }

        Gui.EndRow();

        Gui.BeginRow();
        Gui.Label(Theme.M("Статус:"), Theme.Small, 60);
        var names = Enum.GetNames(typeof(ReviewStatus));
        var cur = (int)r.ReviewStatus;
        var chosen = Gui.Choice(cur, names);
        if (chosen != cur) core.Database.SetReviewStatus(r.RecordId, (ReviewStatus)chosen);
        Gui.EndRow();

        Gui.BeginRow();
        if (Gui.Button("Отметить проверенным (нарушений нет)", 300)) core.Database.SetReviewStatus(r.RecordId, ReviewStatus.Cleared);
        var wl = r.WhitelistStatus == WhitelistStatus.Whitelisted;
        if (Gui.Button(wl ? "Убрать из whitelist" : "В whitelist", 170)) core.Database.SetWhitelist(r.RecordId, !wl);
        if (Gui.Button(r.Watchlist ? "Убрать из watchlist" : "В watchlist", 170)) core.Database.SetWatchlist(r.RecordId, !r.Watchlist);
        Gui.Flex();
        if (Gui.Button("Удалить запись…", 160, accent: true))
        {
            var id = r.RecordId;
            var name = r.PlayerName;
            ConfirmActions.Request("delete-one", $"Удалить запись игрока {Theme.Esc(name)}?", 1, () =>
            {
                var n = core.Database.Delete(new[] { id });
                UiState.SelectedRecordId = null;
                return n > 0 ? "Запись удалена." : "Запись не найдена.";
            });
        }

        Gui.EndRow();
        Gui.EndPanel();
    }

    private static Vector2 _backupScroll;
    private static readonly FrameCache<List<FileInfo>> BackupList = new(2f);
    private static readonly FrameCache<List<FileInfo>> ImportList = new(2f);

    private static void Backups(KDetectorCore core)
    {
        var list = BackupList.Get(() => core.Database.Backups());
        Gui.BeginPanel();
        Gui.H2("Резервные копии");
        Gui.Muted($"Папка: {Theme.Esc(Path.GetDirectoryName(core.Database.Path) ?? string.Empty)}{Path.DirectorySeparatorChar}{KdDatabase.BackupFolderName}. Хранится не больше {core.Settings.Database.MaxBackups} копий.");
        _backupScroll = GUILayout.BeginScrollView(_backupScroll, false, true, GUILayout.Height(Theme.Px(300)));
        if (list.Count == 0) Gui.Empty("Копий пока нет.");
        foreach (var f in list)
        {
            Gui.BeginRow();
            Gui.Label($"{Theme.Esc(f.Name)}  {Theme.M($"{f.LastWriteTime:yyyy-MM-dd HH:mm} · {f.Length / 1024.0:0.0} КБ")}", Theme.Label, 560);
            if (Gui.Button("Восстановить…", 150, accent: true))
            {
                var path = f.FullName;
                ConfirmActions.Request("restore", $"Восстановить базу из {Theme.Esc(f.Name)}? Текущая база будет сохранена в отдельную копию перед заменой.", 2, () =>
                {
                    var report = core.Database.Restore(path);
                    return $"Восстановлено записей: {report.Loaded}" + (report.Corrupt > 0 ? $", повреждённых строк: {report.Corrupt}" : "") + ".";
                });
            }

            Gui.EndRow();
        }

        GUILayout.EndScrollView();

        Gui.Separator();
        Gui.H2("Очистка");
        var s = core.Settings.Database;
        Gui.Muted($"Автоочистка: {(s.AutoCleanup ? "включена" : "выключена")}. Срок хранения {s.RetentionDays} дн., максимум {s.MaxRecords} записей. " +
                  $"Сохраняются: {(s.KeepReviewed ? "рассмотренные " : "")}{(s.KeepWhitelisted ? "whitelist " : "")}{(s.KeepActionHistory ? "с историей действий" : "")}. Параметры — на странице Settings → Database.");
        Gui.BeginRow();
        if (Gui.Button("Очистить по правилам сейчас…", 260))
            ConfirmActions.Request("cleanup", $"Удалить записи старше {s.RetentionDays} дн. и сверх лимита {s.MaxRecords} с учётом исключений? Перед очисткой создаётся резервная копия.", 1, () =>
            {
                var (records, events) = core.Database.Cleanup(manual: true);
                return $"Удалено записей: {records}, событий: {events}.";
            });
        if (Gui.Button("Очистить статистику сессии…", 260))
            ConfirmActions.Request("clear-stats", "Очистить ленту событий, счётчики RPC Shield и статистику правил? База не изменится.", 1, () =>
            {
                core.ClearSessionStatistics();
                return "Статистика сессии очищена.";
            });
        Gui.EndRow();
        Gui.EndPanel();
    }

    private static Vector2 _importScroll;

    private static void Import(KDetectorCore core)
    {
        Gui.BeginPanel();
        Gui.H2("Импорт записей");
        Gui.Muted($"Положите файл .jsonl (экспорт {PluginMetadata.Name}) в папку {Theme.Esc(core.Paths.ExportsDirectory)}. Записи одного игрока объединяются, события не дублируются. Перед импортом создаётся резервная копия.");
        var files = ImportList.Get(() => SafeFiles(core.Paths.ExportsDirectory));
        _importScroll = GUILayout.BeginScrollView(_importScroll, false, true, GUILayout.Height(Theme.Px(300)));
        if (files.Count == 0) Gui.Empty("Файлов .jsonl / .kh / .kd в папке нет.");
        foreach (var f in files)
        {
            Gui.BeginRow();
            Gui.Label($"{Theme.Esc(f.Name)}  {Theme.M($"{f.LastWriteTime:yyyy-MM-dd HH:mm} · {f.Length / 1024.0:0.0} КБ")}", Theme.Label, 560);
            if (Gui.Button("Импортировать…", 150))
            {
                var path = f.FullName;
                ConfirmActions.Request("import", $"Импортировать записи из {Theme.Esc(f.Name)}?", 1, () =>
                {
                    var r = core.Database.Import(path);
                    return $"Импорт: добавлено {r.Added}, объединено {r.Merged}, пропущено {r.Skipped}" + (r.Corrupt > 0 ? $", повреждённых строк {r.Corrupt}" : "") + ".";
                });
            }

            Gui.EndRow();
        }

        GUILayout.EndScrollView();
        Gui.EndPanel();
    }

    private static List<FileInfo> SafeFiles(string dir)
    {
        try
        {
            if (!Directory.Exists(dir)) return new List<FileInfo>();
            return new DirectoryInfo(dir).GetFiles()
                .Where(f => f.Extension is ".jsonl" or ".kh" or ".kd")
                .OrderByDescending(f => f.LastWriteTimeUtc).Take(50).ToList();
        }
        catch
        {
            return new List<FileInfo>();
        }
    }
}
