using KDetector.Core;
using KDetector.Core.Detection;
using KDetector.Core.UiModel;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class DetectionsPage
{
    private static Vector2 _scroll;
    private static readonly DetectionFilter Filter = new();
    private static readonly FrameCache<List<DetectionEvent>> Items = new(0.5f);
    private static string _lastText = string.Empty;
    private static Guid? _expanded;

    private static readonly string[] CategoryNames =
        new[] { "Все" }.Concat(Enum.GetValues(typeof(DetectionCategory)).Cast<DetectionCategory>().Select(DetectionText.Category)).ToArray();

    private static readonly string[] SeverityNames = { "Инфо+", "Низкая+", "Средняя+", "Высокая+", "Критич." };

    public static void Draw(KDetectorCore core)
    {
        Gui.BeginRow();
        var text = TextInput.Field("det.filter", "Поиск: игрок, правило, описание", 300);
        if (text != _lastText)
        {
            _lastText = text;
            Filter.Text = text;
            Items.Invalidate();
        }

        var hide = Gui.Toggle(Filter.HideWhitelisted, "скрыть whitelist");
        if (hide != Filter.HideWhitelisted)
        {
            Filter.HideWhitelisted = hide;
            Items.Invalidate();
        }

        Gui.Flex();
        if (Gui.Button("Очистить ленту…", 150))
            ConfirmActions.Request("clear-feed", "Очистить ленту событий и статистику сессии? База данных не изменится.", 1, () =>
            {
                core.ClearSessionStatistics();
                Items.Invalidate();
                return "Лента и статистика сессии очищены.";
            });
        Gui.EndRow();

        var catIndex = Filter.Category.HasValue ? (int)Filter.Category.Value + 1 : 0;
        var chosenCat = Gui.Choice(catIndex, CategoryNames);
        if (chosenCat != catIndex)
        {
            Filter.Category = chosenCat == 0 ? null : (DetectionCategory)(chosenCat - 1);
            Items.Invalidate();
        }

        var sevIndex = (int)Filter.MinSeverity;
        var chosenSev = Gui.Choice(sevIndex, SeverityNames, 100);
        if (chosenSev != sevIndex)
        {
            Filter.MinSeverity = (Severity)chosenSev;
            Items.Invalidate();
        }

        var items = Items.Get(() => Filter.Apply(core.Engine.Feed.Snapshot()).Take(300).ToList());
        Gui.Muted($"Показано: {items.Count} из {core.Engine.Feed.Count} (в памяти хранится не более {core.Engine.Feed.Capacity}). Нажмите на событие, чтобы увидеть факты.");

        _scroll = Gui.BeginScroll(_scroll);
        if (items.Count == 0) Gui.Empty("Событий нет.");
        foreach (var e in items)
        {
            if (Row(e, compact: false)) _expanded = _expanded == e.Id ? null : e.Id;
            if (_expanded == e.Id) Details(core, e);
        }

        Gui.EndScroll();
    }

    /// <summary>Строка события. Возвращает true при нажатии.</summary>
    public static bool Row(DetectionEvent e, bool compact)
    {
        var time = e.TimestampUtc.ToLocalTime().ToString("HH:mm:ss");
        var sev = Theme.C("▍", Theme.SeverityHex(e.Severity));
        var who = Theme.B(Theme.Esc(e.Player.Display));
        var tag = e.Whitelisted ? Theme.C(" whitelist", Theme.Ok) : e.DryRun ? Theme.C(" dry-run", Theme.Warn) : string.Empty;
        var text = compact
            ? $"{sev} {Theme.M(time)}  {who}  {Theme.Esc(e.Summary)}{tag}"
            : $"{sev} {Theme.M(time)}  {who}  {Theme.M(DetectionText.Category(e.Category))} · {DetectionText.Evidence(e.Evidence)} · {e.Confidence:0.00}{tag}\n      {Theme.Esc(e.Summary)}";
        return Gui.Cell(text, compact ? 760 : 780);
    }

    private static void Details(KDetectorCore core, DetectionEvent e)
    {
        Gui.BeginPanel2();
        Gui.KeyValue("Правило", $"{Theme.Esc(e.RuleName)} {Theme.M($"({e.RuleId} v{e.RuleVersion})")}", 160);
        Gui.KeyValue("Вид доказательства", DetectionText.Evidence(e.Evidence), 160);
        Gui.KeyValue("Серьёзность / уверенность", $"{DetectionText.Severity(e.Severity)} / {e.Confidence:0.00}", 160);
        Gui.KeyValue("Наблюдений в событии", e.ObservationCount.ToString(), 160);
        Gui.KeyValue("Рекомендация", string.IsNullOrEmpty(e.RecommendedAction) ? "—" : e.RecommendedAction, 160);
        Gui.H2("Факты");
        foreach (var f in e.Facts) Gui.Label($"{Theme.M(Theme.Esc(f.Name))}: {Theme.Esc(f.Value)} {Theme.M("[" + Theme.Esc(f.Source) + "]")}", Theme.Small);
        if (!string.IsNullOrEmpty(e.Hypothesis))
        {
            Gui.H2("Гипотеза (не факт)");
            Gui.Muted(Theme.Esc(e.Hypothesis));
        }

        Gui.BeginRow();
        if (Gui.Button("Отключить правило на 30 мин", 240))
        {
            core.Registry.DisableTemporarily(e.RuleId, TimeSpan.FromMinutes(30), DateTime.UtcNow);
            UiState.SetStatus($"Правило {e.RuleId} отключено на 30 минут");
        }

        var exceptionId = !string.IsNullOrEmpty(e.Player.FriendCode) ? e.Player.FriendCode : e.Player.HashPuid;
        if (Gui.Button("Исключение для игрока", 200, enabled: !string.IsNullOrEmpty(exceptionId), disabledReason: "нет Friend Code / PUID"))
        {
            var rs = core.Registry.Settings(e.RuleId);
            var list = Core.Configuration.KdSettings.SplitList(rs.Exceptions);
            if (!list.Contains(exceptionId, StringComparer.OrdinalIgnoreCase))
            {
                core.UpdateSetting(() => rs.Exceptions = string.Join(",", list.Append(exceptionId)));
                UiState.SetStatus($"{e.Player.Display} добавлен в исключения правила {e.RuleId}");
            }
        }

        if (Gui.Button("Карточка игрока", 160, enabled: core.Players.Get(e.Player.ClientId) != null, disabledReason: "игрок не в лобби"))
        {
            UiState.SelectedClientId = e.Player.ClientId;
            UiState.Page = Page.Players;
        }

        Gui.EndRow();
        Gui.EndPanel();
    }
}
