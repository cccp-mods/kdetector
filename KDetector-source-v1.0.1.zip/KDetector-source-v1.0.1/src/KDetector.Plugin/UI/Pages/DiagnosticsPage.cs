using System.Reflection;
using System.Text;
using BepInEx.Unity.IL2CPP;
using KDetector.Core;
using KDetector.Core.Detection;
using KDetector.Core.Diagnostics;
using KDetector.Core.Logging;
using KDetector.Plugin.Game;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class DiagnosticsPage
{
    private static Vector2 _scroll;
    private static readonly FrameCache<List<LogLine>> Logs = new(1f);

    public static string BepInExVersion()
    {
        try
        {
            var asm = typeof(BasePlugin).Assembly;
            return asm.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? asm.GetName().Version?.ToString() ?? "?";
        }
        catch
        {
            return "?";
        }
    }

    public static void Draw(KDetectorCore core)
    {
        var ctx = core.Context;
        Gui.BeginRow();
        if (Gui.GuardedButton("diag-save", "Сохранить отчёт диагностики", 250))
        {
            var path = SaveReport(core);
            UiState.SetStatus(path != null ? "Отчёт: " + path : "Не удалось сохранить отчёт", 10f);
        }

        if (Gui.Button("Перечитать конфигурацию", 220))
        {
            try
            {
                KDetectorPlugin.Instance?.Config.Reload();
                UiState.SetStatus("Конфигурация перечитана с диска");
            }
            catch (Exception ex)
            {
                UiState.SetStatus("Ошибка: " + ex.Message);
            }
        }

        if (Gui.Button("Перечитать файлы правил", 220))
        {
            var w = core.ReloadRuleFiles();
            UiState.SetStatus(w.Count == 0 ? "Файлы правил перечитаны" : string.Join("; ", w), 10f);
        }

        if (Gui.Button("Очистить предупреждения", 210)) core.Diagnostics.ClearWarnings();
        Gui.EndRow();

        _scroll = Gui.BeginScroll(_scroll);
        Gui.BeginPanel();
        Gui.H2("Окружение");
        Gui.KeyValue("Among Us (Application.version)", ctx.GameVersion + (ctx.VersionSupported ? Theme.C("  поддерживается", Theme.Ok) : Theme.C($"  не входит в список ({core.Settings.Compatibility.SupportedVersions}) → {core.Settings.Compatibility.UnsupportedMode}", Theme.Warn)), 240);
        Gui.KeyValue("Проверено на версии", PluginMetadata.VerifiedGameVersion, 240);
        Gui.KeyValue("BepInEx", BepInExVersion(), 240);
        Gui.KeyValue(".NET", Environment.Version.ToString(), 240);
        Gui.KeyValue("64-битный процесс", Environment.Is64BitProcess ? "да" : "нет", 240);
        Gui.KeyValue("Бренд", PluginMetadata.Name, 240);
        Gui.KeyValue("Версия", "v" + PluginMetadata.Version, 240);
        Gui.KeyValue("RpcCalls / Platforms", $"{GameEnums.RpcCount} / {GameEnums.PlatformCount}", 240);
        Gui.KeyValue("Регион / официальный", $"{Theme.Esc(ctx.RegionName)} / {(ctx.OnOfficialServer ? "да" : "нет")}", 240);
        Gui.EndPanel();

        Gui.BeginPanel();
        Gui.H2("Модули и точки интеграции");
        foreach (var m in core.Diagnostics.Modules())
        {
            var state = m.State switch
            {
                ModuleState.Ok => Theme.C("OK", Theme.Ok),
                ModuleState.Warning => Theme.C("внимание", Theme.Warn),
                ModuleState.Disabled => Theme.M("отключено"),
                _ => Theme.A("ошибка"),
            };
            Gui.Label($"{state}  {Theme.B(Theme.Esc(m.Name))}  {Theme.M(Theme.Esc(m.Detail))}", Theme.Small);
        }

        var unavailable = core.Registry.All().Where(r => r.Availability != RuleAvailability.Available).ToList();
        foreach (var r in unavailable)
            Gui.Label($"{Theme.C(r.Availability.ToString(), Theme.Warn)}  {r.Descriptor.Id}: {Theme.M(Theme.Esc(r.AvailabilityReason))}", Theme.Small);
        Gui.EndPanel();

        var warnings = core.Diagnostics.Warnings();
        Gui.BeginPanel();
        Gui.H2($"Предупреждения ({warnings.Count})");
        if (warnings.Count == 0) Gui.Muted("Нет.");
        foreach (var w in warnings) Gui.Label(Theme.C("• ", Theme.Warn) + Theme.Esc(w), Theme.Small);
        Gui.EndPanel();

        Gui.BeginPanel();
        Gui.H2("Журнал (последние строки)");
        foreach (var l in Logs.Get(() => core.Log.Recent.Latest(40)))
        {
            var color = l.Level switch
            {
                KdLogLevel.Error => Theme.Accent,
                KdLogLevel.Warning => Theme.Warn,
                _ => Theme.Muted,
            };
            Gui.Label($"{Theme.M(l.Utc.ToLocalTime().ToString("HH:mm:ss"))} {Theme.C(l.Level.ToString(), color)} [{l.Source}] {Theme.Esc(l.Message)}", Theme.Small);
        }

        Gui.EndPanel();
        Gui.EndScroll();
    }

    public static string? SaveReport(KDetectorCore core)
    {
        try
        {
            var ctx = core.Context;
            var sb = new StringBuilder();
            sb.AppendLine($"{PluginMetadata.Name} v{PluginMetadata.Version} — диагностика ({DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC)");
            sb.AppendLine($"Among Us: {ctx.GameVersion} (поддерживается: {ctx.VersionSupported}); проверено на {PluginMetadata.VerifiedGameVersion}");
            sb.AppendLine($"BepInEx: {BepInExVersion()}; .NET {Environment.Version}; x64: {Environment.Is64BitProcess}");
            sb.AppendLine($"Фаза: {ctx.Phase}; хост: {ctx.LocalIsHost}; официальный сервер: {ctx.OnOfficialServer}; модифицированный протокол: {ctx.ModdedProtocol}");
            sb.AppendLine($"RpcCalls: {GameEnums.RpcCount}; Platforms: {GameEnums.PlatformCount}");
            sb.AppendLine($"RPC проверено {core.Inspector.Inspected}, отменено {core.Inspector.Cancelled}, ошибок {core.Inspector.Errors}");
            sb.AppendLine();
            sb.AppendLine("Модули:");
            foreach (var m in core.Diagnostics.Modules()) sb.AppendLine($"  [{m.State}] {m.Name}: {m.Detail}");
            sb.AppendLine("Правила:");
            foreach (var r in core.Registry.All())
                sb.AppendLine($"  {r.Descriptor.Id} v{r.Descriptor.Version}: {r.Availability} {r.AvailabilityReason}; enabled={core.Registry.Settings(r.Descriptor.Id).Enabled}; obs={r.Observations}; events={r.Events}");
            sb.AppendLine("Предупреждения:");
            foreach (var w in core.Diagnostics.Warnings()) sb.AppendLine("  " + w);
            sb.AppendLine("Журнал:");
            foreach (var l in core.Log.Recent.Snapshot()) sb.AppendLine($"  {l.Utc:HH:mm:ss} [{l.Level}] [{l.Source}] {l.Message}");

            Directory.CreateDirectory(core.Paths.ExportsDirectory);
            var path = Path.Combine(core.Paths.ExportsDirectory, $"diagnostics-{DateTime.UtcNow:yyyyMMdd-HHmmss}.txt");
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
            return path;
        }
        catch (Exception ex)
        {
            core.Log.Error("Diagnostics", "Не удалось сохранить отчёт", ex);
            return null;
        }
    }
}
