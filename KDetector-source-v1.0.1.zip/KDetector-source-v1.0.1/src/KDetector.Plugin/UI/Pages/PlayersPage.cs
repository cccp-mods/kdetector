using KDetector.Core;
using KDetector.Core.Database;
using KDetector.Core.Detection;
using KDetector.Core.Players;
using KDetector.Core.Risk;
using KDetector.Core.UiModel;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class PlayersPage
{
    private static Vector2 _scroll;
    private static Vector2 _cardScroll;
    private static readonly SortState Sort = new("Риск", true);
    private static readonly FrameCache<List<PlayerRow>> Rows = new(0.5f);
    private static readonly FrameCache<CardData?> Card = new(0.5f);
    private static string _lastFilter = string.Empty;
    private static readonly float[] Widths = { 190, 50, 80, 170, 120, 70, 90 };

    public static void Draw(KDetectorCore core)
    {
        var session = core.Context.SessionId;
        Gui.BeginRow();
        var filter = TextInput.Field("players.filter", "Поиск: имя, Friend Code или ID", 320);
        if (filter != _lastFilter)
        {
            _lastFilter = filter;
            Rows.Invalidate();
        }

        Gui.Flex();
        Gui.Label(Theme.M($"Игроков: {core.Players.Count}"), Theme.Small, 110);
        Gui.EndRow();

        var rows = Rows.Get(() => PlayerTable.Build(core.Players.Snapshot(), p => core.Risk.Assess(p.Key(session)),
            p => core.Actions.MarkedSuspicious.Contains(p.Key(session)), filter, Sort));

        Gui.BeginPanel2();
        Gui.BeginRow();
        for (var i = 0; i < PlayerTable.Columns.Length; i++)
        {
            var col = PlayerTable.Columns[i];
            if (Gui.Cell(Theme.B(col + Sort.Arrow(col)), Widths[i]))
            {
                Sort.Toggle(col);
                Rows.Invalidate();
            }
        }

        Gui.EndRow();
        Gui.EndPanel();

        var hasSelection = UiState.SelectedClientId >= 0 && core.Players.Get(UiState.SelectedClientId) != null;
        _scroll = GUILayout.BeginScrollView(_scroll, false, true, GUILayout.Height(Theme.Px(hasSelection ? 190 : 430)));
        if (rows.Count == 0)
            Gui.Empty(core.Context.InOnlineLobbyOrGame ? "Нет игроков, подходящих под фильтр." : "Вы не в лобби — список игроков пуст.");

        foreach (var r in rows)
        {
            var p = r.Player.Identity;
            var selected = p.ClientId == UiState.SelectedClientId;
            Gui.BeginRow();
            var name = Theme.Esc(p.Display) + (p.IsHost ? Theme.M(" (хост)") : "") + (p.IsLocal ? Theme.M(" (вы)") : "") + (r.Marked ? Theme.A(" ●") : "");
            if (Gui.Cell(name, Widths[0], selected)) Select(p.ClientId, selected);
            if (Gui.Cell(p.PlayerId.ToString(), Widths[1], selected)) Select(p.ClientId, selected);
            if (Gui.Cell(p.LevelDisplay, Widths[2], selected)) Select(p.ClientId, selected);
            if (Gui.Cell(Theme.Esc(p.Platform?.Display ?? "—"), Widths[3], selected)) Select(p.ClientId, selected);
            if (Gui.Cell(Theme.Risk(r.Risk), Widths[4], selected)) Select(p.ClientId, selected);
            if (Gui.Cell(r.Player.EventCount.ToString(), Widths[5], selected)) Select(p.ClientId, selected);
            if (Gui.Cell(Ago(r.Player.LastActivityUtc), Widths[6], selected)) Select(p.ClientId, selected);
            Gui.EndRow();
        }

        GUILayout.EndScrollView();

        if (hasSelection) DrawCard(core);
    }

    private static void Select(int clientId, bool alreadySelected)
    {
        UiState.SelectedClientId = alreadySelected ? -1 : clientId;
        Card.Invalidate();
    }

    private sealed class CardData
    {
        public LivePlayer Player = null!;
        public RiskAssessment Risk = RiskAssessment.Empty;
        public List<DetectionEvent> Events = new();
        public DetectionRecord? Record;
    }

    private static void DrawCard(KDetectorCore core)
    {
        var session = core.Context.SessionId;
        var data = Card.Get(() =>
        {
            var live = core.Players.Get(UiState.SelectedClientId);
            if (live == null) return null;
            var key = live.Identity.Key(session);
            return new CardData
            {
                Player = live.Clone(),
                Risk = core.Risk.Assess(key),
                Events = core.Engine.Feed.Snapshot().Where(e => e.PlayerKey == key).OrderByDescending(e => e.TimestampUtc).Take(30).ToList(),
                Record = core.Database.FindByPlayer(live.Identity),
            };
        });
        if (data == null) return;

        var p = data.Player.Identity;
        var ctx = core.Context;
        Gui.BeginPanel();
        Gui.BeginRow();
        Gui.Title(Theme.Esc(p.Display));
        Gui.Label("  " + Theme.Risk(data.Risk), Theme.Label, 220);
        Gui.Flex();
        if (Gui.Button("Закрыть", 90)) Select(-1, true);
        Gui.EndRow();

        _cardScroll = GUILayout.BeginScrollView(_cardScroll, false, true, GUILayout.Height(Theme.Px(220)));
        Gui.BeginRow();
        Gui.BeginCol(330);
        Gui.KeyValue("PlayerId / ClientId", $"{p.PlayerId} / {p.ClientId}", 150);
        Gui.KeyValue("Friend Code", string.IsNullOrEmpty(p.FriendCode) ? Theme.M("недоступен") : Theme.Esc(p.FriendCode), 150);
        Gui.KeyValue("HashPuid", string.IsNullOrEmpty(p.HashPuid) ? Theme.M("недоступен") : p.HashPuid, 150);
        Gui.KeyValue("Уровень", p.LevelDisplay + Theme.M("  (NetworkedPlayerInfo)"), 150);
        Gui.KeyValue("Платформа", Theme.Esc(p.Platform?.Display ?? "—") + Theme.M("  (заявлена клиентом)"), 150);
        if (p.Platform != null && (p.Platform.XboxPlatformId != 0 || p.Platform.PsnPlatformId != 0))
            Gui.KeyValue("ID консоли", $"Xbox {p.Platform.XboxPlatformId} / PSN {p.Platform.PsnPlatformId}", 150);
        Gui.KeyValue("В лобби с", data.Player.JoinedUtc.ToLocalTime().ToString("HH:mm:ss"), 150);
        Gui.KeyValue("В базе", data.Record == null ? Theme.M("нет записи") : $"{data.Record.EventCount} событий, {data.Record.ReviewStatus}" + (data.Record.WhitelistStatus == WhitelistStatus.Whitelisted ? Theme.C(" · whitelist", Theme.Ok) : ""), 150);
        Gui.EndCol();

        Gui.BeginCol();
        Gui.H2("Почему такой риск");
        foreach (var line in data.Risk.Explanation.Take(8)) Gui.Muted(Theme.Esc(line));
        Gui.EndCol();
        Gui.EndRow();

        Gui.H2("События игрока в этой сессии");
        if (data.Events.Count == 0) Gui.Muted("Событий нет.");
        foreach (var e in data.Events) DetectionsPage.Row(e, compact: true);
        GUILayout.EndScrollView();

        // Действия
        Gui.BeginRow();
        var stable = !string.IsNullOrEmpty(p.FriendCode) || !string.IsNullOrEmpty(p.HashPuid);
        var notSelf = !p.IsLocal && !p.IsHost;
        var hostReason = !ctx.LocalIsHost ? "вы не хост этого лобби" : p.IsLocal ? "это вы" : p.IsHost ? "нельзя применить к хосту" : null;

        if (Gui.GuardedButton("kick:" + p.ClientId, "Kick", 80, accent: true, enabled: ctx.LocalIsHost && notSelf, disabledReason: hostReason))
        {
            var ok = core.Actions.TryHostAction(p.Clone(), false, false, "manual", "Kick из карточки игрока", out var err);
            UiState.SetStatus(ok ? $"Kick выполнен: {p.Display}" : "Kick не выполнен: " + err);
        }

        if (Gui.Button("Ban…", 80, accent: true, enabled: ctx.LocalIsHost && notSelf, disabledReason: hostReason))
        {
            var target = p.Clone();
            ConfirmActions.Request("ban:" + p.ClientId, $"Забанить {Theme.Esc(p.Display)} в этом лобби? Бан действует только в текущей комнате (глобального бана у клиента нет).", 1, () =>
                core.Actions.TryHostAction(target, true, false, "manual", "Ban из карточки игрока", out var err) ? $"Ban выполнен: {target.Display}" : "Ban не выполнен: " + err);
        }

        var whitelisted = data.Record?.WhitelistStatus == WhitelistStatus.Whitelisted;
        if (Gui.Button(whitelisted ? "Убрать из whitelist" : "В whitelist", 170, enabled: stable, disabledReason: "нет Friend Code / PUID — игрока нельзя надёжно идентифицировать"))
        {
            var rec = core.Database.EnsureRecord(p);
            if (rec != null) core.Database.SetWhitelist(rec.RecordId, !whitelisted);
            Card.Invalidate();
            UiState.SetStatus(whitelisted ? "Удалён из whitelist" : "Добавлен в whitelist: автоматические меры к игроку не применяются");
        }

        var watch = data.Record?.Watchlist == true;
        if (Gui.Button(watch ? "Убрать из watchlist" : "В watchlist", 170, enabled: stable, disabledReason: "нет Friend Code / PUID"))
        {
            var rec = core.Database.EnsureRecord(p);
            if (rec != null) core.Database.SetWatchlist(rec.RecordId, !watch);
            Card.Invalidate();
        }

        if (Gui.GuardedButton("report:" + p.ClientId, "Отчёт", 90))
        {
            var path = core.WriteReport(p);
            UiState.SetStatus(path != null ? "Отчёт: " + path : "Не удалось сохранить отчёт", 10f);
        }

        if (Gui.Button("Копировать FC", 130, enabled: !string.IsNullOrEmpty(p.FriendCode), disabledReason: "Friend Code недоступен"))
        {
            GUIUtility.systemCopyBuffer = p.FriendCode;
            UiState.SetStatus("Friend Code скопирован");
        }

        Gui.EndRow();
        Gui.EndPanel();
    }

    public static string Ago(DateTime utc)
    {
        var s = (DateTime.UtcNow - utc).TotalSeconds;
        if (s < 5) return "сейчас";
        if (s < 60) return $"{(int)s} с";
        if (s < 3600) return $"{(int)(s / 60)} мин";
        return $"{(int)(s / 3600)} ч";
    }
}
