using System.Text;
using KDetector.Core;
using KDetector.Core.RpcShield;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class RpcShieldPage
{
    private static Vector2 _scroll;
    private static Vector2 _recentScroll;
    private static bool _dirty;
    private static readonly FrameCache<List<ShieldIncident>> Recent = new(0.5f);
    private static readonly FrameCache<Dictionary<string, (long total, long exceeded, long cancelled)>> Stats = new(0.5f);

    public static void Draw(KDetectorCore core)
    {
        var s = core.Settings.RpcShield;
        Gui.BeginPanel();
        Gui.BeginRow();
        var en = Gui.Toggle(s.Enabled, "RPC Shield включён");
        if (en != s.Enabled) core.UpdateSetting(() => s.Enabled = en);
        var dry = Gui.Toggle(s.DryRun, "Dry Run (только фиксировать превышения)");
        if (dry != s.DryRun) core.UpdateSetting(() => s.DryRun = dry);
        var unk = Gui.Toggle(s.LogUnknownRpcs, "журнал RPC вне перечисления игры");
        if (unk != s.LogUnknownRpcs) core.UpdateSetting(() => s.LogUnknownRpcs = unk);
        Gui.EndRow();
        Gui.Muted($"Проверено RPC: {core.Inspector.Inspected}, отменено: {core.Inspector.Cancelled}, ошибок обработки: {core.Inspector.Errors}. " +
                  $"Общий лимит: {s.GlobalLimit} за {s.GlobalWindowMs} мс (только наблюдение). Событие — не чаще раза в {s.EventCooldownSeconds} с на игрока и категорию, кроме усиления флуда.");
        Gui.Muted("Отмена применяется только к категориям, где она безопасна (визуальные эффекты, косметика, чат). Движение, системы, собрания и убийства при превышении только фиксируются, чтобы не вызвать рассинхронизацию.");
        Gui.EndPanel();

        Gui.BeginRow();
        Gui.H2($"Категории ({core.ShieldRules.RulesVersion})");
        Gui.Flex();
        if (Gui.Button("Сохранить", 110, accent: _dirty, enabled: _dirty, disabledReason: "изменений нет"))
        {
            core.SaveShieldRules();
            _dirty = false;
            UiState.SetStatus("Правила RPC Shield сохранены в " + s.RulesFile);
        }

        if (Gui.Button("Перечитать файлы", 150))
        {
            var w = core.ReloadRuleFiles();
            _dirty = false;
            UiState.SetStatus(w.Count == 0 ? "Файлы правил перечитаны" : "Перечитано с предупреждениями: " + string.Join("; ", w), 10f);
        }

        if (Gui.Button("Откатить к встроенным…", 200))
            ConfirmActions.Request("shield-reset", "Вернуть встроенные лимиты RPC Shield? Текущий файл будет сохранён как резервная копия (.bak).", 1, () =>
            {
                core.ResetShieldRulesToDefaults();
                _dirty = false;
                return "Встроенные правила RPC Shield восстановлены.";
            });

        if (Gui.Button("Очистить статистику", 170))
        {
            core.Shield.ClearStatistics();
            Recent.Invalidate();
            Stats.Invalidate();
        }

        if (Gui.Button("Экспорт журнала", 150)) Export(core);
        Gui.EndRow();

        var stats = Stats.Get(() => core.Shield.Stats.ToDictionary(p => p.Key, p => (p.Value.Total, p.Value.Exceeded, p.Value.Cancelled)));
        _scroll = GUILayout.BeginScrollView(_scroll, false, true, GUILayout.Height(Theme.Px(250)));
        Gui.BeginRow();
        Gui.TextCell(Theme.B("Категория"), 130);
        Gui.TextCell(Theme.B("Вкл"), 50);
        Gui.TextCell(Theme.B("Лимит"), 140);
        Gui.TextCell(Theme.B("Окно, мс"), 160);
        Gui.TextCell(Theme.B("Отмена"), 80);
        Gui.TextCell(Theme.B("Хост"), 90);
        Gui.TextCell(Theme.B("Всего / превыш. / отменено"), 220);
        Gui.EndRow();
        foreach (var c in core.ShieldRules.Categories)
        {
            Gui.BeginRow();
            Gui.TextCell(Theme.B(c.Name), 130);
            if (Gui.Cell(c.Enabled ? Theme.C("■", Theme.Accent) : Theme.M("□"), 50))
            {
                c.Enabled = !c.Enabled;
                Changed(core);
            }

            Stepper(core, c.MaxEvents, 1, 1, 10000, v => c.MaxEvents = v, 140);
            Stepper(core, c.WindowMs, 100, 100, 60000, v => c.WindowMs = v, 160);
            Gui.TextCell(c.SafeToCancel ? Theme.C("да", Theme.Ok) : Theme.M("нет"), 80);
            Gui.TextCell(c.ExemptHost ? Theme.M("без лимита") : "с лимитом", 90);
            stats.TryGetValue(c.Name, out var st);
            Gui.TextCell($"{st.total} / {(st.exceeded > 0 ? Theme.C(st.exceeded.ToString(), Theme.Warn) : "0")} / {st.cancelled}", 220);
            Gui.EndRow();
            Gui.Muted("    " + Theme.Esc(c.Description) + (c.RpcNames.Count > 0 ? "  [" + string.Join(", ", c.RpcNames) + "]" : string.Empty));
        }

        if (core.ShieldRules.Overrides.Count > 0)
        {
            Gui.H2("Индивидуальные лимиты RPC");
            foreach (var o in core.ShieldRules.Overrides)
                Gui.Muted($"{o.RpcName}: {o.MaxEvents} за {o.WindowMs} мс {(o.Enabled ? "" : "(выкл)")}");
        }
        else
        {
            Gui.Muted("Индивидуальные лимиты для отдельных RPC задаются в файле " + s.RulesFile + " (раздел Overrides).");
        }

        GUILayout.EndScrollView();

        Gui.H2("Последние превышения");
        var recent = Recent.Get(() => core.Shield.Recent.Latest(50));
        _recentScroll = GUILayout.BeginScrollView(_recentScroll, false, true, GUILayout.Height(Theme.Px(130)));
        if (recent.Count == 0) Gui.Muted("Превышений не было.");
        foreach (var r in recent)
            Gui.Label($"{Theme.M(r.Utc.ToLocalTime().ToString("HH:mm:ss"))} {Theme.B(Theme.Esc(r.PlayerName))} {r.Category}: {Theme.Esc(r.Rpc)} > {r.Limit}/{r.WindowMs} мс  " +
                      (r.Cancelled ? Theme.A("отменено") : Theme.M(Theme.Esc(r.Note))), Theme.Small);
        GUILayout.EndScrollView();
    }

    private static void Changed(KDetectorCore core)
    {
        _dirty = true;
        core.Shield.Rebuild(core.ShieldRules); // применяется сразу; в файл — по кнопке «Сохранить»
    }

    private static void Stepper(KDetectorCore core, int value, int step, int min, int max, Action<int> set, float width)
    {
        Gui.BeginRow();
        if (Gui.Button("−", 26))
        {
            set(Math.Max(min, value - step));
            Changed(core);
        }

        Gui.Label(value.ToString(), Theme.Label, width - 70);
        if (Gui.Button("+", 26))
        {
            set(Math.Min(max, value + step));
            Changed(core);
        }

        Gui.EndRow();
    }

    private static void Export(KDetectorCore core)
    {
        try
        {
            Directory.CreateDirectory(core.Paths.ExportsDirectory);
            var path = Path.Combine(core.Paths.ExportsDirectory, $"rpcshield-{DateTime.UtcNow:yyyyMMdd-HHmmss}.txt");
            var sb = new StringBuilder();
            sb.AppendLine(PluginMetadata.Name + " RPC Shield — журнал превышений (UTC)");
            foreach (var p in core.Shield.Stats) sb.AppendLine($"{p.Key}: всего {p.Value.Total}, превышений {p.Value.Exceeded}, отменено {p.Value.Cancelled}");
            sb.AppendLine();
            foreach (var r in core.Shield.Recent.Snapshot())
                sb.AppendLine($"{r.Utc:yyyy-MM-dd HH:mm:ss} {r.PlayerName} (client {r.ClientId}) {r.Category} {r.Rpc} limit {r.Limit}/{r.WindowMs}ms cancelled={r.Cancelled} {r.Note}");
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
            UiState.SetStatus("Журнал: " + path, 10f);
        }
        catch (Exception ex)
        {
            UiState.SetStatus("Экспорт не удался: " + ex.Message);
        }
    }
}
