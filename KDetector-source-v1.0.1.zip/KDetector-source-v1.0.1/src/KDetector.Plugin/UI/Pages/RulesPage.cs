using KDetector.Core;
using KDetector.Core.Detection;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class RulesPage
{
    private static Vector2 _scroll;
    private static string? _expanded;
    private static int _tab;
    private static readonly string[] Tabs = { "Правила", "Уровень", "Платформа", "Некорр. платформа", "Известные клиенты", "Недопуст. действия" };

    public static void Draw(KDetectorCore core)
    {
        _tab = Gui.Choice(_tab, Tabs);
        _scroll = Gui.BeginScroll(_scroll);
        switch (_tab)
        {
            case 0: RuleList(core); break;
            case 1: Section(core, core.Settings.Level, "LevelSpoofing", "LVL Spoofer Detector",
                "Проверяется только представление значения, пользовательский диапазон (если включён) и изменения внутри подключения. Настоящий уровень аккаунта клиентский плагин проверить не может."); break;
            case 2: Section(core, core.Settings.PlatformSpoof, "PlatformSpoofing", "Platform Spoofer Detector",
                "Проверяется согласованность заявленной платформы и идентификатора консоли, а также смена платформы без переподключения. Заявленная платформа не доказывает реальное устройство."); break;
            case 3: Section(core, core.Settings.InvalidPlatform, "InvalidPlatform", "Invalid Platform Detector",
                $"Значение платформы сравнивается с перечислением Platforms текущей версии игры. Нестандартные значения из списка разрешённых (по умолчанию 112 — Starlight) не считаются ошибкой."); break;
            case 4: KnownClients(core); break;
            case 5: InvalidActions(core); break;
        }

        Gui.EndScroll();
    }

    private static void RuleList(KDetectorCore core)
    {
        Gui.Muted("Нажмите на правило, чтобы увидеть описание, проверяемые данные, ограничения и настройки порога.");
        DetectionCategory? lastCat = null;
        foreach (var r in core.Registry.All())
        {
            var d = r.Descriptor;
            if (lastCat != d.Category)
            {
                lastCat = d.Category;
                Gui.H2(DetectionText.Category(d.Category));
            }

            var rs = core.Registry.Settings(d.Id);
            var active = core.Registry.IsActive(d.Id, DateTime.UtcNow);
            var availability = r.Availability switch
            {
                RuleAvailability.Available => Theme.C("доступно", Theme.Ok),
                RuleAvailability.Limited => Theme.C("ограничено", Theme.Warn),
                _ => Theme.A("недоступно"),
            };
            var temp = r.DisabledUntilUtc.HasValue && r.DisabledUntilUtc > DateTime.UtcNow ? Theme.C($" · пауза до {r.DisabledUntilUtc.Value.ToLocalTime():HH:mm}", Theme.Warn) : string.Empty;

            Gui.BeginRow();
            var toggled = Gui.Toggle(rs.Enabled, string.Empty, width: 40);
            if (toggled != rs.Enabled) core.UpdateSetting(() => rs.Enabled = toggled);
            if (Gui.Cell($"{Theme.B(Theme.Esc(d.Name))} {Theme.M($"{d.Id} v{d.Version}")}  {availability}{temp}" +
                         $"\n{Theme.M($"наблюдений {r.Observations} · событий {r.Events} · ниже порога {r.SuppressedByThreshold} · ниже уверенности {r.SuppressedByConfidence} · исключений {r.SuppressedByException}")}", 680, _expanded == d.Id))
                _expanded = _expanded == d.Id ? null : d.Id;
            Gui.Label(active ? Theme.C("активно", Theme.Ok) : Theme.M("не активно"), Theme.Small, 90);
            Gui.EndRow();

            if (_expanded != d.Id) continue;
            Gui.BeginPanel2();
            Gui.Label(Theme.Esc(d.Description), Theme.Label);
            Gui.KeyValue("Проверяемые данные", Theme.Esc(d.CheckedData), 170);
            Gui.KeyValue("Ограничения", Theme.C(Theme.Esc(d.Limitations), Theme.Warn), 170);
            if (!string.IsNullOrEmpty(r.AvailabilityReason)) Gui.KeyValue("Совместимость", Theme.Esc(r.AvailabilityReason), 170);
            Gui.Separator();
            SettingsEditor.Draw(core, rs, "rule." + d.Id, showRestartHints: false);
            Gui.BeginRow();
            if (Gui.Button("Пауза на 30 мин", 160)) core.Registry.DisableTemporarily(d.Id, TimeSpan.FromMinutes(30), DateTime.UtcNow);
            if (Gui.Button("Снять паузу", 130, enabled: r.DisabledUntilUtc.HasValue, disabledReason: "правило не на паузе")) core.Registry.ClearTemporaryDisable(d.Id);
            if (Gui.Button("Сбросить настройки правила…", 240))
            {
                var id = d.Id;
                ConfirmActions.Request("reset-rule", $"Сбросить настройки правила {id} к значениям по умолчанию?", 1, () =>
                {
                    core.UpdateSetting(() => core.Registry.ResetSettings(id));
                    return "Настройки правила сброшены.";
                });
            }

            Gui.EndRow();
            Gui.EndPanel();
        }
    }

    private static void Section(KDetectorCore core, object section, string name, string title, string explanation)
    {
        Gui.BeginPanel();
        Gui.Title(title);
        Gui.Muted(explanation);
        Gui.EndPanel();
        Gui.BeginPanel();
        SettingsEditor.Draw(core, section, "sec." + name);
        Gui.EndPanel();
        Gui.Muted("Пороги, уверенность, окно и исключения отдельных правил — во вкладке «Правила».");
    }

    private static void KnownClients(KDetectorCore core)
    {
        Section(core, core.Settings.KnownClients, "KnownClients", "Known Cheat Client Detection",
            "Совпадение номера RPC (и, где возможно, структуры данных) с публично описанной сигнатурой — это признак, а не доказательство. " +
            "Устройства игроков не сканируются. MalumMenu не имеет уникального сетевого признака и этим модулем не опознаётся.");
        var cat = core.Signatures;
        Gui.BeginPanel();
        Gui.H2($"Сигнатуры {cat.RulesVersion} (проверено {cat.ReviewedUtc})");
        Gui.Muted(Theme.Esc(cat.Notice));
        foreach (var sig in cat.Signatures)
            Gui.Label($"{(sig.Enabled ? Theme.C("■", Theme.Accent) : Theme.M("□"))} {Theme.B(Theme.Esc(sig.Family))} {Theme.M(sig.Id)} · RPC {sig.CallId} · {sig.PayloadCheck} · уверенность {sig.Confidence:0.00}/{sig.ConfidenceWithPayload:0.00}\n      {Theme.M(Theme.Esc(sig.Source))}", Theme.Small);
        foreach (var c in core.KnownClients.Conflicts) Gui.Label(Theme.C(Theme.Esc(c), Theme.Warn), Theme.Small);
        Gui.Muted("Редактирование: файл Data/" + core.Settings.KnownClients.SignatureFile + ", затем «Перечитать файлы» на странице RPC Shield или Diagnostics.");
        Gui.EndPanel();
    }

    private static void InvalidActions(KDetectorCore core)
    {
        Section(core, core.Settings.InvalidActions, "InvalidActions", "Invalid Action Detector",
            "RPC сравнивается с фазой игры и правами отправителя. Отправитель определяется по владельцу объекта: хост вправе слать RPC от имени других объектов, поэтому такие правила имеют умеренную уверенность. " +
            "Саботажи клиентов видит только хост.");
        var suspended = core.Protocol.SuspendedReason(core.Context);
        if (suspended != null) Gui.Label(Theme.C("Сейчас приостановлено: " + suspended, Theme.Warn), Theme.Small);
        var set = core.ProtocolSet;
        Gui.BeginPanel();
        Gui.H2($"Правила протокола {set.RulesVersion}");
        foreach (var r in set.Rules)
        {
            var phases = r.Phases.Count == 0 ? "любая фаза" : string.Join(", ", r.Phases);
            Gui.Label($"{(r.Enabled ? Theme.C("■", Theme.Accent) : Theme.M("□"))} {Theme.B(r.Id)} · {r.Condition} · {phases} · {DetectionText.Evidence(r.Evidence)} · уверенность {r.Confidence:0.00} · отмена: {(r.Cancelable ? "допустима" : "нет")}\n      {Theme.M(Theme.Esc(r.Description))}\n      {Theme.M(string.Join(", ", r.RpcNames))}", Theme.Small);
        }

        Gui.Muted("Редактирование: файл Data/" + core.Settings.InvalidActions.RulesFile + ".");
        Gui.EndPanel();
    }
}
