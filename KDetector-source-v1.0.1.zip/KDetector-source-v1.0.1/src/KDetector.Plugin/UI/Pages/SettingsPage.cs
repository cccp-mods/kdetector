using KDetector.Core;
using KDetector.Core.Configuration;
using UnityEngine;

namespace KDetector.Plugin.UI.Pages;

public static class SettingsPage
{
    private static Vector2 _scroll;
    private static int _section;

    public static void Draw(KDetectorCore core)
    {
        var sections = new object[]
        {
            core.Settings.General, core.Settings.Detection, core.Settings.Notifications, core.Settings.Gui, core.Settings.Logging,
            core.Settings.Database, core.Settings.AutoActions, core.Settings.RpcShield, core.Settings.Compatibility, core.Settings.Commands,
        };
        var titles = sections.Select(s => SettingsValidator.SectionTitle(s.GetType())).ToArray();

        Gui.BeginRow();
        Gui.BeginCol(170);
        for (var i = 0; i < sections.Length; i++)
            if (Gui.Nav(titles[i], i == _section))
                _section = i;
        Gui.Space(8);
        if (Gui.Button("Сбросить ВСЁ…", 160, accent: true))
            ConfirmActions.Request("reset-all", "Сбросить все настройки " + global::KDetector.Plugin.PluginMetadata.Name + " (включая настройки правил) к значениям по умолчанию? База данных и файлы правил не изменятся.", 2, () =>
            {
                core.UpdateSetting(() =>
                {
                    SettingsValidator.ResetAll(core.Settings);
                    core.Registry.ResetAllSettings();
                });
                return "Все настройки сброшены.";
            });
        Gui.EndCol();

        Gui.BeginCol();
        var section = sections[_section];
        Gui.BeginRow();
        Gui.Title(titles[_section]);
        Gui.Flex();
        if (Gui.Button("Сбросить раздел…", 170))
            ConfirmActions.Request("reset-section", $"Сбросить раздел «{titles[_section]}» к значениям по умолчанию?", 1, () =>
            {
                core.UpdateSetting(() => SettingsValidator.ResetSection(section));
                return $"Раздел «{titles[_section]}» сброшен.";
            });
        Gui.EndRow();
        Gui.Muted("⟳ — изменение вступает в силу после перезапуска игры. Остальные параметры применяются сразу и сохраняются в файл конфигурации.");

        _scroll = Gui.BeginScroll(_scroll);
        SettingsEditor.Draw(core, section, "set." + titles[_section]);

        Gui.Separator();
        Gui.H2("Файлы");
        PathRow("Конфигурация", KDetectorPlugin.Binder?.ConfigFilePath ?? "—");
        PathRow("Папка данных", core.Paths.DataDirectory);
        PathRow("База", core.Database.Path);
        PathRow("Журнал", Path.Combine(core.Paths.LogsDirectory, "KDetector.log"));
        PathRow("Экспорт / отчёты", core.Paths.ExportsDirectory + "  ·  " + core.Paths.ReportsDirectory);
        Gui.EndScroll();
        Gui.EndCol();
        Gui.EndRow();
    }

    private static void PathRow(string title, string path)
    {
        Gui.BeginRow();
        Gui.Label(Theme.M(title), Theme.Label, 150);
        Gui.Label(Theme.Esc(path), Theme.Small);
        Gui.Flex();
        if (Gui.Button("Копировать", 110))
        {
            GUIUtility.systemCopyBuffer = path;
            UiState.SetStatus("Скопировано: " + path);
        }

        Gui.EndRow();
    }
}
