using System.Globalization;
using System.Reflection;
using KDetector.Core;
using KDetector.Core.Configuration;

namespace KDetector.Plugin.UI;

/// <summary>
/// Универсальный редактор секции настроек по атрибутам [Setting]: bool — переключатель, enum — выбор,
/// числа — слайдер и кнопки ±, строки — поле ввода с кнопкой «Применить».
/// Все изменения проходят через KDetectorCore.UpdateSetting (проверка значений + сохранение в .cfg).
/// </summary>
public static class SettingsEditor
{
    public static void Draw(KDetectorCore core, object section, string idPrefix, bool showRestartHints = true)
    {
        foreach (var prop in SettingsValidator.SettingProperties(section.GetType()))
        {
            var attr = prop.GetCustomAttribute<SettingAttribute>()!;
            var value = prop.GetValue(section);
            var id = idPrefix + "." + prop.Name;

            Gui.BeginRow();
            Gui.Label(Theme.B(prop.Name) + (attr.RequiresRestart && showRestartHints ? Theme.M("  ⟳") : string.Empty), Theme.Label, 210);

            switch (value)
            {
                case bool b:
                    var nb = Gui.Toggle(b, b ? "вкл" : "выкл");
                    if (nb != b) Set(core, section, prop, nb);
                    break;

                case Enum e:
                    {
                        var names = Enum.GetNames(e.GetType());
                        var current = Array.IndexOf(names, e.ToString());
                        var chosen = Gui.Choice(current, names);
                        if (chosen != current && chosen >= 0) Set(core, section, prop, Enum.Parse(e.GetType(), names[chosen]));
                        break;
                    }

                case int i:
                    NumberRow(core, section, prop, attr, i, true);
                    break;

                case double d:
                    NumberRow(core, section, prop, attr, d, false);
                    break;

                case string s:
                    {
                        TextInput.Bind(id, s);
                        var edited = TextInput.Field(id, "(пусто)", 300, 200);
                        if (Gui.Button("Применить", 100, enabled: edited != s, disabledReason: "значение не изменено"))
                        {
                            Set(core, section, prop, edited);
                            TextInput.Set(id, (string)prop.GetValue(section)!);
                            UiState.SetStatus($"{prop.Name} = {prop.GetValue(section)}");
                        }

                        break;
                    }
            }

            Gui.EndRow();
            Gui.Muted(attr.Description + (attr.RequiresRestart ? " Вступает в силу после перезапуска игры." : string.Empty));
            Gui.Space(4);
        }
    }

    private static void NumberRow(KDetectorCore core, object section, PropertyInfo prop, SettingAttribute attr, double value, bool integer)
    {
        var min = double.IsNaN(attr.Min) ? 0 : attr.Min;
        var max = double.IsNaN(attr.Max) ? Math.Max(1, value * 2) : attr.Max;
        var step = integer ? Math.Max(1, Math.Round((max - min) / 100)) : (max - min) <= 2 ? 0.05 : Math.Max(0.1, Math.Round((max - min) / 100, 1));
        var text = integer ? ((int)value).ToString(CultureInfo.InvariantCulture) : value.ToString("0.###", CultureInfo.InvariantCulture);

        if (Gui.Button("−", 30)) Apply(core, section, prop, value - step, min, max, integer);
        Gui.Label(Theme.B(text), Theme.Label, 80);
        if (Gui.Button("+", 30)) Apply(core, section, prop, value + step, min, max, integer);

        // Слайдер — только для разумных диапазонов, иначе точное значение задаётся кнопками.
        if (max - min <= 10000)
        {
            var slid = Gui.Slider((float)value, (float)min, (float)max, 180);
            if (Math.Abs(slid - value) > (integer ? 0.5 : 0.0005)) Apply(core, section, prop, slid, min, max, integer);
        }

        Gui.Label(Theme.M($"{Fmt(min)}…{Fmt(max)}"), Theme.Small, 120);
    }

    private static void Apply(KDetectorCore core, object section, PropertyInfo prop, double v, double min, double max, bool integer)
    {
        v = Math.Max(min, Math.Min(max, v));
        if (integer) Set(core, section, prop, (int)Math.Round(v));
        else Set(core, section, prop, Math.Round(v, 3));
    }

    private static void Set(KDetectorCore core, object section, PropertyInfo prop, object value)
    {
        core.UpdateSetting(() => prop.SetValue(section, value));
    }

    private static string Fmt(double v) => v.ToString("0.##", CultureInfo.InvariantCulture);
}
