using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>
/// Поле ввода без GUILayout.TextField (его наличие в IL2CPP-сборке игры не подтверждено).
/// Символы берутся из Input.inputString в Update — тот же источник, что использует сама игра для своих полей ввода.
/// Поле выглядит как кнопка; щелчок — фокус, Enter/Esc или щелчок по другому элементу — снятие фокуса.
/// </summary>
public static class TextInput
{
    private static readonly Dictionary<string, string> Values = new();
    private static string? _focused;
    private static float _blinkStart;

    public static bool HasFocus => _focused != null;

    public static void Unfocus() => _focused = null;

    public static string Get(string id, string initial = "")
    {
        if (!Values.TryGetValue(id, out var v))
        {
            v = initial;
            Values[id] = v;
        }

        return v;
    }

    public static void Set(string id, string value) => Values[id] = value;

    private static readonly Dictionary<string, string> Originals = new();

    /// <summary>
    /// Связывает поле со значением настройки: если настройка изменилась извне (сброс, файл .cfg),
    /// а поле не редактируется, поле показывает новое значение.
    /// </summary>
    public static void Bind(string id, string actual)
    {
        if (Originals.TryGetValue(id, out var original) && original == actual) return;
        Originals[id] = actual;
        if (_focused != id) Values[id] = actual;
    }

    /// <summary>Рисует поле. Возвращает текущее значение.</summary>
    public static string Field(string id, string placeholder, float width, int maxLength = 64)
    {
        var value = Get(id);
        var focused = _focused == id;
        var caret = focused && ((Time.realtimeSinceStartup - _blinkStart) % 1f) < 0.55f ? Theme.A("|") : " ";
        var shown = value.Length == 0 && !focused ? Theme.M(placeholder) : Theme.Esc(value) + (focused ? caret : string.Empty);

        var prev = GUI.backgroundColor;
        GUI.backgroundColor = focused ? new Color(0.30f, 0.12f, 0.14f, 1f) : new Color(0.08f, 0.08f, 0.10f, 1f);
        var pressed = width > 0 ? GUILayout.Button(shown, Theme.Field, Gui.W(width)) : GUILayout.Button(shown, Theme.Field);
        GUI.backgroundColor = prev;

        if (pressed)
        {
            _focused = id;
            _blinkStart = Time.realtimeSinceStartup;
            MaxLengths[id] = maxLength;
        }

        return value;
    }

    private static readonly Dictionary<string, int> MaxLengths = new();

    /// <summary>Обработка ввода (вызывается из Update). Возвращает true, если нажат Enter в фокусированном поле.</summary>
    public static bool Update()
    {
        if (_focused == null) return false;
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            _focused = null;
            return false;
        }

        var input = Input.inputString;
        if (string.IsNullOrEmpty(input)) return false;

        var value = Get(_focused);
        var max = MaxLengths.TryGetValue(_focused, out var m) ? m : 64;
        var submitted = false;
        foreach (var ch in input)
        {
            if (ch == '\b')
            {
                if (value.Length > 0) value = value.Substring(0, value.Length - 1);
            }
            else if (ch == '\n' || ch == '\r')
            {
                submitted = true;
            }
            else if (!char.IsControl(ch) && value.Length < max)
            {
                value += ch;
            }
        }

        Values[_focused] = value;
        if (submitted) _focused = null;
        return submitted;
    }
}
