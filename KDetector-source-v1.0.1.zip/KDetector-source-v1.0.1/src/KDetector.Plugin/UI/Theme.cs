using KDetector.Core.Detection;
using KDetector.Core.Risk;
using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>
/// Тёмная минималистичная тема: почти чёрный фон, тёмно-серые поверхности, красный акцент.
/// Цвет текста задаётся rich-text тегами и GUI.contentColor (свойства, подтверждённые в IL2CPP-сборке игры);
/// фоны — однотонными текстурами 1×1, созданными в коде (внешних ресурсов нет).
/// </summary>
public static class Theme
{
    public const string Bg = "0B0B0D";
    public const string Surface = "141417";
    public const string Surface2 = "1C1C21";
    public const string Border = "2A2A31";
    public const string Accent = "E5484D";
    public const string AccentDim = "8F2D31";
    public const string Text = "EDEDEF";
    public const string Muted = "8B8B94";
    public const string Ok = "4CC38A";
    public const string Warn = "E0A23B";

    private static Texture2D? _bg, _surface, _surface2, _border, _accent;
    private static float _builtScale = -1;

    public static GUIStyle WindowBg = null!;
    public static GUIStyle Panel = null!;
    public static GUIStyle Panel2 = null!;
    public static GUIStyle AccentBar = null!;
    public static GUIStyle Separator = null!;
    public static GUIStyle Title = null!;
    public static GUIStyle H2 = null!;
    public static GUIStyle Label = null!;
    public static GUIStyle Small = null!;
    public static GUIStyle Button = null!;
    public static GUIStyle NavButton = null!;
    public static GUIStyle Cell = null!;
    public static GUIStyle CellButton = null!;
    public static GUIStyle Field = null!;

    public static float Scale { get; private set; } = 1f;

    /// <summary>Строит стили (вызывается только внутри OnGUI: GUI.skin доступен лишь там).</summary>
    public static void Ensure(float scale)
    {
        if (Mathf.Abs(_builtScale - scale) < 0.001f && WindowBg != null && _bg != null) return;
        Scale = scale;
        _builtScale = scale;

        // Текстуры от масштаба не зависят: создаются один раз (иначе изменение масштаба слайдером плодило бы текстуры).
        if (_bg == null)
        {
            _bg = Solid(Bg);
            _surface = Solid(Surface);
            _surface2 = Solid(Surface2);
            _border = Solid(Border);
            _accent = Solid(Accent);
        }

        int S(float v) => Mathf.RoundToInt(v * scale);

        WindowBg = new GUIStyle(GUI.skin.box) { normal = { background = _bg }, padding = new RectOffset(), margin = new RectOffset(), border = new RectOffset() };
        Panel = new GUIStyle(GUI.skin.box) { normal = { background = _surface }, padding = Pad(S(10), S(10), S(8), S(8)), margin = Pad(S(2), S(2), S(3), S(3)), border = new RectOffset() };
        Panel2 = new GUIStyle(GUI.skin.box) { normal = { background = _surface2 }, padding = Pad(S(8), S(8), S(6), S(6)), margin = Pad(S(2), S(2), S(2), S(2)), border = new RectOffset() };
        AccentBar = new GUIStyle(GUI.skin.box) { normal = { background = _accent }, padding = new RectOffset(), margin = new RectOffset(), border = new RectOffset() };
        Separator = new GUIStyle(GUI.skin.box) { normal = { background = _border }, padding = new RectOffset(), margin = Pad(0, 0, S(4), S(4)), border = new RectOffset() };

        Title = new GUIStyle(GUI.skin.label) { fontSize = S(16), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft };
        H2 = new GUIStyle(GUI.skin.label) { fontSize = S(13), fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft, margin = Pad(0, 0, S(4), S(2)) };
        Label = new GUIStyle(GUI.skin.label) { fontSize = S(12), alignment = TextAnchor.MiddleLeft };
        Small = new GUIStyle(GUI.skin.label) { fontSize = S(11), alignment = TextAnchor.MiddleLeft };
        Cell = new GUIStyle(GUI.skin.label) { fontSize = S(12), alignment = TextAnchor.MiddleLeft, padding = Pad(S(4), S(4), S(3), S(3)) };
        Button = new GUIStyle(GUI.skin.button) { fontSize = S(12), padding = Pad(S(10), S(10), S(5), S(5)) };
        NavButton = new GUIStyle(GUI.skin.button) { fontSize = S(12), alignment = TextAnchor.MiddleLeft, padding = Pad(S(12), S(8), S(7), S(7)), margin = Pad(S(4), S(4), S(1), S(1)) };
        CellButton = new GUIStyle(GUI.skin.button) { fontSize = S(12), alignment = TextAnchor.MiddleLeft, padding = Pad(S(6), S(6), S(4), S(4)), margin = Pad(0, 0, 1, 1) };
        Field = new GUIStyle(GUI.skin.button) { fontSize = S(12), alignment = TextAnchor.MiddleLeft, padding = Pad(S(8), S(8), S(5), S(5)) };
    }

    public static float Px(float v) => v * Scale;

    private static RectOffset Pad(int l, int r, int t, int b) => new() { left = l, right = r, top = t, bottom = b };

    private static Texture2D Solid(string hex)
    {
        var tex = new Texture2D(1, 1, TextureFormat.ARGB32, false);
        tex.SetPixels(new[] { Rgb(hex) });
        tex.Apply();
        tex.hideFlags = HideFlags.HideAndDontSave; // не выгружается при смене сцены
        return tex;
    }

    public static Color Rgb(string hex, float alpha = 1f)
    {
        var v = Convert.ToInt32(hex, 16);
        return new Color(((v >> 16) & 0xFF) / 255f, ((v >> 8) & 0xFF) / 255f, (v & 0xFF) / 255f, alpha);
    }

    // ---------- rich-text ----------

    public static string C(string text, string hex) => $"<color=#{hex}>{text}</color>";
    public static string B(string text) => $"<b>{text}</b>";
    public static string M(string text) => C(text, Muted);
    public static string A(string text) => C(text, Accent);

    /// <summary>Экранирование пользовательских строк (имена игроков могут содержать теги rich-text).</summary>
    public static string Esc(string? s)
    {
        if (string.IsNullOrEmpty(s)) return string.Empty;
        return s!.Replace("<", "‹").Replace(">", "›");
    }

    public static string RiskHex(RiskLevel l) => l switch
    {
        RiskLevel.Critical => "FF3B4E",
        RiskLevel.High => Accent,
        RiskLevel.Medium => "E08A2B",
        RiskLevel.Low => "C9A227",
        _ => "6B6B73",
    };

    public static string SeverityHex(Severity s) => s switch
    {
        Severity.Critical => "FF3B4E",
        Severity.High => Accent,
        Severity.Medium => "E08A2B",
        Severity.Low => "C9A227",
        _ => Muted,
    };

    public static string Risk(RiskAssessment r) => C($"{r.Score} · {RiskModel.LevelText(r.Level)}", RiskHex(r.Level));
}
