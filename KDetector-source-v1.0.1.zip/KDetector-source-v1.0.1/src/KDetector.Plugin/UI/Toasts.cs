using KDetector.Core.Actions;
using KDetector.Core.Configuration;
using KDetector.Plugin.Commands;
using UnityEngine;

namespace KDetector.Plugin.UI;

/// <summary>Всплывающие уведомления в правом верхнем углу (отдельное окно IMGUI, видно и при закрытом главном окне).</summary>
public sealed class Toasts : INotifier
{
    private static readonly List<Toast> Items = new();
    private static readonly object Sync = new();
    private readonly KdSettings _settings;

    public Toasts(KdSettings settings)
    {
        _settings = settings;
    }

    public static Rect Rect;

    public void Notify(NotifyLevel level, string title, string text)
    {
        lock (Sync)
        {
            Items.Add(new Toast(level, Theme.Esc(title), Theme.Esc(text), (float)_settings.Notifications.ToastSeconds));
            if (Items.Count > 5) Items.RemoveAt(0);
        }

        if (_settings.Notifications.ShowInChat)
            LocalChat.Show($"{title}: {text}");
    }

    /// <summary>Вызывается из OnGUI.</summary>
    private static readonly FrameCache<List<Toast>> Visible = new(0f);

    public static void Draw(bool mainVisible, bool showWhenClosed)
    {
        // Список фиксируется один раз за кадр, чтобы Layout и Repaint видели одинаковые элементы.
        var visible = Visible.Get(() =>
        {
            lock (Sync)
            {
                var now = Time.realtimeSinceStartup;
                foreach (var t in Items) t.Start ??= now;
                Items.RemoveAll(t => now - t.Start > t.Duration);
                return Items.ToList();
            }
        });

        if (visible.Count == 0 || (!mainVisible && !showWhenClosed))
        {
            Rect = default;
            return;
        }

        var width = Theme.Px(340);
        var height = Theme.Px(14) + visible.Count * Theme.Px(62);
        Rect = new Rect(Screen.width - width - Theme.Px(16), Theme.Px(16), width, height);
        var prev = GUI.backgroundColor;
        GUI.backgroundColor = new Color(0.05f, 0.05f, 0.06f, 0.95f);
        GUI.Window(0x4B44 + 1, Rect, (GUI.WindowFunction)DrawWindow, string.Empty);
        GUI.backgroundColor = prev;
    }

    private static void DrawWindow(int id)
    {
        var items = Visible.Get(() => new List<Toast>());
        GUILayout.BeginVertical(Theme.WindowBg, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
        foreach (var t in items)
        {
            GUILayout.BeginHorizontal(Theme.Panel2);
            GUILayout.Box(string.Empty, t.Level == NotifyLevel.Info ? Theme.Separator : Theme.AccentBar, GUILayout.Width(3f), GUILayout.Height(Theme.Px(40)));
            GUILayout.BeginVertical();
            GUILayout.Label(Theme.B(t.Title), Theme.Label);
            GUILayout.Label(Theme.M(t.Text), Theme.Small);
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        GUILayout.EndVertical();
    }

    private sealed class Toast
    {
        public Toast(NotifyLevel level, string title, string text, float duration)
        {
            Level = level;
            Title = title;
            Text = text.Length > 140 ? text.Substring(0, 140) + "…" : text;
            Duration = duration;
        }

        public NotifyLevel Level { get; }
        public string Title { get; }
        public string Text { get; }
        public float Duration { get; }
        public float? Start { get; set; }
    }
}
