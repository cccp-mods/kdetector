using KDetector.Core;
using KDetector.Core.Common;
using KDetector.Core.UiModel;
using UnityEngine;

namespace KDetector.Plugin.UI;

public enum Page
{
    Dashboard,
    Players,
    Detections,
    Database,
    AutoActions,
    RpcShield,
    Rules,
    Settings,
    Diagnostics,
    About,
}

/// <summary>
/// Состояние интерфейса хранится в статическом классе, а не в полях IL2CPP-компонента:
/// так закрытие/пересоздание компонента не теряет состояние и не зависит от особенностей внедрения типов.
/// </summary>
public static class UiState
{
    public static KDetectorCore? Core;
    public static bool Visible;
    public static Page Page = Page.Dashboard;
    public static Rect Window = new(80, 60, 980, 620);

    public const float TitleBarHeight = 38f;
    public const float ResizeGrip = 18f;

    public static readonly ManualClockAdapter Clock = new();
    public static readonly ConfirmGate Confirm = new(Clock) { TimeoutMs = 15000 };
    public static readonly ActionGuard Guard = new(Clock, 700);

    /// <summary>Перемещение/изменение размера окна (обрабатывается в Update по сырому вводу мыши).</summary>
    public static bool Dragging;
    public static bool Resizing;
    public static Vector2 DragOffset;

    public static Vector2 MouseGui()
    {
        var m = Input.mousePosition;
        return new Vector2(m.x, Screen.height - m.y);
    }

    public static bool PointerOverKDetector()
    {
        try
        {
            var mouse = MouseGui();
            if (Visible && Window.Contains(mouse)) return true;
            return Toasts.Rect.width > 0 && Toasts.Rect.Contains(mouse);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>Перемещение окна за верхнюю панель и изменение размера за правый нижний угол.</summary>
    public static void UpdateWindowInteraction(float scale)
    {
        if (!Visible) return;
        var mouse = MouseGui();
        var down = Input.GetMouseButtonDown(0);
        var held = Input.GetKey(KeyCode.Mouse0);

        if (down)
        {
            var grip = new Rect(Window.xMax - ResizeGrip * scale, Window.yMax - ResizeGrip * scale, ResizeGrip * scale, ResizeGrip * scale);
            var title = new Rect(Window.x, Window.y, Window.width - 260 * scale, TitleBarHeight * scale);
            if (grip.Contains(mouse)) Resizing = true;
            else if (title.Contains(mouse))
            {
                Dragging = true;
                DragOffset = mouse - new Vector2(Window.x, Window.y);
            }
        }

        if (!held)
        {
            if (Dragging || Resizing) WindowChanged = true;
            Dragging = false;
            Resizing = false;
            return;
        }

        if (Dragging)
        {
            Window.x = mouse.x - DragOffset.x;
            Window.y = mouse.y - DragOffset.y;
        }
        else if (Resizing)
        {
            Window.width = Mathf.Max(640 * scale, mouse.x - Window.x);
            Window.height = Mathf.Max(420 * scale, mouse.y - Window.y);
        }

        ClampToScreen();
    }

    /// <summary>Окно всегда остаётся в пределах экрана (при смене разрешения тоже).</summary>
    public static void ClampToScreen()
    {
        var w = Mathf.Min(Window.width, Screen.width);
        var h = Mathf.Min(Window.height, Screen.height);
        Window.width = w;
        Window.height = h;
        Window.x = Mathf.Clamp(Window.x, 0, Mathf.Max(0, Screen.width - w));
        Window.y = Mathf.Clamp(Window.y, 0, Mathf.Max(0, Screen.height - h));
    }

    /// <summary>Пользователь закончил перетаскивание — размеры стоит сохранить в конфигурацию.</summary>
    public static bool WindowChanged;

    // ---------- выбранные элементы страниц ----------
    public static int SelectedClientId = -1;
    public static string? SelectedRecordId;
    public static readonly HashSet<string> CheckedRecords = new();
    public static string Status = string.Empty;
    public static float StatusUntil;

    public static void SetStatus(string text, float seconds = 5f)
    {
        Status = text;
        StatusUntil = Time.realtimeSinceStartup + seconds;
    }
}

/// <summary>IClock поверх времени Unity/системы для моделей интерфейса.</summary>
public sealed class ManualClockAdapter : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
    public long MonotonicMs => KDetector.Core.Common.SystemClock.Instance.MonotonicMs;
}
