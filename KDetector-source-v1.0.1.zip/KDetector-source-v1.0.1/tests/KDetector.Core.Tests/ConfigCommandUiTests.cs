using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Game;
using KDetector.Core.Logging;
using KDetector.Core.RpcShield;
using KDetector.Core.UiModel;

namespace KDetector.Core.Tests;

public sealed class ConfigurationTests
{
    [Test]
    public void InvalidValuesAreClampedWithWarnings()
    {
        var s = new KdSettings();
        s.Detection.GlobalMinConfidence = 5;
        s.RpcShield.GlobalLimit = -3;
        s.Gui.Scale = double.NaN;
        s.Database.Extension = "exe";
        s.Commands.Prefix = "kd x";
        s.Gui.Hotkey = "";
        var w = SettingsValidator.Validate(s);
        Assert.Equal(1.0, s.Detection.GlobalMinConfidence);
        Assert.Equal(10, s.RpcShield.GlobalLimit);
        Assert.Equal(1.0, s.Gui.Scale);
        Assert.Equal("kh", s.Database.Extension);
        Assert.Equal("/kd", s.Commands.Prefix);
        Assert.Equal("F8", s.Gui.Hotkey);
        Assert.True(w.Count >= 6);
    }

    [Test]
    public void ExtensionIsNormalized()
    {
        var s = new KdSettings();
        s.Database.Extension = ".KD";
        SettingsValidator.Validate(s);
        Assert.Equal("kd", s.Database.Extension);
    }

    [Test]
    public void MinMaxAreSwapped()
    {
        var s = new KdSettings();
        s.Level.MinLevel = 500;
        s.Level.MaxLevel = 10;
        s.PlatformSpoof.XboxIdMinDigits = 18;
        s.PlatformSpoof.XboxIdMaxDigits = 3;
        SettingsValidator.Validate(s);
        Assert.Equal(10, s.Level.MinLevel);
        Assert.Equal(500, s.Level.MaxLevel);
        Assert.Equal(3, s.PlatformSpoof.XboxIdMinDigits);
    }

    [Test]
    public void ResetSectionAndAll()
    {
        var s = new KdSettings();
        var section = s.RpcShield;
        section.GlobalLimit = 999;
        s.General.DryRun = true;
        SettingsValidator.ResetSection(section);
        Assert.Equal(120, s.RpcShield.GlobalLimit);
        Assert.True(ReferenceEquals(section, s.RpcShield), "сброс не заменяет объект секции");
        Assert.True(s.General.DryRun);
        SettingsValidator.ResetAll(s);
        Assert.False(s.General.DryRun);
    }

    [Test]
    public void RuleSettingsResetToRuleDefaults()
    {
        using var env = new TestEnv();
        var rs = env.Core.Registry.Settings(RuleIds.UnknownRpc);
        Assert.Equal(3, rs.Threshold);
        rs.Threshold = 99;
        env.Core.Registry.ResetSettings(RuleIds.UnknownRpc);
        Assert.Equal(3, rs.Threshold);
    }

    [Test]
    public void JsonRuleFilesCreatedAndCorruptFileKept()
    {
        using var env = new TestEnv();
        var path = env.Core.Paths.Data("RpcShield.json");
        Assert.True(File.Exists(path));
        File.WriteAllText(path, "{ broken");
        var log = new KdLog(new ManualClock());
        var loaded = JsonFiles.LoadOrCreate(path, RpcShieldRuleSet.BuiltIn, log, "t", out var warning);
        Assert.NotNull(warning);
        Assert.True(loaded.Categories.Count > 0, "используются встроенные правила");
        Assert.Equal("{ broken", File.ReadAllText(path)); // пользовательский файл не перезаписан
    }

    [Test]
    public void EditedRuleFileIsApplied()
    {
        using var env = new TestEnv();
        env.Core.ShieldRules.Categories.First(c => c.Name == "Animation").MaxEvents = 2;
        env.Core.SaveShieldRules();
        var warnings = env.Core.ReloadRuleFiles();
        Assert.Equal(0, warnings.Count);
        Assert.Equal(2, env.Core.ShieldRules.Categories.First(c => c.Name == "Animation").MaxEvents);
    }

    [Test]
    public void EveryRuleHasDescriptionAndLimitations()
    {
        using var env = new TestEnv();
        foreach (var r in env.Core.Registry.All())
        {
            Assert.True(r.Descriptor.Name.Length > 0 && r.Descriptor.Description.Length > 0, r.Descriptor.Id);
            Assert.True(r.Descriptor.Limitations.Length > 0, "ограничения правила должны быть описаны: " + r.Descriptor.Id);
        }
    }
}

public sealed class CommandTests
{
    [Test]
    public void PrefixRecognition()
    {
        using var env = new TestEnv();
        var c = env.Core.Commands;
        Assert.True(c.IsCommand("/kd help"));
        Assert.True(c.IsCommand("  /KD"));
        Assert.False(c.IsCommand("/kdx"));
        Assert.False(c.IsCommand("привет /kd"));
        Assert.False(c.Execute("обычное сообщение").Handled);
        env.Settings.Commands.Enabled = false;
        Assert.False(c.IsCommand("/kd help"));
    }

    [Test]
    public void Tokenizer()
    {
        var t = Commands.CommandProcessor.Tokenize(" player \"Long Name\"  x ");
        Assert.Equal(3, t.Count);
        Assert.Equal("Long Name", t[1]);
    }

    [Test]
    public void HelpAndUnknown()
    {
        using var env = new TestEnv();
        Assert.True(env.Core.Commands.Execute("/kd").Lines.Count > 5);
        Assert.Contains("Неизвестная", env.Core.Commands.Execute("/kd nope").Lines[0]);
    }

    [Test]
    public void RemoveAllNeedsCorrectCodeInTime()
    {
        using var env = new TestEnv();
        env.Core.Database.EnsureRecord(TestEnv.Player(5, fc: "a#1"));
        env.Core.Database.EnsureRecord(TestEnv.Player(6, fc: "b#2"));
        var r = env.Core.Commands.Execute("/kd removeall");
        Assert.Equal(2, env.Core.Database.Count);
        var code = r.Lines[1].Split(' ')[3];

        Assert.Contains("Неверный", env.Core.Commands.Execute("/kd confirm XXXX").Lines[0]);
        Assert.Equal(2, env.Core.Database.Count);

        env.Clock.Advance(TimeSpan.FromSeconds(env.Settings.Commands.ConfirmTimeoutSeconds + 1));
        Assert.Contains("истекло", env.Core.Commands.Execute("/kd confirm " + code).Lines[0]);
        Assert.Equal(2, env.Core.Database.Count);

        r = env.Core.Commands.Execute("/kd removeall");
        code = r.Lines[1].Split(' ')[3];
        env.Core.Commands.Execute("/kd confirm " + code);
        Assert.Equal(0, env.Core.Database.Count);
        Assert.Contains("Нет действия", env.Core.Commands.Execute("/kd confirm " + code).Lines[0]); // повтор невозможен
    }

    [Test]
    public void KickRequiresHost()
    {
        using var env = new TestEnv();
        env.Core.ObservePlayers(new[] { TestEnv.Player(5, "Target") });
        env.SetContext(GamePhase.Lobby, localIsHost: false);
        env.Core.ObservePlayers(new[] { TestEnv.Player(5, "Target") });
        Assert.Contains("не хост", env.Core.Commands.Execute("/kd kick 5").Lines[0]);
        Assert.Equal(0, env.Host.Calls.Count);
    }

    [Test]
    public void KickAndBanByPlayerId()
    {
        using var env = new TestEnv();
        env.Core.ObservePlayers(new[] { TestEnv.Player(5, "Target") });
        Assert.Contains("выполнен", env.Core.Commands.Execute("/kd kick 5").Lines[0]);
        var r = env.Core.Commands.Execute("/kd ban Targ");
        Assert.Equal(1, env.Host.Calls.Count); // бан ждёт подтверждения
        env.Core.Commands.Execute("/kd confirm " + r.Lines[1].Split(' ')[3]);
        Assert.Equal(2, env.Host.Calls.Count);
        Assert.True(env.Host.Calls[1].ban);
    }

    [Test]
    public void DryRunAndProfileCommandsUpdateSettings()
    {
        using var env = new TestEnv();
        var changed = 0;
        env.Core.SettingsChanged += () => changed++;
        env.Core.Commands.Execute("/kd dryrun on");
        Assert.True(env.Settings.General.DryRun);
        env.Core.Commands.Execute("/kd profile strict");
        Assert.Equal(ActionProfileName.Strict, env.Settings.General.Profile);
        Assert.Equal(2, changed);
        Assert.Contains("Профили", env.Core.Commands.Execute("/kd profile ultra").Lines[0]);
    }

    [Test]
    public void WhitelistNeedsStableIdentity()
    {
        using var env = new TestEnv();
        env.Core.ObservePlayers(new[] { TestEnv.Player(5, "NoId"), TestEnv.Player(6, "Has", fc: "h#1") });
        Assert.Contains("нет Friend Code", env.Core.Commands.Execute("/kd whitelist 5").Lines[0]);
        Assert.Contains("добавлен", env.Core.Commands.Execute("/kd whitelist 6").Lines[0]);
        Assert.True(env.Core.Database.IsWhitelisted(TestEnv.Player(6, fc: "h#1")));
    }

    [Test]
    public void StatusAndPlayersWork()
    {
        using var env = new TestEnv();
        env.Core.ObservePlayers(new[] { TestEnv.Player(5, "A") });
        Assert.True(env.Core.Commands.Execute("/kd status").Lines.Count >= 4);
        Assert.Contains("A", env.Core.Commands.Execute("/kd players").Lines[0]);
        Assert.Contains("PlayerId", env.Core.Commands.Execute("/kd player 5").Lines[0]);
    }
}

public sealed class UiModelTests
{
    [Test]
    public void ConfirmGateTwoSteps()
    {
        var clock = new ManualClock();
        var g = new ConfirmGate(clock) { TimeoutMs = 1000 };
        g.Begin("delete-all", "удалить всё", 2);
        Assert.False(g.Confirm("delete-all"));
        Assert.Equal(1, g.Step);
        Assert.False(g.Confirm("other"));
        Assert.True(g.Confirm("delete-all"));
        Assert.Null(g.PendingAction);
        Assert.False(g.Confirm("delete-all"), "после выполнения повторно не срабатывает");
    }

    [Test]
    public void ConfirmGateExpires()
    {
        var clock = new ManualClock();
        var g = new ConfirmGate(clock) { TimeoutMs = 1000 };
        g.Begin("x", "x", 1);
        clock.AdvanceMs(1001);
        Assert.False(g.Confirm("x"));
        Assert.Null(g.PendingAction);
    }

    [Test]
    public void ActionGuardBlocksDoubleClick()
    {
        var clock = new ManualClock();
        var g = new ActionGuard(clock, 500);
        Assert.True(g.TryEnter("kick:5"));
        Assert.False(g.TryEnter("kick:5"));
        Assert.True(g.TryEnter("kick:6"));
        clock.AdvanceMs(500);
        Assert.True(g.TryEnter("kick:5"));
    }

    [Test]
    public void SortToggles()
    {
        var s = new SortState("Имя", false);
        s.Toggle("Имя");
        Assert.True(s.Descending);
        s.Toggle("Риск");
        Assert.Equal("Риск", s.Column);
        Assert.False(s.Descending);
        Assert.Equal(" ▲", s.Arrow("Риск"));
        Assert.Equal(string.Empty, s.Arrow("Имя"));
    }

    [Test]
    public void PlayerTableFilterAndSort()
    {
        using var env = new TestEnv();
        env.Core.ObservePlayers(new[] { TestEnv.Player(5, "Zed"), TestEnv.Player(6, "Amy"), TestEnv.Player(7, "Bob") });
        var rows = PlayerTable.Build(env.Core.Players.Snapshot(), p => env.Core.Risk.Assess(p.Key("ROOM1")), _ => false, string.Empty, new SortState("Имя", false));
        Assert.Equal("Amy", rows[0].Player.Identity.Name);
        rows = PlayerTable.Build(env.Core.Players.Snapshot(), p => env.Core.Risk.Assess(p.Key("ROOM1")), _ => false, "zE", new SortState("Имя", false));
        Assert.Equal(1, rows.Count);
    }

    [Test]
    public void DetectionFilter()
    {
        var events = new List<DetectionEvent>
        {
            new() { Summary = "spam", Category = DetectionCategory.RpcSpam, Severity = Severity.Low, Player = TestEnv.Player(1, "A") },
            new() { Summary = "level", Category = DetectionCategory.LevelSpoofing, Severity = Severity.High, Player = TestEnv.Player(2, "B") },
        };
        Assert.Equal(1, new DetectionFilter { MinSeverity = Severity.Medium }.Apply(events).Count);
        Assert.Equal(1, new DetectionFilter { Category = DetectionCategory.RpcSpam }.Apply(events).Count);
        Assert.Equal(1, new DetectionFilter { Text = "lev" }.Apply(events).Count);
        Assert.Equal(2, new DetectionFilter().Apply(events).Count);
    }

    [Test]
    public void PagingClampsPage()
    {
        var items = Enumerable.Range(0, 25).ToList();
        Assert.Equal(5, Paging.Page(items, 2, 10, out var pages).Count);
        Assert.Equal(3, pages);
        Assert.Equal(20, Paging.Page(items, 99, 10, out _)[0]);
        Assert.Equal(1, Paging.Page(new List<int>(), 0, 10, out var p2).Count + 1);
        Assert.Equal(1, p2);
    }
}

public sealed class PayloadReaderTests
{
    [Test]
    public void ReadsHazelFormat()
    {
        var data = new PayloadWriter().Byte(7).Packed(300).String("hi").Int32(-5).UInt64(ulong.MaxValue).ToArray();
        var r = new PayloadReader(data);
        Assert.True(r.TryReadByte(out var b) && b == 7);
        Assert.True(r.TryReadPackedInt32(out var p) && p == 300);
        Assert.True(r.TryReadString(out var s) && s == "hi");
        Assert.True(r.TryReadInt32(out var i) && i == -5);
        Assert.True(r.TryReadUInt64(out var u) && u == ulong.MaxValue);
        Assert.Equal(0, r.Remaining);
        Assert.False(r.TryReadByte(out _));
    }

    [Test]
    public void RejectsMalformedData()
    {
        Assert.False(new PayloadReader(new byte[] { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF }).TryReadPackedUInt32(out _));
        Assert.False(new PayloadReader(new PayloadWriter().Packed(50).ToArray()).TryReadString(out _));
        Assert.False(new PayloadReader(new byte[] { 1, 2 }).TryReadInt32(out _));
        Assert.Contains("(+", PayloadReader.ToHexPreview(new byte[100], 4));
    }
}

public sealed class LogTests
{
    [Test]
    public void ThrottledSuppressesRepeats()
    {
        var clock = new ManualClock();
        var log = new KdLog(clock);
        var sink = new MemorySink();
        log.AddSink(sink);
        for (var i = 0; i < 100; i++) log.Throttled("k", 1000, KdLogLevel.Warning, "t", "msg");
        Assert.Equal(1, sink.Lines.Count);
        clock.AdvanceMs(1000);
        log.Throttled("k", 1000, KdLogLevel.Warning, "t", "msg");
        Assert.Contains("подавлено повторов: 99", sink.Lines[1]);
    }

    [Test]
    public void FileSinkRotates()
    {
        var dir = Path.Combine(Path.GetTempPath(), "kdlog-" + Guid.NewGuid().ToString("N"));
        var path = Path.Combine(dir, "k.log");
        using (var sink = new RotatingFileSink(path, 64 * 1024, 2))
        {
            var line = new string('x', 1000);
            for (var i = 0; i < 300; i++) sink.Write(DateTime.UtcNow, KdLogLevel.Info, "t", line);
        }

        Assert.True(File.Exists(path + ".1"));
        Assert.False(File.Exists(path + ".3"), "хранится не больше MaxFiles архивов");
        Assert.True(new FileInfo(path).Length <= 66 * 1024);
        Directory.Delete(dir, true);
    }

    [Test]
    public void RingBufferBounded()
    {
        var rb = new RingBuffer<int>(3);
        for (var i = 0; i < 10; i++) rb.Add(i);
        Assert.Equal(3, rb.Count);
        Assert.Equal(9, rb.Latest(1)[0]);
        Assert.Equal(7, rb.Snapshot()[0]);
    }
}
