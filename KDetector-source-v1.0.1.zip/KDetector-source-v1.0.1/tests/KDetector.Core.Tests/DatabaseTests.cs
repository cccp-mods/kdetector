using System.Text;
using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Database;
using KDetector.Core.Detection;
using KDetector.Core.Logging;

namespace KDetector.Core.Tests;

public sealed class DatabaseTests
{
    private static DetectionEvent Evt(string fc, string name = "Bob", DetectionCategory cat = DetectionCategory.InvalidAction, DateTime? utc = null) => new()
    {
        TimestampUtc = utc ?? new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc),
        RuleId = "r1", RuleName = "r1", Category = cat, Evidence = EvidenceKind.ConfirmedInvalidAction, Severity = Severity.High,
        Confidence = 0.9, Player = TestEnv.Player(5, name, fc: fc), PlayerKey = "fc:" + fc, Summary = "summary " + fc,
        Facts = new List<Fact> { new("f", "v", "s") },
    };

    private static DatabaseService NewService(TestEnv env, string? file = null)
    {
        var svc = new DatabaseService(file ?? Path.Combine(env.Dir, "db", "KDetector.kh"), env.Settings, env.Log, env.Clock, startWorker: false);
        svc.Load();
        return svc;
    }

    [Test]
    public void SaveAndLoadRoundTrip()
    {
        using var env = new TestEnv();
        var path = Path.Combine(env.Dir, "db", "KDetector.kh");
        using (var svc = NewService(env, path))
        {
            svc.RecordEvent(Evt("a#1"));
            svc.RecordEvent(Evt("a#1"));
            svc.RecordEvent(Evt("b#2", "Ann"));
            svc.Flush();
        }

        Assert.True(File.Exists(path));
        Assert.Equal(2, File.ReadAllLines(path).Count(l => l.Length > 0)); // JSON Lines: одна запись — одна строка
        using var again = NewService(env, path);
        Assert.Equal(2, again.Count);
        var rec = again.FindByIdentifier("a#1").Single();
        Assert.Equal(2, rec.DetectionEvents.Count);
        Assert.Equal(DetectionRecord.CurrentSchemaVersion, rec.SchemaVersion);
    }

    [Test]
    public void MissingAndEmptyFilesAreEmptyDatabase()
    {
        using var env = new TestEnv();
        using var svc = NewService(env, Path.Combine(env.Dir, "none", "x.kh"));
        Assert.True(svc.IsLoaded);
        Assert.Equal(0, svc.Count);

        var empty = Path.Combine(env.Dir, "empty.kh");
        File.WriteAllText(empty, "\n\n");
        using var svc2 = NewService(env, empty);
        Assert.Equal(0, svc2.Count);
    }

    [Test]
    public void CorruptLinesAreQuarantinedNotDeleted()
    {
        using var env = new TestEnv();
        var path = Path.Combine(env.Dir, "c.kh");
        using (var svc = NewService(env, path))
        {
            svc.RecordEvent(Evt("a#1"));
            svc.RecordEvent(Evt("b#2"));
            svc.Flush();
        }

        var lines = File.ReadAllLines(path).ToList();
        lines.Insert(1, "{ это не json");
        File.WriteAllLines(path, lines);

        var db = new KdDatabase(path);
        var report = db.Load();
        Assert.Equal(2, report.Loaded);
        Assert.Equal(1, report.Corrupt);
        Assert.NotNull(report.QuarantineFile);
        Assert.Contains("это не json", File.ReadAllText(report.QuarantineFile!));
    }

    [Test]
    public void FutureSchemaLinesArePreserved()
    {
        using var env = new TestEnv();
        var path = Path.Combine(env.Dir, "f.kh");
        const string future = "{\"SchemaVersion\":99,\"RecordId\":\"zzz\",\"NewField\":1}";
        File.WriteAllText(path, future + "\n");
        using (var svc = NewService(env, path))
        {
            svc.RecordEvent(Evt("a#1"));
            svc.Flush();
        }

        Assert.True(File.ReadAllLines(path).Contains(future), "строка будущей схемы не должна теряться");
    }

    [Test]
    public void MigratesSchemaZeroAndHashesRawPuid()
    {
        using var env = new TestEnv();
        var path = Path.Combine(env.Dir, "m.kh");
        File.WriteAllText(path, "{\"Name\":\"Old\",\"FriendCode\":\"old#1\",\"Puid\":\"RAWPUID\",\"Note\":\"n\"}\n");
        var db = new KdDatabase(path);
        var report = db.Load();
        Assert.Equal(1, report.Migrated);
        var r = db.Records.Single();
        Assert.Equal("Old", r.PlayerName);
        Assert.Equal("n", r.Notes);
        Assert.Equal(Hashing.HashPuid("RAWPUID"), r.HashPuid);
        Assert.False(db.Serialize().Contains("RAWPUID"), "сырой PUID не должен сохраняться");
    }

    [Test]
    public void DuplicateRecordIdsAreFixed()
    {
        using var env = new TestEnv();
        var path = Path.Combine(env.Dir, "d.kh");
        File.WriteAllText(path,
            "{\"SchemaVersion\":1,\"RecordId\":\"same\",\"FriendCode\":\"a#1\"}\n{\"SchemaVersion\":1,\"RecordId\":\"same\",\"FriendCode\":\"b#2\"}\n");
        var db = new KdDatabase(path);
        var report = db.Load();
        Assert.Equal(1, report.DuplicateIdsFixed);
        Assert.Equal(2, db.Records.Select(r => r.RecordId).Distinct().Count());
    }

    [Test]
    public void DifferentPuidWithSameFriendCodeIsNotMerged()
    {
        using var env = new TestEnv();
        using var svc = NewService(env);
        var e1 = Evt("same#1");
        e1.Player.HashPuid = Hashing.HashPuid("p1");
        var e2 = Evt("same#1");
        e2.Player.HashPuid = Hashing.HashPuid("p2");
        svc.RecordEvent(e1);
        svc.RecordEvent(e2);
        Assert.Equal(2, svc.Count);
    }

    [Test]
    public void ExportImportMergesWithoutDuplicates()
    {
        using var env = new TestEnv();
        using var src = NewService(env, Path.Combine(env.Dir, "src.kh"));
        src.RecordEvent(Evt("a#1"));
        src.RecordEvent(Evt("b#2"));
        var export = Path.Combine(env.Dir, "export.jsonl");
        Assert.Equal(2, src.Export(export));

        using var dst = NewService(env, Path.Combine(env.Dir, "dst.kh"));
        dst.RecordEvent(Evt("a#1"));
        var r1 = dst.Import(export);
        Assert.Equal(1, r1.Added);
        Assert.Equal(1, r1.Merged);
        var r2 = dst.Import(export); // повторный импорт не дублирует события
        Assert.Equal(2, r2.Merged);
        Assert.Equal(2, dst.FindByIdentifier("a#1").Single().DetectionEvents.Count);
    }

    [Test]
    public void BackupAndRestore()
    {
        using var env = new TestEnv();
        using var svc = NewService(env, Path.Combine(env.Dir, "b", "KDetector.kh"));
        svc.RecordEvent(Evt("a#1"));
        var backup = svc.Backup();
        Assert.NotNull(backup);
        svc.DeleteAll();
        svc.Flush();
        Assert.Equal(0, svc.Count);
        svc.Restore(backup!);
        Assert.Equal(1, svc.Count);
        Assert.True(svc.Backups().Count >= 2, "перед восстановлением создаётся копия текущей базы");
    }

    [Test]
    public void BackupBeforeDeleteIncludesUnsavedChanges()
    {
        using var env = new TestEnv();
        using var svc = NewService(env, Path.Combine(env.Dir, "u2", "KDetector.kh"));
        svc.RecordEvent(Evt("a#1"));
        svc.Flush();
        svc.RecordEvent(Evt("b#2")); // ещё не записано на диск
        svc.DeleteAll();
        var backup = svc.Backups().First(b => b.Name.Contains("before-delete-all"));
        var restored = new KdDatabase(backup.FullName);
        restored.Load();
        Assert.Equal(2, restored.Records.Count);
    }

    [Test]
    public void BackupsAreRotated()
    {
        using var env = new TestEnv(s => s.Database.MaxBackups = 2);
        using var svc = NewService(env, Path.Combine(env.Dir, "r", "KDetector.kh"));
        svc.RecordEvent(Evt("a#1"));
        for (var i = 0; i < 5; i++) svc.Backup("t" + i);
        Assert.Equal(2, svc.Backups().Count);
    }

    [Test]
    public void DeleteRequiresIdsAndCreatesBackupForBulk()
    {
        using var env = new TestEnv();
        using var svc = NewService(env, Path.Combine(env.Dir, "x", "KDetector.kh"));
        svc.RecordEvent(Evt("a#1"));
        svc.RecordEvent(Evt("b#2"));
        svc.RecordEvent(Evt("c#3"));
        svc.Flush();
        var ids = svc.Query(new RecordQuery()).Take(2).Select(r => r.RecordId).ToList();
        Assert.Equal(2, svc.Delete(ids));
        Assert.Equal(1, svc.Count);
        Assert.True(svc.Backups().Any(b => b.Name.Contains("before-delete")));
    }

    [Test]
    public void SearchFilterAndSort()
    {
        using var env = new TestEnv();
        using var svc = NewService(env);
        svc.RecordEvent(Evt("aaa#1", "Alice", utc: new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc)));
        svc.RecordEvent(Evt("bbb#2", "Bob", DetectionCategory.RpcSpam, new DateTime(2026, 1, 2, 0, 0, 0, DateTimeKind.Utc)));
        svc.RecordEvent(Evt("bbb#2", "Bob", DetectionCategory.RpcSpam, new DateTime(2026, 1, 3, 0, 0, 0, DateTimeKind.Utc)));

        Assert.Equal("Alice", svc.Query(new RecordQuery { Text = "ali" }).Single().PlayerName);
        Assert.Equal("Bob", svc.Query(new RecordQuery { Text = "bbb#" }).Single().PlayerName);
        Assert.Equal("Bob", svc.Query(new RecordQuery { Category = DetectionCategory.RpcSpam }).Single().PlayerName);
        Assert.Equal("Bob", svc.Query(new RecordQuery { Sort = RecordSort.EventCountDesc }).First().PlayerName);
        Assert.Equal("Alice", svc.Query(new RecordQuery { Sort = RecordSort.LastSeenAsc }).First().PlayerName);

        var rec = svc.FindByIdentifier("aaa#1").Single();
        svc.SetReviewStatus(rec.RecordId, ReviewStatus.Cleared);
        svc.SetNote(rec.RecordId, "проверен");
        Assert.Equal("Alice", svc.Query(new RecordQuery { Status = ReviewStatus.Cleared }).Single().PlayerName);
    }

    [Test]
    public void CleanupRespectsKeepFlags()
    {
        using var env = new TestEnv(s =>
        {
            s.Database.RetentionDays = 30;
        });
        using var svc = NewService(env);
        var old = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        svc.RecordEvent(Evt("old#1", utc: old));
        svc.RecordEvent(Evt("kept#2", utc: old));
        svc.RecordEvent(Evt("new#3", utc: env.Clock.UtcNow));
        svc.SetReviewStatus(svc.FindByIdentifier("kept#2").Single().RecordId, ReviewStatus.Confirmed);

        // автоочистка выключена по умолчанию — без ручного запуска ничего не удаляется
        Assert.Equal((0, 0), svc.Cleanup(manual: false));
        var (records, _) = svc.Cleanup(manual: true);
        Assert.Equal(1, records);
        Assert.Equal(2, svc.Count);
        Assert.Equal(1, svc.FindByIdentifier("kept#2").Count);
    }

    [Test]
    public void ResolvePathUsesSingleActiveDatabase()
    {
        using var env = new TestEnv();
        var dir = Path.Combine(env.Dir, "p");
        Directory.CreateDirectory(dir);
        Assert.True(KdDatabase.ResolvePath(dir, "KDetector", "kh", out _).EndsWith(".kh"));
        File.WriteAllText(Path.Combine(dir, "KDetector.kd"), string.Empty);
        var p = KdDatabase.ResolvePath(dir, "KDetector", "kh", out var note);
        Assert.True(p.EndsWith(".kd"), "существующая .kd используется вместо создания второй базы");
        Assert.NotNull(note);
        File.WriteAllText(Path.Combine(dir, "KDetector.kh"), string.Empty);
        Assert.True(KdDatabase.ResolvePath(dir, "KDetector", "kh", out var note2).EndsWith(".kh"));
        Assert.Contains("оба", note2!);
    }

    [Test]
    public void FileIsPlainUtf8TextWithCyrillic()
    {
        using var env = new TestEnv();
        var path = Path.Combine(env.Dir, "u.kh");
        using (var svc = NewService(env, path))
        {
            svc.RecordEvent(Evt("a#1", "Игрок"));
            svc.Flush();
        }

        var text = File.ReadAllText(path, Encoding.UTF8);
        Assert.Contains("Игрок", text);
    }

    [Test]
    public void BackgroundWorkerFlushesWithoutBlocking()
    {
        using var env = new TestEnv(s => s.Database.FlushIntervalSeconds = 1);
        var path = Path.Combine(env.Dir, "w", "KDetector.kh");
        using var svc = new DatabaseService(path, env.Settings, new KdLog(SystemClock.Instance), SystemClock.Instance, startWorker: true);
        svc.Load();
        svc.RecordEvent(Evt("a#1"));
        var deadline = DateTime.UtcNow.AddSeconds(5);
        while (!File.Exists(path) && DateTime.UtcNow < deadline) Thread.Sleep(50);
        Assert.True(File.Exists(path), "фоновый поток должен записать базу");
    }
}
