using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Game;

namespace KDetector.Core.Tests;

public sealed class DetectionEngineTests
{
    private static DetectionCandidate Candidate(string rule, int clientId, double confidence = 0.8, string fc = "")
        => new()
        {
            RuleId = rule,
            Player = TestEnv.Player(clientId, fc: fc),
            Confidence = confidence,
            Severity = Severity.Medium,
            Summary = "test",
            CorrelationKey = "k",
        };

    [Test]
    public void ThresholdRequiresObservationsWithinWindow()
    {
        using var env = new TestEnv();
        var rs = env.Core.Registry.Settings(RuleIds.LevelInvalidValue);
        rs.Threshold = 3;
        rs.WindowSeconds = 10;

        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        var evt = env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5));
        Assert.NotNull(evt);
        Assert.Equal(3, evt!.ObservationCount);

        // после регистрации окно начинается заново
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }

    [Test]
    public void ObservationsOutsideWindowDoNotAccumulate()
    {
        using var env = new TestEnv();
        var rs = env.Core.Registry.Settings(RuleIds.LevelInvalidValue);
        rs.Threshold = 2;
        rs.WindowSeconds = 5;

        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        env.Clock.AdvanceMs(5000); // ровно граница окна: старое наблюдение уже не считается
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        env.Clock.AdvanceMs(4999);
        Assert.NotNull(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }

    [Test]
    public void ThresholdIsPerPlayer()
    {
        using var env = new TestEnv();
        env.Core.Registry.Settings(RuleIds.LevelInvalidValue).Threshold = 2;
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 6)));
        Assert.NotNull(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }

    [Test]
    public void LowConfidenceIsFiltered()
    {
        using var env = new TestEnv();
        env.Core.Registry.Settings(RuleIds.LevelInvalidValue).MinConfidence = 0.7;
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5, confidence: 0.69)));
        Assert.NotNull(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5, confidence: 0.7)));
        Assert.Equal(1L, env.Core.Registry.Get(RuleIds.LevelInvalidValue)!.SuppressedByConfidence);
    }

    [Test]
    public void ExceptionsSuppressEvents()
    {
        using var env = new TestEnv();
        env.Core.Registry.Settings(RuleIds.LevelInvalidValue).Exceptions = "friend#1234, other#1";
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5, fc: "Friend#1234")));
        Assert.NotNull(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5, fc: "someone#9")));
    }

    [Test]
    public void DisabledAndTemporarilyDisabledRules()
    {
        using var env = new TestEnv();
        env.Core.Registry.Settings(RuleIds.LevelInvalidValue).Enabled = false;
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));

        env.Core.Registry.Settings(RuleIds.LevelInvalidValue).Enabled = true;
        env.Core.Registry.DisableTemporarily(RuleIds.LevelInvalidValue, TimeSpan.FromMinutes(10), env.Clock.UtcNow);
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));

        env.Clock.Advance(TimeSpan.FromMinutes(11));
        Assert.NotNull(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }

    [Test]
    public void UnavailableRuleNeverFires()
    {
        using var env = new TestEnv();
        env.Core.Registry.SetAvailability(RuleIds.LevelInvalidValue, RuleAvailability.Unavailable, "нет API");
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }

    [Test]
    public void UnknownRuleIsIgnored()
    {
        using var env = new TestEnv();
        Assert.Null(env.Core.Engine.Process(Candidate("no.such.rule", 5)));
    }

    [Test]
    public void EventKeepsFactsSeparateFromHypothesis()
    {
        using var env = new TestEnv();
        var c = Candidate(RuleIds.LevelInvalidValue, 5);
        c.Hypothesis = "гипотеза";
        c.AddFact("Факт", "1", "источник");
        var evt = env.Core.Engine.Process(c)!;
        Assert.Equal("гипотеза", evt.Hypothesis);
        Assert.Equal(1, evt.Facts.Count);
        Assert.Equal("источник", evt.Facts[0].Source);
        Assert.Equal("2026.9.29", evt.GameVersion);
    }

    [Test]
    public void MasterSwitchDisablesEverything()
    {
        using var env = new TestEnv(s => s.General.Enabled = false);
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }

    [Test]
    public void FailingSubscriberDoesNotBreakOthers()
    {
        using var env = new TestEnv();
        var called = false;
        env.Core.Engine.EventPublished += _ => throw new InvalidOperationException("boom");
        env.Core.Engine.EventPublished += _ => called = true;
        Assert.NotNull(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        Assert.True(called, "второй подписчик должен быть вызван");
    }

    [Test]
    public void PlayerKeyPrefersStableIdentifiers()
    {
        var p = TestEnv.Player(5, fc: "abc#1", puid: "PUID");
        Assert.True(p.Key("S").StartsWith("puid:"));
        p.HashPuid = string.Empty;
        Assert.Equal("fc:abc#1", p.Key("S"));
        p.FriendCode = string.Empty;
        Assert.Equal("session:S:5", p.Key("S"));
    }

    [Test]
    public void SessionChangeResetsPendingThresholds()
    {
        using var env = new TestEnv();
        env.Core.Registry.Settings(RuleIds.LevelInvalidValue).Threshold = 2;
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
        env.SetContext(GamePhase.Lobby, session: "ROOM2");
        Assert.Null(env.Core.Engine.Process(Candidate(RuleIds.LevelInvalidValue, 5)));
    }
}
