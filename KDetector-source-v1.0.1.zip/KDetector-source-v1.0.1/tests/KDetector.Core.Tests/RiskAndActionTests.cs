using KDetector.Core.Actions;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Game;
using KDetector.Core.Risk;

namespace KDetector.Core.Tests;

public sealed class RiskTests
{
    private static DetectionEvent Evt(TestEnv env, string rule, string corr, Severity sev = Severity.High, double conf = 0.9,
        EvidenceKind kind = EvidenceKind.ConfirmedInvalidAction, string key = "fc:a#1") => new()
    {
        TimestampUtc = env.Clock.UtcNow, RuleId = rule, RuleName = rule, CorrelationKey = corr, Severity = sev,
        Confidence = conf, Evidence = kind, PlayerKey = key, Player = TestEnv.Player(5, fc: "a#1"),
    };

    [Test]
    public void RepeatsAreNotIndependentEvidence()
    {
        using var env = new TestEnv();
        for (var i = 0; i < 50; i++) env.Core.Risk.Add(Evt(env, "r1", "same"));
        var r = env.Core.Risk.Assess("fc:a#1");
        Assert.Equal(1, r.IndependentEvidence);
        var single = new RiskModel(env.Settings, env.Clock);
        single.Add(Evt(env, "r1", "same"));
        var s = single.Assess("fc:a#1");
        Assert.True(r.Score <= Math.Min(100, (int)(s.Score * 1.5) + 1), "повторы увеличивают вклад не более чем в 1.5 раза");
    }

    [Test]
    public void DifferentRulesAreIndependent()
    {
        using var env = new TestEnv();
        env.Core.Risk.Add(Evt(env, "r1", "x"));
        env.Core.Risk.Add(Evt(env, "r2", "y"));
        var r = env.Core.Risk.Assess("fc:a#1");
        Assert.Equal(2, r.IndependentEvidence);
        Assert.True(r.Score <= 100);
        Assert.True(r.Explanation.Count >= 3, "объяснение: итог + строка на каждую группу");
    }

    [Test]
    public void RiskDecaysOverTime()
    {
        using var env = new TestEnv();
        env.Core.Risk.Add(Evt(env, "r1", "x"));
        var before = env.Core.Risk.Assess("fc:a#1").Score;
        env.Clock.Advance(TimeSpan.FromMinutes(env.Settings.Detection.RiskHalfLifeMinutes));
        var after = env.Core.Risk.Assess("fc:a#1").Score;
        Assert.True(after < before, $"риск должен затухать: {before} → {after}");
        env.Clock.Advance(TimeSpan.FromMinutes(env.Settings.Detection.RiskHalfLifeMinutes * 20));
        env.Core.Risk.Prune();
        Assert.Equal(0, env.Core.Risk.Assess("fc:a#1").Score);
    }

    [Test]
    public void DifferentAccountsAreNotMerged()
    {
        using var env = new TestEnv();
        env.Core.Risk.Add(Evt(env, "r1", "x", key: "fc:a#1"));
        Assert.Equal(0, env.Core.Risk.Assess("fc:b#2").Score);
    }

    [Test]
    public void SingleWeakSignalIsLowRisk()
    {
        using var env = new TestEnv();
        env.Core.Risk.Add(Evt(env, "r1", "x", Severity.Low, 0.35, EvidenceKind.SuspiciousBehavior));
        Assert.True(env.Core.Risk.Assess("fc:a#1").Level <= RiskLevel.Low);
    }
}

public sealed class ActionTests
{
    private static DetectionCandidate Strong(int clientId, string rule, string corr, string fc = "x#1") => new()
    {
        RuleId = rule, Player = TestEnv.Player(clientId, fc: fc), Confidence = 0.95, Severity = Severity.Critical,
        Evidence = EvidenceKind.ConfirmedInvalidAction, Summary = "s", CorrelationKey = corr,
    };

    [Test]
    public void BalancedNeverKicks()
    {
        using var env = new TestEnv(s => s.AutoActions.AllowAutoKick = true);
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        env.Core.Engine.Process(Strong(5, RuleIds.LevelInvalidValue, "b"));
        Assert.Equal(0, env.Host.Calls.Count);
    }

    [Test]
    public void StrictKicksOnlyWhenAllowedAndHost()
    {
        using var env = new TestEnv(s => s.General.Profile = ActionProfileName.Strict);
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        env.Core.Engine.Process(Strong(5, RuleIds.LevelInvalidValue, "b"));
        Assert.Equal(0, env.Host.Calls.Count); // AllowAutoKick=false по умолчанию
        Assert.True(env.Core.Actions.ReviewQueue.Count == 1, "вместо кика — очередь рассмотрения");
        Assert.True(env.Core.Actions.History.Snapshot().Any(h => h.Kind == ActionKind.Kick && h.Outcome == ActionOutcome.Skipped));
    }

    [Test]
    public void StrictAutoKickExecutesWithEnoughEvidence()
    {
        using var env = new TestEnv(s =>
        {
            s.General.Profile = ActionProfileName.Strict;
            s.AutoActions.AllowAutoKick = true;
        });
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        Assert.Equal(0, env.Host.Calls.Count); // одно доказательство — недостаточно
        env.Core.Engine.Process(Strong(5, RuleIds.LevelInvalidValue, "b"));
        Assert.Equal(1, env.Host.Calls.Count);
        Assert.False(env.Host.Calls[0].ban);
    }

    [Test]
    public void NoKickWithoutHostAuthorityAtExecutionTime()
    {
        using var env = new TestEnv(s =>
        {
            s.General.Profile = ActionProfileName.Strict;
            s.AutoActions.AllowAutoKick = true;
        });
        env.Host.IsHost = false; // контекст говорит «хост», но фактическая проверка в момент действия — нет
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        env.Core.Engine.Process(Strong(5, RuleIds.LevelInvalidValue, "b"));
        Assert.Equal(0, env.Host.Calls.Count);
        Assert.True(env.Core.Actions.History.Snapshot().Any(h => h.Reason.Contains("не хост")));
    }

    [Test]
    public void DryRunDoesNotKick()
    {
        using var env = new TestEnv(s =>
        {
            s.General.Profile = ActionProfileName.Strict;
            s.AutoActions.AllowAutoKick = true;
            s.General.DryRun = true;
        });
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        env.Core.Engine.Process(Strong(5, RuleIds.LevelInvalidValue, "b"));
        Assert.Equal(0, env.Host.Calls.Count);
        Assert.True(env.Core.Actions.History.Snapshot().Any(h => h.Outcome == ActionOutcome.DryRun));
    }

    [Test]
    public void BanRequiresConfirmedViolationAndPermission()
    {
        using var env = new TestEnv(s =>
        {
            s.General.Profile = ActionProfileName.Strict;
            s.AutoActions.AllowAutoBan = true;
        });
        var c1 = Strong(5, RuleIds.KnownClientSignature, "a");
        c1.Evidence = EvidenceKind.KnownClientIndicator;
        var c2 = Strong(5, RuleIds.PlatformConsoleIdMismatch, "b");
        c2.Evidence = EvidenceKind.SuspiciousBehavior;
        var c3 = Strong(5, RuleIds.LevelAnomalousChange, "c");
        c3.Evidence = EvidenceKind.SuspiciousBehavior;
        env.Core.Engine.Process(c1);
        env.Core.Engine.Process(c2);
        env.Core.Engine.Process(c3);
        Assert.False(env.Host.Calls.Any(c => c.ban), "без подтверждённого нарушения бан не применяется");
    }

    [Test]
    public void WhitelistedPlayerGetsNoActions()
    {
        using var env = new TestEnv(s =>
        {
            s.General.Profile = ActionProfileName.Strict;
            s.AutoActions.AllowAutoKick = true;
        });
        var rec = env.Core.Database.EnsureRecord(TestEnv.Player(5, fc: "x#1"))!;
        env.Core.Database.SetWhitelist(rec.RecordId, true);
        var e1 = env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        env.Core.Engine.Process(Strong(5, RuleIds.LevelInvalidValue, "b"));
        Assert.True(e1!.Whitelisted);
        Assert.Equal(0, env.Host.Calls.Count);
        Assert.Equal(0, env.Notifier.Messages.Count);
    }

    [Test]
    public void ManualKickChecksAuthorityAndTarget()
    {
        using var env = new TestEnv();
        Assert.True(env.Core.Actions.TryHostAction(TestEnv.Player(5), false, false, "manual", "r", out _));
        Assert.False(env.Core.Actions.TryHostAction(TestEnv.Player(6, host: true), false, false, "manual", "r", out var e1));
        Assert.Contains("хосту", e1);
        Assert.False(env.Core.Actions.TryHostAction(TestEnv.Player(1, local: true), false, false, "manual", "r", out var e2));
        Assert.Contains("себе", e2);
        env.Host.IsHost = false;
        Assert.False(env.Core.Actions.TryHostAction(TestEnv.Player(7), true, false, "manual", "r", out var e3));
        Assert.Contains("не хост", e3);
        env.Host.KickAvailable = false;
        env.Host.IsHost = true;
        Assert.False(env.Core.Actions.TryHostAction(TestEnv.Player(7), false, false, "manual", "r", out var e4));
        Assert.Contains("недоступна", e4);
    }

    [Test]
    public void NotificationsRespectCooldown()
    {
        using var env = new TestEnv();
        var c = Strong(5, RuleIds.InvalidActionProtocol, "a");
        env.Core.Engine.Process(c);
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        Assert.Equal(1, env.Notifier.Messages.Count);
        env.Clock.Advance(TimeSpan.FromSeconds(env.Settings.Notifications.CooldownSeconds + 1));
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a"));
        Assert.Equal(2, env.Notifier.Messages.Count);
    }

    [Test]
    public void EventsAreRecordedInDatabaseOnlyWithStableIdentity()
    {
        using var env = new TestEnv();
        env.Core.Engine.Process(Strong(5, RuleIds.InvalidActionProtocol, "a", fc: ""));
        Assert.Equal(0, env.Core.Database.Count);
        env.Core.Engine.Process(Strong(6, RuleIds.InvalidActionProtocol, "a", fc: "y#2"));
        Assert.Equal(1, env.Core.Database.Count);
    }

    [Test]
    public void CustomProfileFileIsCreatedAndEditable()
    {
        using var env = new TestEnv();
        Assert.True(File.Exists(env.Core.Paths.Data("ActionPolicies.json")));
        env.Core.CopyProfileToCustom(ActionProfileName.Passive);
        env.Settings.General.Profile = ActionProfileName.Custom;
        Assert.Equal("Custom", env.Core.Actions.ActivePolicy.Name);
        Assert.False(env.Core.Actions.ActivePolicy.Categories.SelectMany(c => c.Actions).Any(a => a.Kind == ActionKind.CancelRpc));
    }

    [Test]
    public void AllProfilesKeepAutoBanOffByDefault()
    {
        var s = new KdSettings();
        Assert.False(s.AutoActions.AllowAutoBan);
        Assert.False(s.AutoActions.AllowAutoKick);
        Assert.Equal(ActionProfileName.Balanced, s.General.Profile);
        foreach (var p in new[] { ActionProfiles.Passive(), ActionProfiles.Balanced() })
            Assert.False(p.Categories.SelectMany(c => c.Actions).Any(a => a.Kind is ActionKind.Kick or ActionKind.Ban));
        foreach (var a in ActionProfiles.Strict().Categories.SelectMany(c => c.Actions).Where(a => a.Kind is ActionKind.Kick or ActionKind.Ban))
            Assert.True(a.MinIndependentEvidence >= 2, "в Strict Kick/Ban требуют нескольких независимых доказательств");
    }
}
