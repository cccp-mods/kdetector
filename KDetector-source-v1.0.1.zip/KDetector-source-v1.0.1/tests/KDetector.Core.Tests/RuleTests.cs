using KDetector.Core.Detection;
using KDetector.Core.Detection.Rules;
using KDetector.Core.Game;
using KDetector.Core.Network;
using KDetector.Core.Players;

namespace KDetector.Core.Tests;

public sealed class LevelRuleTests
{
    [Test]
    public void HighLevelAloneIsNotSuspicious()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        Assert.Equal(0, env.Core.Level.Observe(p, 99_999, "t").Count);
        Assert.Equal(0, env.Core.Level.Observe(TestEnv.Player(6), 0, "t").Count);
    }

    [Test]
    public void SignBitValueIsInvalid()
    {
        using var env = new TestEnv();
        var list = env.Core.Level.Observe(TestEnv.Player(5), uint.MaxValue, "t");
        Assert.Equal(1, list.Count);
        Assert.Equal(RuleIds.LevelInvalidValue, list[0].RuleId);
        Assert.Equal(EvidenceKind.InvalidProtocol, list[0].Evidence);
    }

    [Test]
    public void RangeCheckIsOffByDefault()
    {
        using var env = new TestEnv();
        Assert.False(env.Settings.Level.RangeCheckEnabled);
        env.Settings.Level.RangeCheckEnabled = true;
        env.Settings.Level.MaxLevel = 500;
        var list = env.Core.Level.Observe(TestEnv.Player(5), 600, "t");
        Assert.True(list.Any(c => c.RuleId == RuleIds.LevelOutOfRange));
    }

    [Test]
    public void DecreaseWithinConnectionIsFlagged()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        env.Core.Level.Observe(p, 50, "t");
        var list = env.Core.Level.Observe(p, 10, "t");
        Assert.True(list.Any(c => c.RuleId == RuleIds.LevelAnomalousChange && c.CorrelationKey == "decrease"));
    }

    [Test]
    public void IncreaseAfterMatchIsNormal()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        env.Core.Level.Observe(p, 50, "t");
        env.Core.Level.OnMatchEnded();
        Assert.Equal(0, env.Core.Level.Observe(p, 51, "t").Count);
    }

    [Test]
    public void IncreaseWithoutMatchIsLowConfidence()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        env.Core.Level.Observe(p, 50, "t");
        var list = env.Core.Level.Observe(p, 51, "t");
        Assert.Equal(1, list.Count);
        Assert.Equal(Severity.Low, list[0].Severity);
        Assert.True(list[0].Confidence < 0.5);
    }

    [Test]
    public void ZeroIsNotUsedAsBaseline()
    {
        // 0 — значение по умолчанию до прихода данных игрока; переход 0 → N не должен считаться изменением.
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        Assert.Equal(0, env.Core.Level.Observe(p, 0, "t").Count);
        Assert.Equal(0, env.Core.Level.Observe(p, 120, "t").Count);
    }

    [Test]
    public void LocalPlayerIsNeverChecked()
    {
        using var env = new TestEnv();
        Assert.Equal(0, env.Core.Level.Observe(TestEnv.Player(1, local: true), uint.MaxValue, "t").Count);
    }
}

public sealed class PlatformRuleTests
{
    private static PlatformInfo Info(int id, string? name, ulong xbox = 0, ulong psn = 0) =>
        new() { PlatformId = id, EnumName = name, XboxPlatformId = xbox, PsnPlatformId = psn };

    [Test]
    public void StarlightIsAllowed()
    {
        using var env = new TestEnv();
        Assert.Equal(0, env.Core.Platform.Observe(TestEnv.Player(5), Info(112, null)).Count);
    }

    [Test]
    public void UndefinedValueIsInvalidPlatformNotSpoof()
    {
        using var env = new TestEnv();
        var list = env.Core.Platform.Observe(TestEnv.Player(5), Info(77, null));
        Assert.Equal(1, list.Count);
        Assert.Equal(RuleIds.InvalidPlatformUndefined, list[0].RuleId);
        Assert.Equal(EvidenceKind.InvalidProtocol, list[0].Evidence);
    }

    [Test]
    public void UnknownValueIsWeakSignal()
    {
        using var env = new TestEnv();
        var list = env.Core.Platform.Observe(TestEnv.Player(5), Info(0, "Unknown"));
        Assert.Equal(RuleIds.InvalidPlatformUnknown, list.Single().RuleId);
        Assert.True(list[0].Confidence <= 0.3);
    }

    [Test]
    public void XboxWithoutConsoleIdIsSpoofSuspicion()
    {
        using var env = new TestEnv();
        var list = env.Core.Platform.Observe(TestEnv.Player(5), Info(5, "Xbox", xbox: 0));
        var c = list.Single();
        Assert.Equal(RuleIds.PlatformConsoleIdMismatch, c.RuleId);
        Assert.Equal(EvidenceKind.SuspiciousBehavior, c.Evidence);
        Assert.Contains("отсутствует", c.Summary);
    }

    [Test]
    public void ValidConsoleIdsPass()
    {
        using var env = new TestEnv();
        Assert.Equal(0, env.Core.Platform.Observe(TestEnv.Player(5), Info(5, "Xbox", xbox: 2535412345678901)).Count);
        Assert.Equal(0, env.Core.Platform.Observe(TestEnv.Player(6), Info(6, "Playstation", psn: 12345678901234567)).Count);
        Assert.Equal(1, env.Core.Platform.Observe(TestEnv.Player(7), Info(6, "Playstation", psn: 123)).Count);
    }

    [Test]
    public void PcPlatformsAreNotCheckedForConsoleIds()
    {
        using var env = new TestEnv();
        Assert.Equal(0, env.Core.Platform.Observe(TestEnv.Player(5), Info(2, "StandaloneSteamPC")).Count);
    }

    [Test]
    public void PlatformChangeWithinConnection()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        env.Core.Platform.Observe(p, Info(2, "StandaloneSteamPC"));
        var list = env.Core.Platform.Observe(p, Info(3, "StandaloneEpicPC"));
        Assert.True(list.Any(c => c.RuleId == RuleIds.PlatformSessionChange));
        env.Core.Platform.Forget(5); // переподключение
        Assert.Equal(0, env.Core.Platform.Observe(p, Info(2, "StandaloneSteamPC")).Count);
    }

    [Test]
    public void PlayerObservationChecksPlatformAfterDelayOnly()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5, fc: "a#1");
        p.Platform = Info(77, null);
        env.Core.ObservePlayers(new[] { p });
        Assert.Equal(0L, env.Core.Engine.SessionEventCount);
        env.Clock.AdvanceMs((long)(env.Settings.PlatformSpoof.CheckDelaySeconds * 1000));
        env.Core.ObservePlayers(new[] { p });
        Assert.Equal(1L, env.Core.Engine.SessionEventCount);
        env.Core.ObservePlayers(new[] { p }); // повторно не проверяется
        Assert.Equal(1L, env.Core.Engine.SessionEventCount);
    }
}

public sealed class KnownClientTests
{
    [Test]
    public void SignatureMatchIsIndicatorNotProof()
    {
        using var env = new TestEnv();
        var obs = env.Rpc(TestEnv.Player(5), 164);
        obs.Context = env.Core.Context;
        var c = env.Core.KnownClients.Evaluate(obs);
        Assert.NotNull(c);
        Assert.Equal(EvidenceKind.KnownClientIndicator, c!.Evidence);
        Assert.True(c.Confidence < 0.8);
        Assert.False(c.Cancelable);
    }

    [Test]
    public void DisabledOnModdedOrUnofficial()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.Lobby, modded: true);
        var obs = env.Rpc(TestEnv.Player(5), 164);
        obs.Context = env.Core.Context;
        Assert.Null(env.Core.KnownClients.Evaluate(obs));

        env.SetContext(GamePhase.Lobby, official: false);
        obs.Context = env.Core.Context;
        Assert.Null(env.Core.KnownClients.Evaluate(obs));
    }

    [Test]
    public void PayloadStructureRaisesOrRejects()
    {
        using var env = new TestEnv();
        var sender = TestEnv.Player(5);
        var good = env.Rpc(sender, 85, payload: new PayloadWriter().Byte(sender.PlayerId).ToArray());
        good.Context = env.Core.Context;
        var c = env.Core.KnownClients.Evaluate(good)!;
        Assert.True(c.Confidence >= 0.6);

        var bad = env.Rpc(sender, 85, payload: new PayloadWriter().Byte((byte)(sender.PlayerId + 1)).ToArray());
        bad.Context = env.Core.Context;
        Assert.Null(env.Core.KnownClients.Evaluate(bad));
    }

    [Test]
    public void TaggedChatStructure()
    {
        using var env = new TestEnv();
        var sender = TestEnv.Player(5);
        var payload = new PayloadWriter().Byte(1).Packed(sender.PlayerId).String("name").String("привет").UInt64(123).Byte(0).ToArray();
        var obs = env.Rpc(sender, 201, payload: payload);
        obs.Context = env.Core.Context;
        var c = env.Core.KnownClients.Evaluate(obs)!;
        Assert.True(c.Confidence >= 0.7);

        var truncated = env.Rpc(sender, 201, payload: payload.Take(5).ToArray());
        truncated.Context = env.Core.Context;
        Assert.Null(env.Core.KnownClients.Evaluate(truncated));
    }

    [Test]
    public void ConflictWithVanillaRpcDisablesSignature()
    {
        using var env = new TestEnv();
        env.Core.SetVanillaRpcPredicate(id => id == 164);
        Assert.False(env.Core.KnownClients.IsCandidateCallId(164));
        Assert.True(env.Core.KnownClients.Conflicts.Count == 1);
    }

    [Test]
    public void MalumMenuHasNoSignature()
    {
        var catalog = KnownClientRules_Catalog();
        Assert.False(catalog.Signatures.Any(s => s.Family.Contains("Malum", StringComparison.OrdinalIgnoreCase)));
    }

    private static SignatureCatalog KnownClientRules_Catalog() => SignatureCatalog.BuiltIn();
}

public sealed class ProtocolRuleTests
{
    private static List<DetectionCandidate> Eval(TestEnv env, RpcObservation obs)
    {
        obs.Context = env.Core.Context;
        return env.Core.Protocol.Evaluate(obs, false).ToList();
    }

    [Test]
    public void MatchActionInLobbyIsConfirmedInvalid()
    {
        using var env = new TestEnv();
        var list = Eval(env, env.Rpc(TestEnv.Player(5), 12));
        Assert.Equal(EvidenceKind.ConfirmedInvalidAction, list.Single().Evidence);

        env.SetContext(GamePhase.Tasks);
        Assert.Equal(0, Eval(env, env.Rpc(TestEnv.Player(5), 12)).Count);
    }

    [Test]
    public void PhaseRulesWaitForGracePeriod()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.Tasks, settle: false);
        env.SetContext(GamePhase.Lobby, settle: false); // матч закончился, мы в лобби
        Assert.Equal(0, Eval(env, env.Rpc(TestEnv.Player(5), 12)).Count); // MurderPlayer «на стыке» фаз не считается нарушением
        env.Clock.Advance(TimeSpan.FromSeconds(env.Settings.InvalidActions.PhaseGraceSeconds));
        Assert.Equal(1, Eval(env, env.Rpc(TestEnv.Player(5), 12)).Count);
    }

    [Test]
    public void SetRoleIsNotALobbyViolation()
    {
        Assert.False(ProtocolRuleSet.BuiltIn().Rules.Single(r => r.Id == "match-rpc-in-lobby").RpcNames.Contains("SetRole"));
    }

    [Test]
    public void HostOnlyRpcDependsOnSender()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.Tasks);
        Assert.Equal(0, Eval(env, env.Rpc(TestEnv.Player(5), 29, senderIsHost: true)).Count);
        var list = Eval(env, env.Rpc(TestEnv.Player(5), 29));
        Assert.Equal(1, list.Count);
        Assert.Contains("владельцу объекта", list[0].Hypothesis);
    }

    [Test]
    public void CosmeticsDuringMatch()
    {
        using var env = new TestEnv();
        Assert.Equal(0, Eval(env, env.Rpc(TestEnv.Player(5), 8)).Count); // лобби — можно
        env.SetContext(GamePhase.Meeting);
        Assert.Equal(1, Eval(env, env.Rpc(TestEnv.Player(5), 8)).Count);
    }

    [Test]
    public void SuspendedOnUnofficialAndModded()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.Lobby, official: false);
        Assert.Equal(0, Eval(env, env.Rpc(TestEnv.Player(5), 12)).Count);
        env.SetContext(GamePhase.Lobby, modded: true);
        Assert.Equal(0, Eval(env, env.Rpc(TestEnv.Player(5), 12)).Count);
    }

    [Test]
    public void UnknownRpcIsLoggedButNotCancelable()
    {
        using var env = new TestEnv();
        var c = Eval(env, env.Rpc(TestEnv.Player(5), 222)).Single();
        Assert.Equal(RuleIds.UnknownRpc, c.RuleId);
        Assert.False(c.Cancelable);
    }
}
