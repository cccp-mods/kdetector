using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Detection;
using KDetector.Core.Game;
using KDetector.Core.RpcShield;

namespace KDetector.Core.Tests;

public sealed class SlidingWindowTests
{
    [Test]
    public void AllowsExactlyLimitWithinWindow()
    {
        var c = new SlidingWindowCounter(3, 1000);
        Assert.True(c.Hit(0));
        Assert.True(c.Hit(10));
        Assert.True(c.Hit(20));
        Assert.False(c.Hit(30));
    }

    [Test]
    public void WindowBoundaryIsExclusive()
    {
        var c = new SlidingWindowCounter(2, 1000);
        Assert.True(c.Hit(0));
        Assert.True(c.Hit(500));
        Assert.False(c.Hit(999));   // из последних двух меток (0, 500) старейшая 0 ещё в окне
        Assert.True(c.Hit(1500));   // последние две метки — 500 и 999; 1500 − 500 = 1000 ≥ окна → разрешено
    }

    [Test]
    public void ContinuousFloodStaysBlocked()
    {
        var c = new SlidingWindowCounter(5, 1000);
        var allowed = 0;
        for (var t = 0; t < 5000; t += 10)
            if (c.Hit(t)) allowed++;
        // при 100 событиях/с и лимите 5/с превышающие события тоже учитываются, поэтому пропускается только начальная пачка
        Assert.Equal(5, allowed);
    }

    [Test]
    public void NormalRateIsNeverBlocked()
    {
        var c = new SlidingWindowCounter(5, 1000);
        for (var t = 0; t < 60000; t += 250)
            Assert.True(c.Hit(t), "4 события/с при лимите 5/с не должны блокироваться");
    }

    [Test]
    public void BurstEstimateGrowsWithIntensity()
    {
        var c = new SlidingWindowCounter(10, 1000);
        for (var i = 0; i < 60; i++) c.Hit(i);
        Assert.True(c.EstimatedInWindow(60) >= 50);
    }

    [Test]
    public void ReconfigureResetsState()
    {
        var c = new SlidingWindowCounter(1, 1000);
        Assert.True(c.Hit(0));
        Assert.False(c.Hit(1));
        c.Reconfigure(2, 1000);
        Assert.True(c.Hit(2));
        Assert.True(c.Hit(3));
    }
}

public sealed class RpcShieldTests
{
    private const byte Pet = 49;

    [Test]
    public void LimitsAreIndependentPerPlayer()
    {
        using var env = new TestEnv();
        var a = TestEnv.Player(5);
        var b = TestEnv.Player(6);
        for (var i = 0; i < 10; i++) Assert.Null(env.Core.Shield.Inspect(Obs(env, a, Pet)));
        Assert.NotNull(env.Core.Shield.Inspect(Obs(env, a, Pet)));
        Assert.Null(env.Core.Shield.Inspect(Obs(env, b, Pet)));
    }

    [Test]
    public void ReconnectResetsCounters()
    {
        using var env = new TestEnv();
        var a = TestEnv.Player(5);
        for (var i = 0; i < 11; i++) env.Core.Shield.Inspect(Obs(env, a, Pet));
        env.Core.PlayerLeft(5);
        Assert.Null(env.Core.Shield.Inspect(Obs(env, a, Pet)));
    }

    [Test]
    public void CategoriesAreIndependent()
    {
        using var env = new TestEnv();
        var a = TestEnv.Player(5);
        for (var i = 0; i < 11; i++) env.Core.Shield.Inspect(Obs(env, a, Pet));
        Assert.Null(env.Core.Shield.Inspect(Obs(env, a, 13))); // SendChat — своя категория
    }

    [Test]
    public void OnlySafeCategoriesAreCancelable()
    {
        using var env = new TestEnv();
        var a = TestEnv.Player(5);
        List<DetectionCandidate>? pet = null;
        for (var i = 0; i < 11; i++) pet = env.Core.Shield.Inspect(Obs(env, a, Pet));
        Assert.True(pet!.Single().Cancelable, "Animation безопасно отменять");

        List<DetectionCandidate>? snap = null;
        for (var i = 0; i < 21; i++) snap = env.Core.Shield.Inspect(Obs(env, a, 21));
        Assert.False(snap!.Single().Cancelable, "Movement небезопасно отменять");
    }

    [Test]
    public void SeverityEscalatesWithinCooldown()
    {
        using var env = new TestEnv();
        var a = TestEnv.Player(5);
        var emitted = new List<Severity>();
        for (var i = 0; i < 120; i++)
        {
            var obs = Obs(env, a, Pet);
            var verdict = env.Core.InspectRpc(obs);
        }

        foreach (var e in env.Core.Engine.Feed.Snapshot()) emitted.Add(e.Severity);
        Assert.True(emitted.Count >= 2 && emitted.Count <= 3, $"ожидалось 2–3 события по эскалации, получено {emitted.Count}");
        Assert.Equal(Severity.High, emitted.Last());
    }

    [Test]
    public void HostChatIsNotLimitedButHostPetFloodIs()
    {
        using var env = new TestEnv();
        var host = TestEnv.Player(2, host: true);
        for (var i = 0; i < 30; i++)
        {
            var chat = env.Rpc(host, 13, senderIsHost: true);
            chat.Context = env.Core.Context;
            Assert.Null(env.Core.Shield.Inspect(chat));
        }

        List<DetectionCandidate>? pet = null;
        for (var i = 0; i < 11; i++)
        {
            var o = env.Rpc(host, Pet, senderIsHost: true);
            o.Context = env.Core.Context;
            pet = env.Core.Shield.Inspect(o);
        }

        Assert.NotNull(pet);
    }

    [Test]
    public void ShieldDisabledDoesNothing()
    {
        using var env = new TestEnv(s => s.RpcShield.Enabled = false);
        var a = TestEnv.Player(5);
        for (var i = 0; i < 50; i++) Assert.Null(env.Core.Shield.Inspect(Obs(env, a, Pet)));
    }

    [Test]
    public void ResetToDefaultsRestoresBuiltInRules()
    {
        using var env = new TestEnv();
        env.Core.ShieldRules.Categories.First(c => c.Name == "Animation").MaxEvents = 1;
        env.Core.SaveShieldRules();
        env.Core.ResetShieldRulesToDefaults();
        Assert.Equal(10, env.Core.ShieldRules.Categories.First(c => c.Name == "Animation").MaxEvents);
        Assert.True(Directory.GetFiles(env.Core.Paths.DataDirectory, "RpcShield.json.bak-*").Length == 1, "копия пользовательского файла сохранена");
    }

    internal static Network.RpcObservation Obs(TestEnv env, Players.PlayerIdentity p, byte call)
    {
        var o = env.Rpc(p, call);
        o.Context = env.Core.Context;
        return o;
    }
}

public sealed class InspectorTests
{
    private const byte Pet = 49;

    private static int CountCancelled(TestEnv env, int n, byte call = Pet, int clientId = 5, string fc = "")
    {
        var p = TestEnv.Player(clientId, fc: fc);
        var cancelled = 0;
        for (var i = 0; i < n; i++)
            if (env.Core.InspectRpc(env.Rpc(p, call)).Cancel) cancelled++;
        return cancelled;
    }

    [Test]
    public void BalancedCancelsPetFlood()
    {
        using var env = new TestEnv();
        Assert.Equal(40, CountCancelled(env, 50));
    }

    [Test]
    public void DryRunNeverCancels()
    {
        using var env = new TestEnv(s => s.General.DryRun = true);
        Assert.Equal(0, CountCancelled(env, 50));
        Assert.True(env.Core.Engine.SessionEventCount > 0, "события всё равно регистрируются");
    }

    [Test]
    public void ShieldDryRunNeverCancels()
    {
        using var env = new TestEnv(s => s.RpcShield.DryRun = true);
        Assert.Equal(0, CountCancelled(env, 50));
    }

    [Test]
    public void PassiveProfileNeverCancels()
    {
        using var env = new TestEnv(s => s.General.Profile = ActionProfileName.Passive);
        Assert.Equal(0, CountCancelled(env, 50));
    }

    [Test]
    public void WhitelistedPlayerIsNotCancelled()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5, fc: "friend#1");
        var rec = env.Core.Database.EnsureRecord(p)!;
        env.Core.Database.SetWhitelist(rec.RecordId, true);
        Assert.Equal(0, CountCancelled(env, 50, fc: "friend#1"));
    }

    [Test]
    public void ConfigWhitelistPreventsCancelAndActions()
    {
        using var env = new TestEnv(s => s.Detection.Whitelist = "friend#7");
        Assert.Equal(0, CountCancelled(env, 50, fc: "FRIEND#7"));
        Assert.True(env.Core.Engine.Feed.Snapshot().All(e => e.Whitelisted), "события записаны с пометкой whitelist");
    }

    [Test]
    public void UnsupportedVersionObserveOnly()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.Lobby, version: "2099.1.1");
        Assert.Equal(0, CountCancelled(env, 50));
        Assert.True(env.Core.Engine.SessionEventCount > 0);
    }

    [Test]
    public void UnsupportedVersionDisableNetworkChecks()
    {
        using var env = new TestEnv(s => s.Compatibility.UnsupportedMode = UnsupportedVersionMode.DisableNetworkChecks);
        env.SetContext(GamePhase.Lobby, version: "2099.1.1");
        Assert.Equal(0, CountCancelled(env, 50));
        Assert.Equal(0L, env.Core.Engine.SessionEventCount);
    }

    [Test]
    public void LocalPlayerIsIgnored()
    {
        using var env = new TestEnv();
        var me = TestEnv.Player(1, local: true);
        for (var i = 0; i < 50; i++) Assert.False(env.Core.InspectRpc(env.Rpc(me, Pet)).Cancel);
        Assert.Equal(0L, env.Core.Inspector.Inspected);
    }

    [Test]
    public void NotInLobbyIsIgnored()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.NotConnected, session: "");
        Assert.Equal(0, CountCancelled(env, 50));
    }

    [Test]
    public void ConfirmedInvalidActionCancelledInBalanced()
    {
        using var env = new TestEnv();
        var p = TestEnv.Player(5);
        Assert.True(env.Core.InspectRpc(env.Rpc(p, 12)).Cancel, "MurderPlayer в лобби — подтверждённое недопустимое действие");
    }

    [Test]
    public void SuspiciousHostOnlyNotCancelledInBalanced()
    {
        using var env = new TestEnv();
        env.SetContext(GamePhase.Tasks);
        var p = TestEnv.Player(5);
        Assert.False(env.Core.InspectRpc(env.Rpc(p, 29)).Cancel, "SetTasks от не-хоста — InvalidProtocol, Balanced отменяет только подтверждённые");
        env.Settings.General.Profile = ActionProfileName.Strict;
        Assert.True(env.Core.InspectRpc(env.Rpc(p, 29)).Cancel);
    }

    [Test]
    public void ExceptionsPreventCancel()
    {
        using var env = new TestEnv();
        env.Core.Registry.Settings(Detection.Rules.RuleIds.RpcRateCategory).Exceptions = "friend#2";
        Assert.Equal(0, CountCancelled(env, 50, fc: "friend#2"));
    }
}
