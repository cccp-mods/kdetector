using System.Text;
using KDetector.Core.Actions;
using KDetector.Core.Common;
using KDetector.Core.Configuration;
using KDetector.Core.Game;
using KDetector.Core.Logging;
using KDetector.Core.Network;
using KDetector.Core.Players;

namespace KDetector.Core.Tests;

/// <summary>Изолированное окружение теста: временная папка, управляемые часы, ядро без фонового потока базы.</summary>
public sealed class TestEnv : IDisposable
{
    public TestEnv(Action<KdSettings>? configure = null)
    {
        Dir = Path.Combine(Path.GetTempPath(), "kdtests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Dir);
        Clock = new ManualClock();
        Log = new KdLog(Clock) { MinLevel = KdLogLevel.Debug };
        Log.AddSink(Sink);
        Settings = new KdSettings();
        configure?.Invoke(Settings);
        Core = new KDetectorCore(Settings, new KdPaths(Dir), Clock, Log, startDatabaseWorker: false);
        Core.Initialize();
        Core.SetVanillaRpcPredicate(id => Vanilla.ContainsKey(id));
        Host = new FakeHost();
        Notifier = new FakeNotifier();
        Core.Actions.Host = Host;
        Core.Actions.Notifier = Notifier;
        SetContext(GamePhase.Lobby);
    }

    public string Dir { get; }
    public ManualClock Clock { get; }
    public KdLog Log { get; }
    public MemorySink Sink { get; } = new();
    public KdSettings Settings { get; }
    public KDetectorCore Core { get; }
    public FakeHost Host { get; }
    public FakeNotifier Notifier { get; }

    /// <summary>Небольшое подмножество штатных RPC для тестов (номера условные: тестируется логика, а не протокол игры).</summary>
    public static readonly Dictionary<byte, string> Vanilla = new()
    {
        [2] = "PlayAnimation", [3] = "CompleteTask", [6] = "SetName", [8] = "SetColor", [9] = "SetHatStr", [12] = "MurderPlayer",
        [13] = "SendChat", [14] = "StartMeeting", [21] = "SnapTo", [29] = "SetTasks", [38] = "SetLevel", [49] = "Pet", [50] = "CancelPet",
    };

    /// <param name="settle">Пропустить период стабилизации после смены фазы (большинству тестов нужно устоявшееся состояние).</param>
    public void SetContext(GamePhase phase, bool localIsHost = true, bool official = true, bool modded = false, string version = "2026.9.29", string session = "ROOM1", bool settle = true)
    {
        Core.UpdateContext(new GameContext
        {
            Phase = phase,
            LocalIsHost = localIsHost,
            OnOfficialServer = official,
            ModdedProtocol = modded,
            GameVersion = version,
            SessionId = session,
            LocalClientId = 1,
            HostClientId = localIsHost ? 1 : 2,
        });
        if (settle) Clock.Advance(TimeSpan.FromSeconds(Settings.InvalidActions.PhaseGraceSeconds + 0.1));
    }

    public static PlayerIdentity Player(int clientId, string name = "", string fc = "", string puid = "", bool host = false, bool local = false) => new()
    {
        ClientId = clientId,
        PlayerId = (byte)(clientId % 15),
        Name = string.IsNullOrEmpty(name) ? "P" + clientId : name,
        FriendCode = fc,
        HashPuid = string.IsNullOrEmpty(puid) ? string.Empty : Hashing.HashPuid(puid),
        IsHost = host,
        IsLocal = local,
    };

    public RpcObservation Rpc(PlayerIdentity sender, byte callId, NetObjectKind kind = NetObjectKind.PlayerControl, byte[]? payload = null, bool senderIsHost = false) => new()
    {
        CallId = callId,
        RpcName = Vanilla.TryGetValue(callId, out var n) ? n : null,
        ObjectKind = kind,
        Sender = sender,
        SenderIsHost = senderIsHost,
        PayloadProvider = payload == null ? null : max => payload.Take(max).ToArray(),
    };

    public void Dispose()
    {
        Core.Dispose();
        try
        {
            Directory.Delete(Dir, true);
        }
        catch
        {
            // временная папка
        }
    }
}

public sealed class MemorySink : ILogSink
{
    public List<string> Lines { get; } = new();

    public void Write(DateTime utc, KdLogLevel level, string source, string message)
    {
        lock (Lines) Lines.Add($"[{level}] [{source}] {message}");
    }
}

public sealed class FakeHost : IHostActions
{
    public bool IsHost { get; set; } = true;
    public bool KickAvailable { get; set; } = true;
    public List<(int clientId, bool ban)> Calls { get; } = new();

    public bool LocalIsHostNow() => IsHost;

    public bool TryKick(int clientId, bool ban, out string error)
    {
        Calls.Add((clientId, ban));
        error = string.Empty;
        return true;
    }
}

public sealed class FakeNotifier : INotifier
{
    public List<string> Messages { get; } = new();
    public void Notify(NotifyLevel level, string title, string text) => Messages.Add(title + " | " + text);
}

/// <summary>Запись полезной нагрузки в формате Hazel (для тестов разбора).</summary>
public sealed class PayloadWriter
{
    private readonly List<byte> _bytes = new();

    public PayloadWriter Byte(byte b)
    {
        _bytes.Add(b);
        return this;
    }

    public PayloadWriter Int32(int v)
    {
        _bytes.AddRange(BitConverter.GetBytes(v));
        return this;
    }

    public PayloadWriter UInt64(ulong v)
    {
        _bytes.AddRange(BitConverter.GetBytes(v));
        return this;
    }

    public PayloadWriter Packed(uint v)
    {
        do
        {
            var b = (byte)(v & 0x7F);
            v >>= 7;
            if (v != 0) b |= 0x80;
            _bytes.Add(b);
        } while (v != 0);

        return this;
    }

    public PayloadWriter String(string s)
    {
        var data = Encoding.UTF8.GetBytes(s);
        Packed((uint)data.Length);
        _bytes.AddRange(data);
        return this;
    }

    public byte[] ToArray() => _bytes.ToArray();
}
