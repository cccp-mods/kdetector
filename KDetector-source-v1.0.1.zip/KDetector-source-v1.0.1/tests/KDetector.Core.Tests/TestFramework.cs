using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace KDetector.Core.Tests;

[AttributeUsage(AttributeTargets.Method)]
public sealed class TestAttribute : Attribute
{
}

public sealed class AssertionException : Exception
{
    public AssertionException(string message) : base(message)
    {
    }
}

public static class Assert
{
    public static void True(bool condition, string message = "ожидалось true")
    {
        if (!condition) throw new AssertionException(message);
    }

    public static void False(bool condition, string message = "ожидалось false")
    {
        if (condition) throw new AssertionException(message);
    }

    public static void Equal<T>(T expected, T actual, string message = "")
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
            throw new AssertionException($"ожидалось <{expected}>, получено <{actual}>. {message}");
    }

    public static void NotNull(object? value, string message = "ожидалось не null")
    {
        if (value == null) throw new AssertionException(message);
    }

    public static void Null(object? value, string message = "ожидался null")
    {
        if (value != null) throw new AssertionException(message + $" (получено {value})");
    }

    public static void Contains(string expectedSubstring, string actual)
    {
        if (actual == null || !actual.Contains(expectedSubstring, StringComparison.Ordinal))
            throw new AssertionException($"строка не содержит «{expectedSubstring}»: «{actual}»");
    }

    public static T Throws<T>(Action action) where T : Exception
    {
        try
        {
            action();
        }
        catch (T ex)
        {
            return ex;
        }
        catch (Exception ex)
        {
            throw new AssertionException($"ожидалось {typeof(T).Name}, получено {ex.GetType().Name}: {ex.Message}");
        }

        throw new AssertionException($"ожидалось исключение {typeof(T).Name}");
    }
}

public static class Program
{
    public static int Main(string[] args)
    {
        var filter = args.Length > 0 ? args[0] : null;
        var tests = typeof(Program).Assembly.GetTypes()
            .SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
            .Where(m => m.GetCustomAttribute<TestAttribute>() != null)
            .Where(m => filter == null || (m.DeclaringType!.Name + "." + m.Name).Contains(filter, StringComparison.OrdinalIgnoreCase))
            .OrderBy(m => m.DeclaringType!.Name).ThenBy(m => m.Name)
            .ToList();

        Console.OutputEncoding = Encoding.UTF8;
        var failed = new List<string>();
        var sw = Stopwatch.StartNew();
        string? currentGroup = null;
        foreach (var m in tests)
        {
            if (currentGroup != m.DeclaringType!.Name)
            {
                currentGroup = m.DeclaringType!.Name;
                Console.WriteLine($"== {currentGroup}");
            }

            try
            {
                var instance = m.IsStatic ? null : Activator.CreateInstance(m.DeclaringType!);
                m.Invoke(instance, null);
                if (instance is IDisposable d) d.Dispose();
                Console.WriteLine($"  PASS {m.Name}");
            }
            catch (TargetInvocationException tie) when (tie.InnerException != null)
            {
                failed.Add($"{m.DeclaringType!.Name}.{m.Name}: {tie.InnerException.GetType().Name}: {tie.InnerException.Message}");
                Console.WriteLine($"  FAIL {m.Name}: {tie.InnerException.Message}");
                if (tie.InnerException is not AssertionException) Console.WriteLine(tie.InnerException.StackTrace);
            }
        }

        Console.WriteLine();
        Console.WriteLine($"Тестов: {tests.Count}, успешно: {tests.Count - failed.Count}, провалено: {failed.Count}, время: {sw.ElapsedMilliseconds} мс");
        foreach (var f in failed) Console.WriteLine("  ✗ " + f);
        return failed.Count == 0 ? 0 : 1;
    }
}
